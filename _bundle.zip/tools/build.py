#!/usr/bin/env python3
"""Parse lessons/*.txt -> data/curriculum.js and (optionally) verify every lesson locally.

usage: python3 tools/build.py [--verify] [--only id1,id2]
"""
import os, sys, json, re, glob, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, 'py'))

MODULES = [
    {'id': 'pixels',   'title': 'Pixels & the Mat',        'blurb': 'An image is just a grid of numbers. Learn to read, write and rearrange them.'},
    {'id': 'arith',    'title': 'Pixel arithmetic',        'blurb': 'Saturation, rounding and blending — the arithmetic every pipeline relies on.'},
    {'id': 'color',    'title': 'Color spaces',            'blurb': 'BGR, grayscale and HSV, plus color masks.'},
    {'id': 'hist',     'title': 'Thresholds & histograms', 'blurb': 'Turn intensities into decisions and statistics.'},
    {'id': 'geometry', 'title': 'Geometry',                'blurb': 'Resizing, rotating and warping with inverse mapping and interpolation.'},
    {'id': 'conv',     'title': 'Convolution & blur',      'blurb': 'Borders, kernels, and the operation behind every CNN.'},
    {'id': 'edges',    'title': 'Gradients & edges',       'blurb': 'Sobel derivatives and the full Canny edge detector.'},
    {'id': 'morph',    'title': 'Morphology',              'blurb': 'Erode, dilate, open and close: shape operations on masks.'},
    {'id': 'shapes',   'title': 'Regions & contours',      'blurb': 'Label blobs, trace their outlines, measure and simplify them.'},
    {'id': 'detect',   'title': 'Detection',               'blurb': 'Voting with Hough transforms and sliding-window template matching.'},
    {'id': 'dnn',      'title': 'OpenCV for AI',           'blurb': 'The pre- and post-processing that sits around every neural network.'},
    {'id': 'projects', 'title': 'Capstone projects',       'blurb': 'Build real applications using only your own mycv library.'},
    {'id': 'live',     'title': 'Live video & webcam',     'blurb': 'Capture loops, motion, background models and tracking — running on your own camera.'},
]

SECTIONS = ['meta', 'concept', 'ai', 'questions', 'starter', 'solution', 'playground', 'ai_code', 'tests', 'hints']


def parse(path):
    txt = open(path, encoding='utf-8').read()
    parts = re.split(r'^=== (\w+)\s*$', txt, flags=re.M)
    d = {}
    for i in range(1, len(parts), 2):
        d[parts[i]] = parts[i + 1].strip('\n') + '\n'
    missing = [s for s in SECTIONS if s not in d]
    if missing:
        raise SystemExit('%s missing sections %s' % (path, missing))
    meta = json.loads(d['meta'])
    try:
        qs = json.loads(d['questions'])
    except json.JSONDecodeError as e:
        raise SystemExit('%s: bad questions JSON: %s' % (path, e))
    hints = [h[2:].strip() for h in d['hints'].split('\n') if h.startswith('- ')]
    les = dict(meta)
    les.update({'concept': d['concept'].strip(), 'ai': d['ai'].strip(), 'questions': qs,
                'starter': d['starter'].rstrip() + '\n', 'solution': d['solution'].rstrip() + '\n',
                'playground': d['playground'].rstrip() + '\n', 'ai_code': d['ai_code'].rstrip() + '\n',
                'tests': d['tests'], 'hints': hints})
    for opt in ('live', 'desktop'):
        if opt in d:
            les[opt] = d[opt].rstrip() + '\n'
    les.setdefault('banned', [])
    les.setdefault('fn', [])
    return les


def load_all():
    files = sorted(glob.glob(os.path.join(ROOT, 'lessons', '*.txt')))
    lessons = [parse(f) for f in files]
    ids = [l['id'] for l in lessons]
    assert len(ids) == len(set(ids)), 'duplicate ids'
    for l in lessons:
        assert l['module'] in [m['id'] for m in MODULES], l['id']
        for q in l['questions']:
            assert q['type'] in ('mcq', 'number', 'grid', 'multi'), (l['id'], q)
    return lessons


def verify(lessons, only=None):
    import grader
    grader.IMG_DIR = os.path.join(ROOT, 'img')
    lib = []
    bad = 0
    for l in lessons:
        if only and l['id'] not in only:
            lib.append({'id': l['id'], 'src': l['solution']})
            continue
        t0 = time.time()
        r = json.loads(grader.grade(lib, l['solution'], l['tests'], l['banned'], l['fn']))
        status = 'PASS' if r['passed'] else 'FAIL'
        if not r['passed']:
            bad += 1
            print('  error:', r['error'])
            for c in r['cases']:
                if c['ok'] is False:
                    print('   x', c['name'], '->', c['msg'][:400])
        rs = json.loads(grader.grade(lib, l['starter'], l['tests'], l['banned'], l['fn']))
        if rs['passed']:
            print('  WARNING: starter passes!'); bad += 1
        p = json.loads(grader.run(lib + [{'id': l['id'], 'src': l['solution']}], l['solution'], l['playground'], 'playground.py'))
        if p['error']:
            print('  playground error:', p['error']); bad += 1
        a = json.loads(grader.run(lib + [{'id': l['id'], 'src': l['solution']}], l['solution'], l['ai_code'], 'ai_example.py'))
        if a['error']:
            print('  ai_code error:', a['error']); bad += 1
        if l.get('live'):
            fullib = lib + [{'id': l['id'], 'src': l['solution']}]
            sres = json.loads(grader.live_setup(fullib, l['solution'], l['live']))
            if sres['error']:
                print('  live setup error:', sres['error']); bad += 1
            else:
                import numpy as np
                for k, fr in enumerate(grader.sim_video(n=4, size=(320, 240))):
                    rgba = np.dstack([fr[..., ::-1], np.full(fr.shape[:2], 255, np.uint8)]).tobytes()
                    out = grader.live_frame(rgba, 240, 320)
                    if out[4]:
                        print('  live frame error:', out[4]); bad += 1; break
                print('  live: %dx%d out, %.0f ms/frame, text=%r' % (out[2], out[1], out[5], out[3]))
        nq = len(l['questions'])
        print('%-22s %s  %d cases  %4dms  play:%d img  ai:%d img  q:%d' % (
            l['id'], status, len([c for c in r['cases'] if c['ok'] is not None]), int((time.time() - t0) * 1000),
            len(p['images']), len(a['images']), nq))
        lib.append({'id': l['id'], 'src': l['solution']})
    return bad


def main():
    lessons = load_all()
    only = None
    if '--only' in sys.argv:
        only = set(sys.argv[sys.argv.index('--only') + 1].split(','))
    if '--verify' in sys.argv:
        bad = verify(lessons, only)
        print('problems:', bad)
    grader_src = open(os.path.join(ROOT, 'py', 'grader.py'), encoding='utf-8').read()
    bundle = {'modules': MODULES, 'lessons': lessons, 'grader': grader_src,
              'images': sorted(os.path.basename(p) for p in glob.glob(os.path.join(ROOT, 'img', '*')))}
    with open(os.path.join(ROOT, 'data', 'curriculum.js'), 'w', encoding='utf-8') as f:
        f.write('window.CURRICULUM = ' + json.dumps(bundle, ensure_ascii=False) + ';\n')
    print('built %d lessons' % len(lessons))


if __name__ == '__main__':
    main()
