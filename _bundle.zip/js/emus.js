/* Emulator generators — one per algorithm family. Conventions mirror the reference solutions. */
(function () {
  var Rec = EMU.Rec, K = EMU.kinds;

  /* ---------- helpers */
  function rint(v) { var f = Math.floor(v), d = v - f; if (Math.abs(d - 0.5) < 1e-9) return f % 2 === 0 ? f : f + 1; return Math.round(v); }
  function sat(v) { return Math.max(0, Math.min(255, rint(v))); }
  function zeros(h, w, v) { var a = []; for (var y = 0; y < h; y++) { a.push([]); for (var x = 0; x < w; x++) a[y].push(v === undefined ? 0 : v); } return a; }
  function nulls(h, w) { return zeros(h, w, null); }
  function cp(a) { return JSON.parse(JSON.stringify(a)); }
  function randGray(r, h, w, lo, hi) { var a = zeros(h, w); for (var y = 0; y < h; y++) for (var x = 0; x < w; x++) a[y][x] = r.int(lo == null ? 0 : lo, hi == null ? 255 : hi); return a; }
  function smoothGray(r, h, w) {
    var a = zeros(h, w), gx = r.int(-30, 30), gy = r.int(-30, 30), c = r.int(80, 170);
    for (var y = 0; y < h; y++) for (var x = 0; x < w; x++) a[y][x] = sat(c + gx * (x - w / 2) + gy * (y - h / 2) + r.int(-12, 12));
    return a;
  }
  function stepImg(r, h, w) { // dark / bright regions with an edge
    var a = zeros(h, w), kind = r.int(0, 2), lo = r.int(10, 60), hi = r.int(170, 240), c = r.int(2, w - 3);
    for (var y = 0; y < h; y++) for (var x = 0; x < w; x++) {
      var on = kind === 0 ? x >= c : kind === 1 ? y >= c : (x - w / 2) * (x - w / 2) + (y - h / 2) * (y - h / 2) < (h / 3.2) * (h / 3.2);
      a[y][x] = sat((on ? hi : lo) + r.int(-8, 8));
    }
    return a;
  }
  function randColor(r, h, w) { var a = zeros(h, w); for (var y = 0; y < h; y++) for (var x = 0; x < w; x++) a[y][x] = [r.int(0, 255), r.int(0, 255), r.int(0, 255)]; return a; }
  function blobs(r, h, w, n, v) {
    var a = zeros(h, w); v = v || 255;
    for (var k = 0; k < n; k++) {
      var bw = r.int(1, 3), bh = r.int(1, 3), x0 = r.int(0, w - bw), y0 = r.int(0, h - bh);
      for (var y = y0; y < y0 + bh; y++) for (var x = x0; x < x0 + bw; x++) a[y][x] = v;
    }
    for (var j = 0; j < Math.floor(h * w / 30); j++) a[r.int(0, h - 1)][r.int(0, w - 1)] = v; // salt
    return a;
  }
  function borderIdx(p, n, type) {
    if (p >= 0 && p < n) return p;
    if (type === 'constant') return -1;
    if (type === 'replicate') return p < 0 ? 0 : n - 1;
    if (n === 1) return 0;
    if (type === 'wrap') return ((p % n) + n) % n;
    var period = type === 'reflect' ? 2 * n : 2 * n - 2;
    var q = ((p % period) + period) % period;
    if (type === 'reflect') return q < n ? q : 2 * n - 1 - q;
    return q < n ? q : 2 * n - 2 - q;
  }
  function f2(v) { return (Math.round(v * 100) / 100).toString(); }
  function f3(v) { return (Math.round(v * 1000) / 1000).toString(); }
  var G = function (id, title, mode, extra) { var p = { id: id, type: 'grid', title: title, mode: mode || 'gray' }; for (var k in extra || {}) p[k] = extra[k]; return p; };

  /* =========================== POINTWISE */
  K.pointwise = function (op) {
    var defs = {
      invert: { title: 'Invert: dst = 255 − src', params: [] },
      scale_abs: { title: 'convertScaleAbs: |α·src + β| → saturate', params: [
        { id: 'alpha', label: 'α', type: 'range', min: -2, max: 3, step: 0.1, value: 1.5 },
        { id: 'beta', label: 'β', type: 'range', min: -100, max: 100, step: 5, value: -40 }] },
      add_weighted: { title: 'addWeighted: α·A + β·B + γ', params: [
        { id: 'alpha', label: 'α', type: 'range', min: 0, max: 1, step: 0.1, value: 0.7 },
        { id: 'gamma', label: 'γ', type: 'range', min: -50, max: 50, step: 5, value: 0 }] },
      gray: { title: 'BGR → gray: 0.299R + 0.587G + 0.114B', params: [] },
      hsv: { title: 'BGR → HSV (OpenCV 8-bit ranges)', params: [{ id: 'show', label: 'ask for', type: 'select', options: ['V', 'S', 'H'], value: 'V' }] },
      in_range: { title: 'inRange: lo ≤ pixel ≤ hi on every channel', params: [
        { id: 'blo', label: 'B lo', type: 'range', min: 0, max: 255, step: 5, value: 0 },
        { id: 'glo', label: 'G lo', type: 'range', min: 0, max: 255, step: 5, value: 100 },
        { id: 'rlo', label: 'R lo', type: 'range', min: 0, max: 255, step: 5, value: 0 },
        { id: 'hi', label: 'all hi', type: 'range', min: 0, max: 255, step: 5, value: 255 }] },
      threshold: { title: 'threshold(src, T, maxval, type)', params: [
        { id: 't', label: 'T', type: 'range', min: 0, max: 255, step: 1, value: 127 },
        { id: 'type', label: 'type', type: 'select', options: ['binary', 'binary_inv', 'trunc', 'tozero', 'tozero_inv'], value: 'binary' }] }
    };
    var d = defs[op]; if (!d) return null;
    d.build = function (P, r) {
      var R = new Rec(), H = 5, W = 6, src, src2, out = nulls(H, W), panels;
      if (op === 'gray' || op === 'hsv' || op === 'in_range') { H = 4; W = 5; out = nulls(H, W); src = randColor(r, H, W); }
      else if (op === 'threshold' || op === 'invert') src = randGray(r, H, W);
      else src = randGray(r, H, W);
      if (op === 'add_weighted') { src2 = randGray(r, H, W); panels = [G('a', 'A'), G('b', 'B'), G('out', 'dst')]; R.set('a', src).set('b', src2); }
      else if (op === 'hsv') { panels = [G('src', 'src (B,G,R)', 'color'), G('out', 'HSV → ' + P.show, P.show === 'V' ? 'gray' : 'text')]; R.set('src', src); }
      else if (op === 'in_range') { panels = [G('src', 'src (B,G,R)', 'color'), G('out', 'mask', 'bin')]; R.set('src', src); }
      else if (op === 'gray') { panels = [G('src', 'src (B,G,R)', 'color'), G('out', 'gray')]; R.set('src', src); }
      else { panels = [G('src', 'src'), G('out', 'dst')]; R.set('src', src); }
      R.set('out', out);
      R.frame('Every output pixel depends only on the input pixel at the same (x, y). Step to process them in raster order.');
      for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) {
        var v = src[y][x], res, formula, q;
        if (op === 'invert') { res = 255 - v; formula = '255 − ' + v + ' = ' + res; }
        else if (op === 'scale_abs') { var raw = P.alpha * v + P.beta; res = sat(Math.abs(raw)); formula = '|' + P.alpha + '·' + v + ' + ' + P.beta + '| = ' + f2(Math.abs(raw)) + ' → round & clip → ' + res; }
        else if (op === 'add_weighted') { var b = src2[y][x], be = Math.round((1 - P.alpha) * 10) / 10, rw = P.alpha * v + be * b + P.gamma; res = sat(rw); formula = P.alpha + '·' + v + ' + ' + be + '·' + b + ' + ' + P.gamma + ' = ' + f2(rw) + ' → ' + res; }
        else if (op === 'gray') { var gv = 0.299 * v[2] + 0.587 * v[1] + 0.114 * v[0]; res = sat(gv); formula = '0.299·' + v[2] + ' + 0.587·' + v[1] + ' + 0.114·' + v[0] + ' = ' + f2(gv) + ' → ' + res; }
        else if (op === 'hsv') {
          var B = v[0], Gg = v[1], Rr = v[2], V = Math.max(B, Gg, Rr), mn = Math.min(B, Gg, Rr), dl = V - mn;
          var S = V > 0 ? rint(dl / V * 255) : 0, h = 0;
          if (dl > 0) { h = V === Rr ? 60 * (Gg - B) / dl : V === Gg ? 120 + 60 * (B - Rr) / dl : 240 + 60 * (Rr - Gg) / dl; if (h < 0) h += 360; }
          var Hh = rint(h / 2); if (Hh >= 180) Hh -= 180;
          res = P.show === 'V' ? V : P.show === 'S' ? S : Hh;
          formula = 'V = max = ' + V + ',  S = 255·(V−min)/V = 255·' + dl + '/' + V + ' = ' + S + ',  H = ' + f2(h) + '°/2 → ' + Hh;
        }
        else if (op === 'in_range') {
          var lo = [P.blo, P.glo, P.rlo], ok = v.every(function (c, i) { return c >= lo[i] && c <= P.hi; });
          res = ok ? 255 : 0; formula = '[' + v.join(', ') + '] within [' + lo.join(', ') + ']…[' + P.hi + ']³ ? ' + (ok ? 'yes → 255' : 'no → 0');
        }
        else if (op === 'threshold') {
          var t = P.t, ty = P.type;
          res = ty === 'binary' ? (v > t ? 255 : 0) : ty === 'binary_inv' ? (v > t ? 0 : 255) : ty === 'trunc' ? Math.min(v, t) : ty === 'tozero' ? (v > t ? v : 0) : (v > t ? 0 : v);
          formula = v + (v > t ? ' > ' : ' ≤ ') + t + ' → ' + res + '   (' + ty + ')';
        }
        out[y][x] = res;
        R.set('out', out).clearHl();
        ['src', 'a', 'b'].forEach(function (id) { R.hl(id, [[y, x, 'src']]); });
        R.hl('out', [[y, x, 'dst']]);
        q = op === 'in_range' ? 'Is this pixel in range? Type 255 or 0:' : null;
        R.frame('Pixel (x=' + x + ', y=' + y + ')', formula, { panel: 'out', y: y, x: x, answer: res, tol: op === 'hsv' && P.show === 'H' ? 1 : 0, q: q });
      }
      R.clearHl().frame('Done — ' + H * W + ' independent computations. On a GPU these would all run in parallel.');
      return { panels: panels, frames: R.frames };
    };
    return d;
  };

  /* =========================== SPLIT / MERGE */
  K.split = function () {
    return { title: 'split: one 3-channel image → three 1-channel planes', params: [],
      build: function (P, r) {
        var R = new Rec(), H = 3, W = 4, src = randColor(r, H, W), b = nulls(H, W), g = nulls(H, W), rr = nulls(H, W);
        var panels = [G('src', 'img[y, x] = [B, G, R]', 'color'), G('b', 'img[:, :, 0]  (B)'), G('g', 'img[:, :, 1]  (G)'), G('r', 'img[:, :, 2]  (R)')];
        R.set('src', src).set('b', b).set('g', g).set('r', rr).frame('In memory the channels are interleaved: B G R B G R … Splitting copies every third byte into its own plane.');
        for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) {
          var v = src[y][x]; b[y][x] = v[0]; g[y][x] = v[1]; rr[y][x] = v[2];
          R.set('b', b).set('g', g).set('r', rr).clearHl().hl('src', [[y, x, 'src']]).hl('b', [[y, x, 'dst']]).hl('g', [[y, x, 'dst']]).hl('r', [[y, x, 'dst']]);
          R.frame('Pixel (' + x + ', ' + y + ') sits at flat index ' + ((y * W + x) * 3) + ' in the byte buffer.', 'B=' + v[0] + '  G=' + v[1] + '  R=' + v[2], { panel: 'g', y: y, x: x, answer: v[1], q: 'What lands in the G plane here?' });
        }
        R.clearHl().frame('merge() is the exact inverse: interleave the three planes back into [B, G, R] triples.');
        return { panels: panels, frames: R.frames };
      } };
  };

  /* =========================== MAPPING (dst ← src lookup) */
  function homography(src, dst) { // 4 point pairs [[x,y]...] -> 3x3
    var A = [], bb = [];
    for (var i = 0; i < 4; i++) {
      var x = src[i][0], y = src[i][1], u = dst[i][0], v = dst[i][1];
      A.push([x, y, 1, 0, 0, 0, -u * x, -u * y]); bb.push(u);
      A.push([0, 0, 0, x, y, 1, -v * x, -v * y]); bb.push(v);
    }
    var h = solve(A, bb).x;
    return [[h[0], h[1], h[2]], [h[3], h[4], h[5]], [h[6], h[7], 1]];
  }
  function solve(A, b, rec) { // gaussian elimination with partial pivoting; optional recorder callback
    var n = A.length, M = A.map(function (row, i) { return row.concat([b[i]]); });
    for (var c = 0; c < n; c++) {
      var p = c; for (var i = c + 1; i < n; i++) if (Math.abs(M[i][c]) > Math.abs(M[p][c])) p = i;
      if (rec) rec('pivot', M, c, p);
      if (p !== c) { var t = M[p]; M[p] = M[c]; M[c] = t; if (rec) rec('swap', M, c, p); }
      for (var i2 = c + 1; i2 < n; i2++) {
        var f = M[i2][c] / M[c][c];
        for (var k = c; k <= n; k++) M[i2][k] -= f * M[c][k];
        if (rec) rec('elim', M, c, i2, f);
      }
    }
    var x = new Array(n);
    for (var i3 = n - 1; i3 >= 0; i3--) {
      var s = M[i3][n]; for (var k2 = i3 + 1; k2 < n; k2++) s -= M[i3][k2] * x[k2];
      x[i3] = s / M[i3][i3];
      if (rec) rec('back', M, i3, x.slice());
    }
    return { x: x, M: M };
  }
  function inv3(m) {
    var a = m[0][0], b = m[0][1], c = m[0][2], d = m[1][0], e = m[1][1], f = m[1][2], g = m[2][0], h = m[2][1], i = m[2][2];
    var A = e * i - f * h, B = -(d * i - f * g), C = d * h - e * g, det = a * A + b * B + c * C;
    return [[A / det, -(b * i - c * h) / det, (b * f - c * e) / det], [B / det, (a * i - c * g) / det, -(a * f - c * d) / det], [C / det, -(a * h - b * g) / det, (a * e - b * d) / det]];
  }
  function bilin(src, sx, sy, H, W, clampMode) {
    var x0 = Math.floor(sx), y0 = Math.floor(sy), ax = sx - x0, ay = sy - y0;
    var px = function (yy, xx) { return (xx >= 0 && xx < W && yy >= 0 && yy < H) ? src[yy][xx] : 0; };
    var v = (px(y0, x0) * (1 - ax) + px(y0, x0 + 1) * ax) * (1 - ay) + (px(y0 + 1, x0) * (1 - ax) + px(y0 + 1, x0 + 1) * ax) * ay;
    return { v: v, x0: x0, y0: y0, ax: ax, ay: ay };
  }
  K.mapping = function (op) {
    var defs = {
      flip: { title: 'flip: dst(x, y) = src(mirrored x, y)', params: [{ id: 'code', label: 'flipCode', type: 'select', options: [[1, '1 (horizontal)'], [0, '0 (vertical)'], [-1, '−1 (both)']], value: 1 }] },
      rotate: { title: 'rotate 90°: the output shape is (W, H)', params: [{ id: 'k', label: 'rotation', type: 'select', options: [['cw', '90° clockwise'], ['180', '180°'], ['ccw', '90° counter-clockwise']], value: 'cw' }] },
      nearest: { title: 'resize INTER_NEAREST: sx = floor(x · src_w / dst_w)', params: [
        { id: 'w', label: 'dst w', type: 'range', min: 2, max: 9, value: 7 }, { id: 'h', label: 'dst h', type: 'range', min: 2, max: 9, value: 6 }] },
      bilinear: { title: 'resize INTER_LINEAR: half-pixel centres + 4-neighbour blend', params: [
        { id: 'w', label: 'dst w', type: 'range', min: 2, max: 9, value: 7 }, { id: 'h', label: 'dst h', type: 'range', min: 2, max: 9, value: 6 }] },
      warp: { title: 'warpAffine: for every dst pixel, sample src at M⁻¹·(x, y)', params: [
        { id: 'ang', label: 'angle°', type: 'range', min: -180, max: 180, step: 15, value: 30 },
        { id: 'sc', label: 'scale', type: 'range', min: 0.5, max: 1.5, step: 0.1, value: 1 }] },
      perspective: { title: 'warpPerspective: divide by the third coordinate', params: [] },
      pad: { title: 'copyMakeBorder: where does an outside pixel come from?', params: [
        { id: 'type', label: 'border', type: 'select', options: ['constant', 'replicate', 'reflect', 'reflect_101', 'wrap'], value: 'reflect_101' },
        { id: 'p', label: 'pad', type: 'range', min: 1, max: 3, value: 2 }] }
    };
    var d = defs[op]; if (!d) return null;
    d.build = function (P, r) {
      var R = new Rec(), sh = 5, sw = 5, src, dh, dw, map, note0;
      if (op === 'rotate') { sh = 3; sw = 5; }
      if (op === 'nearest' || op === 'bilinear') { sh = 4; sw = 4; }
      if (op === 'pad') { sh = 4; sw = 4; }
      if (op === 'warp' || op === 'perspective') { sh = 7; sw = 7; }
      src = (op === 'warp' || op === 'perspective') ? stepImg(r, sh, sw) : randGray(r, sh, sw, 0, 255);
      if (op === 'warp' || op === 'perspective') { for (var yy = 0; yy < sh; yy++) for (var xx = 0; xx < sw; xx++) src[yy][xx] = sat(40 + 25 * xx + 6 * yy + r.int(-5, 5)); }
      var extraPanels = [], kv = null;
      if (op === 'flip') { dh = sh; dw = sw; var c = +P.code; map = function (y, x) { return [c === 1 ? y : sh - 1 - y, c === 0 ? x : sw - 1 - x]; }; note0 = 'Each dst pixel copies exactly one src pixel. flipCode 1 mirrors x, 0 mirrors y, −1 both.'; }
      else if (op === 'rotate') { if (P.k === '180') { dh = sh; dw = sw; map = function (y, x) { return [sh - 1 - y, sw - 1 - x]; }; } else { dh = sw; dw = sh; map = P.k === 'cw' ? function (y, x) { return [sh - 1 - x, y]; } : function (y, x) { return [x, sw - 1 - y]; }; } note0 = 'Input is ' + sh + '×' + sw + ' (rows×cols); the output is ' + dh + '×' + dw + '. Ask: which src pixel lands at dst(x, y)?'; }
      else if (op === 'nearest') { dh = P.h; dw = P.w; var ifx = sw / dw, ify = sh / dh; map = function (y, x) { return [Math.min(Math.floor(y * ify), sh - 1), Math.min(Math.floor(x * ifx), sw - 1)]; }; note0 = 'Scale factors: src_w/dst_w = ' + f3(ifx) + ', src_h/dst_h = ' + f3(ify) + '. No blending — pixels are duplicated or dropped.'; }
      else if (op === 'pad') { dh = sh + 2 * P.p; dw = sw + 2 * P.p; map = function (y, x) { var a = borderIdx(y - P.p, sh, P.type), b = borderIdx(x - P.p, sw, P.type); return a < 0 || b < 0 ? null : [a, b]; }; note0 = 'Border "' + P.type + '": inside pixels copy directly, outside indices are folded back by border_index().'; }
      else if (op === 'bilinear') { dh = P.h; dw = P.w; }
      else if (op === 'warp') {
        dh = sh; dw = sw;
        var a = P.ang * Math.PI / 180, al = P.sc * Math.cos(a), be = P.sc * Math.sin(a), cx = (sw - 1) / 2, cy = (sh - 1) / 2;
        var M = [[al, be, (1 - al) * cx - be * cy], [-be, al, be * cx + (1 - al) * cy]];
        var det = M[0][0] * M[1][1] - M[0][1] * M[1][0];
        var Mi = [[M[1][1] / det, -M[0][1] / det, 0], [-M[1][0] / det, M[0][0] / det, 0]];
        Mi[0][2] = -(Mi[0][0] * M[0][2] + Mi[0][1] * M[1][2]); Mi[1][2] = -(Mi[1][0] * M[0][2] + Mi[1][1] * M[1][2]);
        kv = [['M', '[' + M[0].map(f2).join(', ') + ']'], ['', '[' + M[1].map(f2).join(', ') + ']'], ['M⁻¹', '[' + Mi[0].map(f2).join(', ') + ']'], ['', '[' + Mi[1].map(f2).join(', ') + ']']];
        d._Mi = Mi;
      }
      else if (op === 'perspective') {
        dh = 6; dw = 6;
        var q = [[r.int(0, 2), r.int(0, 2)], [r.int(4, 6), r.int(0, 2)], [r.int(4, 6), r.int(4, 6)], [r.int(0, 2), r.int(4, 6)]];
        var Hm = homography([[0, 0], [dw - 1, 0], [dw - 1, dh - 1], [0, dh - 1]], q); // dst -> src directly
        d._Hm = Hm; d._q = q;
        kv = [['src quad', q.map(function (p) { return '(' + p + ')'; }).join(' ')], ['H⁻¹ row 0', Hm[0].map(f3).join(', ')], ['H⁻¹ row 1', Hm[1].map(f3).join(', ')], ['H⁻¹ row 2', Hm[2].map(f3).join(', ')]];
      }
      var dst = nulls(dh, dw);
      var panels = [G('src', 'src ' + sh + '×' + sw), G('dst', 'dst ' + dh + '×' + dw)];
      if (kv) panels.push({ id: 'kv', type: 'kv', title: 'matrices' });
      R.set('src', src).set('dst', dst); if (kv) R.set('kv', kv);
      R.frame(note0 || (op === 'bilinear' ? 'Map each dst centre back: sx = (x + 0.5)·' + f3(sw / dw) + ' − 0.5, clamp to the image, then blend the four neighbours.' : op === 'perspective' ? 'We map each dst pixel through the inverse homography, then divide by w (the third coordinate).' : 'Inverse mapping: loop over dst pixels, ask where they come from in src. This never leaves holes.'));
      for (var y = 0; y < dh; y++) for (var x = 0; x < dw; x++) {
        var val, formula, hls = [], tol = 0;
        if (map) {
          var s = map(y, x);
          if (!s) { val = 0; formula = 'outside & constant border → 0'; }
          else { val = src[s[0]][s[1]]; hls = [[s[0], s[1], 'src']]; formula = 'dst(' + x + ', ' + y + ') ← src(' + s[1] + ', ' + s[0] + ') = ' + val; }
        } else if (op === 'bilinear') {
          var co = function (i, dn, sn) { var f = (i + 0.5) * sn / dn - 0.5, i0 = Math.floor(f), fr = f - i0; if (i0 < 0) { i0 = 0; fr = 0; } if (i0 >= sn - 1) { i0 = sn - 1; fr = 0; } return [i0, Math.min(i0 + 1, sn - 1), fr, f]; };
          var cx2 = co(x, dw, sw), cy2 = co(y, dh, sh);
          var top = src[cy2[0]][cx2[0]] * (1 - cx2[2]) + src[cy2[0]][cx2[1]] * cx2[2], bot = src[cy2[1]][cx2[0]] * (1 - cx2[2]) + src[cy2[1]][cx2[1]] * cx2[2];
          var vv = top * (1 - cy2[2]) + bot * cy2[2]; val = sat(vv); tol = 1;
          hls = [[cy2[0], cx2[0], 'win'], [cy2[0], cx2[1], 'win'], [cy2[1], cx2[0], 'win'], [cy2[1], cx2[1], 'win']];
          formula = 'sx=' + f3(cx2[3]) + ' → x0=' + cx2[0] + ', ax=' + f3(cx2[2]) + ';  sy=' + f3(cy2[3]) + ' → y0=' + cy2[0] + ', ay=' + f3(cy2[2]) + ';  top=' + f2(top) + ' bot=' + f2(bot) + ' → ' + f2(vv) + ' → ' + val;
        } else if (op === 'warp') {
          var Mi2 = d._Mi, sx = Mi2[0][0] * x + Mi2[0][1] * y + Mi2[0][2], sy = Mi2[1][0] * x + Mi2[1][1] * y + Mi2[1][2];
          var bl = bilin(src, sx, sy, sh, sw); val = sat(bl.v); tol = 1;
          [[bl.y0, bl.x0], [bl.y0, bl.x0 + 1], [bl.y0 + 1, bl.x0], [bl.y0 + 1, bl.x0 + 1]].forEach(function (p) { if (p[0] >= 0 && p[0] < sh && p[1] >= 0 && p[1] < sw) hls.push([p[0], p[1], 'win']); });
          formula = 'M⁻¹·(' + x + ', ' + y + ', 1) = (' + f2(sx) + ', ' + f2(sy) + ') → bilinear → ' + val + (hls.length < 4 ? '   (partly outside → black)' : '');
        } else if (op === 'perspective') {
          var Hm2 = d._Hm, X = Hm2[0][0] * x + Hm2[0][1] * y + Hm2[0][2], Y = Hm2[1][0] * x + Hm2[1][1] * y + Hm2[1][2], Wd = Hm2[2][0] * x + Hm2[2][1] * y + Hm2[2][2];
          var px2 = X / Wd, py2 = Y / Wd, bl2 = bilin(src, px2, py2, sh, sw); val = sat(bl2.v); tol = 1;
          [[bl2.y0, bl2.x0], [bl2.y0, bl2.x0 + 1], [bl2.y0 + 1, bl2.x0], [bl2.y0 + 1, bl2.x0 + 1]].forEach(function (p) { if (p[0] >= 0 && p[0] < sh && p[1] >= 0 && p[1] < sw) hls.push([p[0], p[1], 'win']); });
          formula = '(X, Y, w) = (' + f2(X) + ', ' + f2(Y) + ', ' + f3(Wd) + ') → (' + f2(px2) + ', ' + f2(py2) + ') → ' + val;
        }
        dst[y][x] = val;
        R.set('dst', dst).clearHl().hl('src', hls).hl('dst', [[y, x, 'dst']]);
        if (op === 'pad' && (y < P.p || y >= dh - P.p || x < P.p || x >= dw - P.p)) formula = 'border_index(' + (x - P.p) + ', ' + sw + ') = ' + borderIdx(x - P.p, sw, P.type) + ', border_index(' + (y - P.p) + ', ' + sh + ') = ' + borderIdx(y - P.p, sh, P.type) + '  →  ' + formula;
        R.frame('dst pixel (x=' + x + ', y=' + y + ')', formula, { panel: 'dst', y: y, x: x, answer: val, tol: tol });
      }
      R.clearHl().frame('Done. Every dst pixel was computed by looking backwards into src — the core trick of all OpenCV geometry.');
      return { panels: panels, frames: R.frames };
    };
    return d;
  };

  /* =========================== BMP hex viewer */
  K.bmp = function () {
    return { title: 'Reading a 24-bit BMP byte by byte', params: [{ id: 'w', label: 'width', type: 'range', min: 1, max: 3, value: 3 }, { id: 'h', label: 'height', type: 'range', min: 1, max: 3, value: 2 }],
      build: function (P, r) {
        var W = P.w, H = P.h, row = Math.ceil(W * 3 / 4) * 4, size = 54 + row * H, bytes = [];
        var u16 = function (v) { bytes.push(v & 255, (v >> 8) & 255); }, u32 = function (v) { bytes.push(v & 255, (v >> 8) & 255, (v >> 16) & 255, (v >>> 24) & 255); };
        bytes.push(66, 77); u32(size); u32(0); u32(54); u32(40); u32(W); u32(H); u16(1); u16(24); u32(0); u32(row * H); u32(2835); u32(2835); u32(0); u32(0);
        var img = randColor(r, H, W);
        for (var rr = 0; rr < H; rr++) { var y = H - 1 - rr; for (var x = 0; x < W; x++) bytes.push(img[y][x][0], img[y][x][1], img[y][x][2]); for (var p = W * 3; p < row; p++) bytes.push(0); }
        var R = new Rec(), out = nulls(H, W), kv = [];
        var panels = [{ id: 'hex', type: 'hex', title: 'file bytes (hex)' }, { id: 'kv', type: 'kv', title: 'decoded header' }, G('img', 'decoded image', 'color')];
        R.set('hex', { bytes: bytes, a: 0, b: 0, seen: 0 }).set('kv', kv).set('img', out);
        R.frame('A BMP file is a 54-byte header followed by pixel rows. Numbers are little-endian: the lowest byte comes first.');
        var field = function (a, b, name, val, note, ask) {
          kv.push([name, String(val)]);
          R.set('hex', { bytes: bytes, a: a, b: b, seen: b }).set('kv', cp(kv));
          R.frame('Bytes ' + a + '–' + (b - 1) + ': ' + note, bytes.slice(a, b).map(function (v) { return v.toString(16).toUpperCase().padStart(2, '0'); }).join(' ') + '  →  ' + val, ask ? { answer: val, q: 'Decode these little-endian bytes as an integer:' } : null);
        };
        field(0, 2, 'magic', "'BM'", 'the signature — every BMP starts with ASCII "BM".');
        field(2, 6, 'file size', size, 'total file size (u32).', true);
        field(10, 14, 'pixel offset', 54, 'where the pixel array starts (u32).', true);
        field(18, 22, 'width', W, 'image width in pixels (s32).', true);
        field(22, 26, 'height', H, 'height (s32). Positive means rows are stored bottom-up.', true);
        field(28, 30, 'bits/pixel', 24, '24 → 3 bytes per pixel in B, G, R order.', true);
        kv.push(['row size', row + ' (= ceil(' + W + '·3 / 4)·4)']);
        R.set('kv', cp(kv)).frame('Each row is padded to a multiple of 4 bytes: ' + W + '·3 = ' + W * 3 + ' → ' + row + ' bytes.', 'row_size = ((w·3 + 3) // 4) · 4 = ' + row, { answer: row, q: 'How many bytes does each stored row take?' });
        for (var r2 = 0; r2 < H; r2++) {
          var yy = H - 1 - r2;
          for (var x2 = 0; x2 < W; x2++) {
            var o = 54 + r2 * row + x2 * 3;
            out[yy][x2] = img[yy][x2];
            R.set('img', out).set('hex', { bytes: bytes, a: o, b: o + 3, seen: o + 3 }).clearHl().hl('img', [[yy, x2, 'dst']]);
            R.frame('File row ' + r2 + ' is image row y = ' + yy + ' (bottom-up). Offset = 54 + ' + r2 + '·' + row + ' + ' + x2 + '·3 = ' + o, 'B=' + img[yy][x2][0] + ' G=' + img[yy][x2][1] + ' R=' + img[yy][x2][2] + '  →  img[' + yy + ', ' + x2 + ']', x2 === 0 ? { answer: o, q: 'At which byte offset does this pixel start?' } : null);
          }
          if (row > W * 3) { R.set('hex', { bytes: bytes, a: 54 + r2 * row + W * 3, b: 54 + (r2 + 1) * row, seen: 54 + (r2 + 1) * row }).clearHl().frame('Padding bytes — skip them.', (row - W * 3) + ' byte(s) of zeros'); }
        }
        R.clearHl().frame('Decoded. cv2.imread does exactly this (plus many more formats).');
        return { panels: panels, frames: R.frames };
      } };
  };

  /* =========================== HISTOGRAMS */
  K.hist = function (op) {
    if (op === 'calc') return { title: 'calcHist: one counter per intensity bin', params: [{ id: 'bins', label: 'bins', type: 'select', options: [4, 8, 16], value: 8 }],
      build: function (P, r) {
        var R = new Rec(), H = 5, W = 6, img = smoothGray(r, H, W), nb = +P.bins, h = new Array(nb).fill(0), bw = 256 / nb;
        var labels = h.map(function (_, i) { return i * bw; });
        var panels = [G('img', 'gray image'), { id: 'h', type: 'bars', title: 'histogram', h: 130 }];
        R.set('img', img).set('h', { data: h.slice(), labels: labels, max: H * W / 2 }).frame('Bin width = 256 / ' + nb + ' = ' + bw + '. Each pixel adds 1 to bin ⌊v / ' + bw + '⌋.');
        for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) {
          var v = img[y][x], b = Math.floor(v / bw); h[b]++;
          R.clearHl().hl('img', [[y, x, 'src']]).set('h', { data: h.slice(), hl: [b], labels: labels, max: H * W / 2 });
          R.frame('Pixel ' + v, 'bin = ⌊' + v + ' / ' + bw + '⌋ = ' + b + '  → count ' + h[b], { answer: b, q: 'Which bin index does ' + v + ' fall into?' });
        }
        R.clearHl().frame('Sum of all bins = ' + H * W + ' = number of pixels. Dividing by that gives a probability distribution.');
        return { panels: panels, frames: R.frames };
      } };
    if (op === 'equalize') return { title: 'equalizeHist: map through the normalised CDF', params: [],
      build: function (P, r) {
        var R = new Rec(), H = 4, W = 6, levels = [], base = r.int(60, 110);
        for (var i = 0; i < 6; i++) levels.push(base + i * r.int(4, 8));
        var img = zeros(H, W); for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) img[y][x] = levels[Math.min(5, Math.floor(Math.pow(r(), 1.3) * 6))];
        var cnt = levels.map(function (l) { var c = 0; img.forEach(function (row) { row.forEach(function (v) { if (v === l) c++; }); }); return c; });
        var used = levels.filter(function (_, i) { return cnt[i] > 0; }), uc = cnt.filter(function (c) { return c > 0; });
        var N = H * W, scale = 255 / (N - uc[0]), lut = {}, run = 0, cdf = [];
        var panels = [G('img', 'input'), { id: 'h', type: 'bars', title: 'histogram (used levels)' }, { id: 'lut', type: 'kv', title: 'LUT  level → new' }, G('out', 'equalized')];
        R.set('img', img).set('h', { data: uc, labels: used }).set('lut', []).set('out', nulls(H, W));
        R.frame('Only ' + used.length + ' grey levels are used, squeezed between ' + used[0] + ' and ' + used[used.length - 1] + '. Equalization spreads them over 0…255.', 'scale = 255 / (N − h[first]) = 255 / (' + N + ' − ' + uc[0] + ') = ' + f3(scale));
        var kv = [];
        used.forEach(function (l, i) {
          if (i > 0) run += uc[i];
          lut[l] = i === 0 ? 0 : sat(run * scale); cdf.push(run);
          kv.push([String(l), String(lut[l])]);
          R.set('lut', cp(kv)).set('h', { data: uc, labels: used, hl: [i] });
          R.frame(i === 0 ? 'The first used level always maps to 0.' : 'Running count (excluding the first bin) = ' + run, i === 0 ? 'lut[' + l + '] = 0' : 'lut[' + l + '] = round(' + run + ' · ' + f3(scale) + ') = ' + lut[l], i > 0 ? { answer: lut[l], tol: 1, q: 'lut[' + l + '] = ?' } : null);
        });
        var out = nulls(H, W);
        for (var y2 = 0; y2 < H; y2++) for (var x2 = 0; x2 < W; x2++) { out[y2][x2] = lut[img[y2][x2]]; R.set('out', out).clearHl().hl('img', [[y2, x2, 'src']]).hl('out', [[y2, x2, 'dst']]).frame('Look up ' + img[y2][x2] + ' in the LUT', img[y2][x2] + ' → ' + out[y2][x2]); }
        R.clearHl().frame('Same ordering, but now the full range is used — contrast stretched where pixels are dense.');
        return { panels: panels, frames: R.frames };
      } };
    if (op === 'otsu') return { title: "Otsu: maximise between-class variance", params: [],
      build: function (P, r) {
        var R = new Rec(), H = 5, W = 6, N = H * W, lv = [r.int(20, 50), r.int(60, 90), r.int(100, 130), r.int(150, 180), r.int(190, 230)];
        var img = zeros(H, W), dark = r.int(1, 3);
        for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) img[y][x] = r() < 0.5 ? lv[r.int(0, dark)] : lv[r.int(dark, 4)];
        var cnt = lv.map(function (l) { var c = 0; img.forEach(function (row) { row.forEach(function (v) { if (v === l) c++; }); }); return c; });
        var mu = 0; lv.forEach(function (l, i) { mu += l * cnt[i] / N; });
        var sig = lv.map(function () { return 0; }), best = -1, bt = 0;
        var panels = [G('img', 'gray image'), { id: 'h', type: 'bars', title: 'histogram' }, { id: 's', type: 'bars', title: 'σ²_between(t)' }, { id: 'kv', type: 'kv', title: 'classes for this t' }, G('mask', 'mask (v > t)', 'bin', { notext: true })];
        R.set('img', img).set('h', { data: cnt, labels: lv }).set('s', { data: sig.slice(), labels: lv }).set('kv', [['global mean μ', f2(mu)]]).set('mask', zeros(H, W));
        R.frame('Try every threshold t. Pixels ≤ t form class 1, the rest class 2. Pick the t that pushes the class means furthest apart (weighted).');
        var q1 = 0, s1 = 0;
        lv.forEach(function (l, i) {
          q1 += cnt[i] / N; s1 += l * cnt[i] / N;
          var q2 = 1 - q1; if (q1 <= 1e-9 || q2 <= 1e-9) return;
          var m1 = s1 / q1, m2 = (mu - s1) / q2, sb = q1 * q2 * (m1 - m2) * (m1 - m2); sig[i] = sb;
          if (sb > best) { best = sb; bt = l; }
          var mask = img.map(function (row) { return row.map(function (v) { return v > l ? 255 : 0; }); });
          R.set('h', { data: cnt, labels: lv, hl: lv.map(function (_, k) { return k; }).filter(function (k) { return k <= i; }) }).set('s', { data: sig.slice(), labels: lv, hl: [i] }).set('mask', mask);
          R.set('kv', [['t', l], ['q1 (weight ≤ t)', f3(q1)], ['q2', f3(q2)], ['μ1', f2(m1)], ['μ2', f2(m2)], ['σ²_b = q1·q2·(μ1−μ2)²', f2(sb)], ['best so far', 't = ' + bt]]);
          R.frame('Threshold t = ' + l, 'σ²_b = ' + f3(q1) + ' · ' + f3(q2) + ' · (' + f2(m1) + ' − ' + f2(m2) + ')² = ' + f2(sb), { answer: Math.round(sb), tol: Math.max(2, sb * 0.02), q: 'Compute σ²_between for t = ' + l + ' (nearest integer):' });
        });
        R.set('mask', img.map(function (row) { return row.map(function (v) { return v > bt ? 255 : 0; }); })).frame('Otsu picks t = ' + bt + ' — the peak of the σ² curve.', 'otsu_threshold = ' + bt);
        return { panels: panels, frames: R.frames };
      } };
    return null;
  };

  /* =========================== MATRIX */
  K.matrix = function (op) {
    if (op === 'rotation') return { title: 'getRotationMatrix2D(center, angle, scale)', params: [
      { id: 'ang', label: 'angle°', type: 'range', min: -180, max: 180, step: 15, value: 45 }, { id: 'sc', label: 'scale', type: 'range', min: 0.5, max: 2, step: 0.25, value: 1 },
      { id: 'cx', label: 'cx', type: 'range', min: 0, max: 100, step: 10, value: 50 }, { id: 'cy', label: 'cy', type: 'range', min: 0, max: 100, step: 10, value: 40 }], random: false,
      build: function (P) {
        var R = new Rec(), a = P.ang * Math.PI / 180, al = P.sc * Math.cos(a), be = P.sc * Math.sin(a);
        var M = [[al, be, (1 - al) * P.cx - be * P.cy], [-be, al, be * P.cx + (1 - al) * P.cy]];
        var pts = [[20, 20], [80, 20], [80, 60], [20, 60]], tp = pts.map(function (p) { return [M[0][0] * p[0] + M[0][1] * p[1] + M[0][2], M[1][0] * p[0] + M[1][1] * p[1] + M[1][2]]; });
        var panels = [{ id: 'kv', type: 'kv', title: 'M (2×3)' }, { id: 'cv', type: 'canvas', title: 'points (y grows downward)', w: 260, h: 220, draw: function (ctx, d, c) {
          var s = 1.6, ox = 50, oy = 30; ctx.strokeStyle = c.line; ctx.lineWidth = 1; ctx.strokeRect(ox, oy, 100 * s, 100 * s * 0.8);
          var poly = function (P2, col, dash) { ctx.setLineDash(dash || []); ctx.strokeStyle = col; ctx.lineWidth = 2; ctx.beginPath(); P2.forEach(function (p, i) { var X = ox + p[0] * s, Y = oy + p[1] * s * 0.8; i ? ctx.lineTo(X, Y) : ctx.moveTo(X, Y); }); ctx.closePath(); ctx.stroke(); ctx.setLineDash([]); };
          poly(pts, c.muted, [4, 3]); if (d && d.n) poly(tp.slice(0, 4), c.accent);
          if (d && d.n) for (var i = 0; i < d.n; i++) { ctx.fillStyle = c.accent; ctx.beginPath(); ctx.arc(ox + tp[i][0] * s, oy + tp[i][1] * s * 0.8, 3.5, 0, 7); ctx.fill(); }
          ctx.fillStyle = c.info; ctx.beginPath(); ctx.arc(ox + P.cx * s, oy + P.cy * s * 0.8, 4, 0, 7); ctx.fill();
        } }];
        var kv = [];
        R.set('cv', { n: 0 }).set('kv', kv).frame('Rotating about a centre = translate centre to origin, rotate, translate back. OpenCV folds this into one 2×3 matrix. Positive angles turn counter-clockwise on screen.');
        var add = function (k, v, note, f) { kv.push([k, f3(v)]); R.set('kv', cp(kv)).frame(note, f, { answer: v, tol: 0.01 + Math.abs(v) * 0.005, q: k + ' = ?' }); };
        add('α = s·cos θ', al, 'α', P.sc + '·cos(' + P.ang + '°) = ' + f3(al));
        add('β = s·sin θ', be, 'β', P.sc + '·sin(' + P.ang + '°) = ' + f3(be));
        add('M[0,2]', M[0][2], 'First-row translation', '(1−α)·cx − β·cy = ' + f3(M[0][2]));
        add('M[1,2]', M[1][2], 'Second-row translation', 'β·cx + (1−α)·cy = ' + f3(M[1][2]));
        tp.forEach(function (p, i) { R.set('cv', { n: i + 1 }).frame('transform_points: (' + pts[i] + ') → M·(x, y, 1)', 'x\' = ' + f3(al) + '·' + pts[i][0] + ' + ' + f3(be) + '·' + pts[i][1] + ' + ' + f3(M[0][2]) + ' = ' + f2(p[0]) + ',  y\' = ' + f2(p[1]), { answer: Math.round(p[0] * 100) / 100, tol: 0.05, q: 'x\' for (' + pts[i] + ') = ?' }); });
        R.frame('The blue dot (the centre) never moves — check M·(cx, cy, 1) = (cx, cy).');
        return { panels: panels, frames: R.frames };
      } };
    if (op === 'gauss') return { title: 'Gaussian elimination: solving A·x = b', params: [{ id: 'n', label: 'system', type: 'select', options: [[3, '3×3 (practice)'], [8, '8×8 (homography)']], value: 3 }],
      build: function (P, r) {
        var R = new Rec(), n = +P.n, A, b;
        if (n === 3) { A = [[r.int(-4, 5), r.int(-3, 3), r.int(-3, 3)], [r.int(-3, 3), r.int(-4, 5), r.int(-3, 3)], [r.int(-3, 3), r.int(-3, 3), r.int(2, 6)]]; A[0][0] = A[0][0] || 2; var xs = [r.int(-3, 3), r.int(-3, 3), r.int(-3, 3)]; b = A.map(function (row) { return row[0] * xs[0] + row[1] * xs[1] + row[2] * xs[2]; }); }
        else {
          var src = [[0, 0], [9, 0], [9, 9], [0, 9]], dst = [[r.int(0, 2), r.int(0, 2)], [r.int(7, 9), r.int(0, 2)], [r.int(7, 9), r.int(7, 9)], [r.int(0, 2), r.int(7, 9)]];
          A = []; b = [];
          for (var i = 0; i < 4; i++) { var x = src[i][0], y = src[i][1], u = dst[i][0], v = dst[i][1]; A.push([x, y, 1, 0, 0, 0, -u * x, -u * y]); b.push(u); A.push([0, 0, 0, x, y, 1, -v * x, -v * y]); b.push(v); }
        }
        var panels = [G('M', '[A | b] augmented', 'float', { cs: n > 3 ? 38 : 52, cf: n > 3 ? 9 : 11 }), { id: 'x', type: 'list', title: 'solution x' }];
        var aug = A.map(function (row, i) { return row.concat([b[i]]); });
        R.set('M', aug).set('x', { items: [] }).frame(n === 8 ? 'Each point pair (x,y)→(u,v) gives two rows. Unknowns: h00…h21 (h22 = 1).' : 'Goal: turn the left block upper-triangular, then back-substitute from the bottom.');
        var askEvery = 0;
        solve(A, b, function (kind, M, c, p, f) {
          var g = M.map(function (row) { return row.map(function (v) { return Math.round(v * 1000) / 1000; }); });
          R.set('M', g).clearHl();
          if (kind === 'pivot') { R.hl('M', [[p, c, 'src']].concat(g.map(function (_, i) { return [i, c, 'win']; }))); R.frame('Column ' + c + ': choose the row with the largest |value| as pivot (partial pivoting).', 'pivot row = ' + p + ', value = ' + f3(M[p][c])); }
          else if (kind === 'swap') { R.hl('M', g[0].map(function (_, k) { return [c, k, 'src']; })); R.frame('Swap rows ' + c + ' and ' + p + '.'); }
          else if (kind === 'elim') { var row = p; R.hl('M', g[0].map(function (_, k) { return [row, k, 'dst']; }).concat([[c, c, 'src']])); askEvery++; R.frame('Row ' + row + ' −= ' + f3(f) + ' × row ' + c, 'factor = M[' + row + '][' + c + '] / M[' + c + '][' + c + '] = ' + f3(f), n === 3 && askEvery <= 3 ? { answer: Math.round(f * 1000) / 1000, tol: 0.01, q: 'Elimination factor for row ' + row + '?' } : null); }
          else if (kind === 'back') { var xi = p; R.set('x', { items: xi.map(function (v) { return v == null ? '·' : Math.round(v * 1000) / 1000; }), hl: [c] }); R.hl('M', [[c, c, 'src'], [c, n, 'win']]); R.frame('Back-substitute row ' + c, 'x[' + c + '] = (b − Σ known terms) / M[' + c + '][' + c + '] = ' + f3(xi[c]), { answer: Math.round(xi[c] * 1000) / 1000, tol: 0.02, q: 'x[' + c + '] = ?' }); }
        });
        R.clearHl().frame(n === 8 ? 'These 8 numbers + 1 are the homography H. getPerspectiveTransform does exactly this.' : 'Solved. np.linalg.solve uses the same idea (LU decomposition).');
        return { panels: panels, frames: R.frames };
      } };
    return null;
  };

  /* =========================== 1-D gaussian kernel */
  K.kernel1d = function () {
    return { title: 'getGaussianKernel(ksize, sigma)', random: false, params: [
      { id: 'k', label: 'ksize', type: 'select', options: [3, 5, 7, 9], value: 5 }, { id: 's', label: 'σ (0 = auto)', type: 'range', min: 0, max: 3, step: 0.1, value: 1 }],
      build: function (P) {
        var R = new Rec(), k = +P.k, s = +P.s, c = (k - 1) / 2;
        var FIXED = { 1: [1], 3: [0.25, 0.5, 0.25], 5: [0.0625, 0.25, 0.375, 0.25, 0.0625], 7: [0.03125, 0.109375, 0.21875, 0.28125, 0.21875, 0.109375, 0.03125] };
        var panels = [{ id: 'w', type: 'bars', title: 'weights' }, { id: 'kv', type: 'kv', title: 'values' }];
        var w = new Array(k).fill(0), labs = w.map(function (_, i) { return String(i - c); });
        R.set('w', { data: w.slice(), labels: labs, max: 1 }).set('kv', []);
        if (s <= 0 && FIXED[k]) {
          R.set('w', { data: FIXED[k], labels: labs, max: 0.6 }).set('kv', FIXED[k].map(function (v, i) { return ['w[' + i + ']', String(v)]; }));
          R.frame('Special case: σ ≤ 0 and ksize ≤ 7 → OpenCV uses a fixed binomial table (exact fractions).', 'k=' + k + ': ' + FIXED[k].join(', '));
          return { panels: panels, frames: R.frames };
        }
        if (s <= 0) { s = 0.3 * ((k - 1) * 0.5 - 1) + 0.8; R.frame('σ ≤ 0: derive σ from the size.', 'σ = 0.3·((k−1)·0.5 − 1) + 0.8 = ' + f3(s), { answer: Math.round(s * 1000) / 1000, tol: 0.005, q: 'σ for ksize ' + k + '?' }); }
        var sum = 0, kv = [];
        for (var i = 0; i < k; i++) {
          var x = i - c; w[i] = Math.exp(-(x * x) / (2 * s * s)); sum += w[i];
          kv.push(['e[' + i + ']', f3(w[i])]);
          R.set('w', { data: w.slice(), labels: labs, hl: [i], max: 1 }).set('kv', cp(kv)).frame('Unnormalised weight at offset ' + x, 'exp(−' + x + '² / (2·' + f3(s) + '²)) = ' + f3(w[i]), { answer: Math.round(w[i] * 1000) / 1000, tol: 0.005, q: 'exp(−x²/2σ²) for x = ' + x + '?' });
        }
        kv.push(['sum', f3(sum)]); R.set('kv', cp(kv)).frame('Sum of weights', 'Σ = ' + f3(sum));
        var nw = w.map(function (v) { return v / sum; });
        R.set('w', { data: nw, labels: labs, max: 1 }).set('kv', nw.map(function (v, i) { return ['w[' + i + ']', f3(v)]; }).concat([['sum', '1.000']])).frame('Divide by the sum so the kernel adds up to 1 → blurring keeps the brightness.', 'w[c] = ' + f3(nw[c]), { answer: Math.round(nw[c] * 1000) / 1000, tol: 0.005, q: 'Normalised centre weight?' });
        return { panels: panels, frames: R.frames };
      } };
  };

  /* =========================== SLIDING WINDOW */
  var KERNELS = { sharpen: [[0, -1, 0], [-1, 5, -1], [0, -1, 0]], edge: [[-1, -1, -1], [-1, 8, -1], [-1, -1, -1]], emboss: [[-2, -1, 0], [-1, 1, 1], [0, 1, 2]], box: [[1 / 9, 1 / 9, 1 / 9], [1 / 9, 1 / 9, 1 / 9], [1 / 9, 1 / 9, 1 / 9]] };
  K.window = function (op) {
    var defs = {
      filter: { title: 'filter2D: Σ kernel × neighbourhood (reflect_101 border)', params: [{ id: 'k', label: 'kernel', type: 'select', options: ['sharpen', 'edge', 'emboss', 'box'], value: 'sharpen' }] },
      box: { title: 'Box blur with an integral image: 4 lookups per pixel', params: [] },
      gauss: { title: 'GaussianBlur 3×3: weighted average', params: [{ id: 's', label: 'σ', type: 'range', min: 0, max: 2, step: 0.1, value: 0 }] },
      median: { title: 'medianBlur 3×3: sort the window, take the middle', params: [] },
      sobel: { title: 'Sobel 3×3 (reflect_101) → signed gradient', params: [{ id: 'dir', label: 'derivative', type: 'select', options: [['x', 'dx=1 (vertical edges)'], ['y', 'dy=1 (horizontal edges)']], value: 'x' }] },
      erode: { title: 'Erode / dilate: window min / max', params: [{ id: 'op', label: 'op', type: 'select', options: ['erode', 'dilate'], value: 'erode' }] },
      morph: { title: 'morphologyEx: chaining erode and dilate', params: [{ id: 'op', label: 'op', type: 'select', options: ['open', 'close', 'gradient', 'tophat', 'blackhat'], value: 'open' }] },
      template: { title: 'matchTemplate: score every placement', params: [{ id: 'm', label: 'method', type: 'select', options: ['sqdiff', 'ccorr_normed', 'ccoeff_normed'], value: 'sqdiff' }] }
    };
    var d = defs[op]; if (!d) return null;
    d.build = function (P, r) {
      var R = new Rec(), H = 6, W = 6, src;
      if (op === 'median') { src = smoothGray(r, H, W); for (var i = 0; i < 5; i++) src[r.int(0, H - 1)][r.int(0, W - 1)] = r() < 0.5 ? 0 : 255; }
      else if (op === 'erode' || op === 'morph') { H = 7; W = 8; src = blobs(r, H, W, 3); }
      else if (op === 'sobel' || op === 'filter') src = stepImg(r, H, W);
      else if (op === 'template') { H = 7; W = 7; src = randGray(r, H, W, 20, 120); }
      else src = smoothGray(r, H, W);

      /* --- box blur via integral */
      if (op === 'box') {
        var pad = [], PH = H + 2, PW = W + 2;
        for (var y = 0; y < PH; y++) { pad.push([]); for (var x = 0; x < PW; x++) pad[y].push(src[borderIdx(y - 1, H, 'reflect_101')][borderIdx(x - 1, W, 'reflect_101')]); }
        var I = zeros(PH + 1, PW + 1), If = nulls(PH + 1, PW + 1);
        for (var a = 0; a <= PH; a++) { If[a][0] = 0; } for (var b2 = 0; b2 <= PW; b2++) If[0][b2] = 0;
        var panels = [G('pad', 'padded src (reflect_101)', 'gray', { cs: 30 }), G('I', 'integral  S[y][x] = Σ above-left', 'float', { cs: 34, cf: 9 }), G('out', 'box 3×3')];
        R.set('pad', pad).set('I', If).set('out', nulls(H, W)).frame('Integral image: S[y+1][x+1] = p[y][x] + S[y][x+1] + S[y+1][x] − S[y][x]. One extra row/column of zeros on top/left.');
        var shown = 0;
        for (var y1 = 1; y1 <= PH; y1++) for (var x1 = 1; x1 <= PW; x1++) {
          I[y1][x1] = pad[y1 - 1][x1 - 1] + I[y1 - 1][x1] + I[y1][x1 - 1] - I[y1 - 1][x1 - 1]; If[y1][x1] = I[y1][x1];
          if (shown < 14 || (y1 === PH && x1 === PW)) {
            R.set('I', If).clearHl().hl('pad', [[y1 - 1, x1 - 1, 'src']]).hl('I', [[y1, x1, 'dst'], [y1 - 1, x1, 'win'], [y1, x1 - 1, 'win'], [y1 - 1, x1 - 1, 'dim']]);
            R.frame('S[' + y1 + '][' + x1 + ']', pad[y1 - 1][x1 - 1] + ' + ' + I[y1 - 1][x1] + ' + ' + I[y1][x1 - 1] + ' − ' + I[y1 - 1][x1 - 1] + ' = ' + I[y1][x1], shown < 6 ? { panel: 'I', y: y1, x: x1, answer: I[y1][x1] } : null);
            shown++;
          }
        }
        R.set('I', I).clearHl().frame('…the rest is filled the same way (fast-forwarded). Now any rectangle sum costs 4 lookups.');
        var out = nulls(H, W);
        for (var yy = 0; yy < H; yy++) for (var xx = 0; xx < W; xx++) {
          var y0 = yy, x0 = xx, y3 = yy + 3, x3 = xx + 3, sum = I[y3][x3] - I[y0][x3] - I[y3][x0] + I[y0][x0], v = sat(sum / 9);
          out[yy][xx] = v;
          var win = []; for (var dy = 0; dy < 3; dy++) for (var dx = 0; dx < 3; dx++) win.push([yy + dy, xx + dx, 'win']);
          R.set('out', out).clearHl().hl('pad', win).hl('I', [[y3, x3, 'ok'], [y0, x3, 'bad'], [y3, x0, 'bad'], [y0, x0, 'ok']]).hl('out', [[yy, xx, 'dst']]);
          R.frame('Window sum = S[↘] − S[↗] − S[↙] + S[↖]', I[y3][x3] + ' − ' + I[y0][x3] + ' − ' + I[y3][x0] + ' + ' + I[y0][x0] + ' = ' + sum + ';  /9 = ' + f2(sum / 9) + ' → ' + v, { panel: 'out', y: yy, x: xx, answer: v, tol: 1 });
        }
        R.clearHl().frame('Cost per pixel is constant — a 31×31 box costs the same as 3×3.');
        return { panels: panels, frames: R.frames };
      }

      /* --- template matching */
      if (op === 'template') {
        var tx = r.int(0, 4), ty = r.int(0, 4), T = [];
        for (var j = 0; j < 3; j++) { T.push([]); for (var k = 0; k < 3; k++) { var tv = r.int(150, 250); T[j].push(tv); src[ty + j][tx + k] = sat(tv + r.int(-10, 10)); } }
        var oh = H - 2, ow = W - 2, Rm = nulls(oh, ow), n = 9, Tm = 0; T.forEach(function (row) { row.forEach(function (v) { Tm += v / 9; }); });
        var panels2 = [G('src', 'image'), G('T', 'template'), G('R', 'result R (' + P.m + ')', 'float', { cs: 40, cf: 9 })];
        R.set('src', src).set('T', T).set('R', Rm).frame('Slide the template over every position where it fits completely: (' + H + '−3+1) × (' + W + '−3+1) = ' + oh + '×' + ow + ' scores.');
        var bestV = null, bestP = null;
        for (var y4 = 0; y4 < oh; y4++) for (var x4 = 0; x4 < ow; x4++) {
          var sIT = 0, sI = 0, sI2 = 0, sT2 = 0, sTc2 = 0, sITc = 0, wn = [];
          for (var j2 = 0; j2 < 3; j2++) for (var k2 = 0; k2 < 3; k2++) { var iv = src[y4 + j2][x4 + k2], t2 = T[j2][k2]; sIT += iv * t2; sI += iv; sI2 += iv * iv; sT2 += t2 * t2; sTc2 += (t2 - Tm) * (t2 - Tm); sITc += iv * (t2 - Tm); wn.push([y4 + j2, x4 + k2, 'win']); }
          var val, fml;
          if (P.m === 'sqdiff') { val = sI2 - 2 * sIT + sT2; fml = 'Σ(I − T)² = ' + Math.round(val); }
          else if (P.m === 'ccorr_normed') { val = sIT / Math.sqrt(sI2 * sT2); fml = 'Σ I·T / √(ΣI² · ΣT²) = ' + f3(val); }
          else { var varI = Math.max(sI2 - sI * sI / n, 0), den = Math.sqrt(varI * sTc2); val = den > 1e-6 ? sITc / den : 0; fml = 'Σ I·(T−T̄) / √(var·ΣT̃²) = ' + f3(val); }
          val = P.m === 'sqdiff' ? Math.round(val) : Math.round(val * 1000) / 1000;
          Rm[y4][x4] = val;
          var better = bestV === null || (P.m === 'sqdiff' ? val < bestV : val > bestV); if (better) { bestV = val; bestP = [y4, x4]; }
          R.set('R', Rm).clearHl().hl('src', wn).hl('R', [[y4, x4, 'dst']]);
          R.frame('Template placed with its top-left at (' + x4 + ', ' + y4 + ')', fml, { panel: 'R', y: y4, x: x4, answer: val, tol: P.m === 'sqdiff' ? Math.max(5, val * 0.02) : 0.02 });
        }
        var bw = []; for (var j3 = 0; j3 < 3; j3++) for (var k3 = 0; k3 < 3; k3++) bw.push([bestP[0] + j3, bestP[1] + k3, 'ok']);
        R.clearHl().hl('src', bw).hl('R', [[bestP[0], bestP[1], 'ok']]).frame('min_max_loc: best match at (' + bestP[1] + ', ' + bestP[0] + ') — ' + (P.m === 'sqdiff' ? 'the MINIMUM for sqdiff.' : 'the MAXIMUM for correlation scores.') + ' True position was (' + tx + ', ' + ty + ').');
        return { panels: panels2, frames: R.frames };
      }

      /* --- morph (two phase) */
      if (op === 'morph') {
        var ero = function (A, isMax) { return A.map(function (row, y) { return row.map(function (_, x) { var m = isMax ? 0 : 255; for (var dy = -1; dy <= 1; dy++) for (var dx = -1; dx <= 1; dx++) { var yy = y + dy, xx = x + dx; if (yy < 0 || yy >= H || xx < 0 || xx >= W) continue; m = isMax ? Math.max(m, A[yy][xx]) : Math.min(m, A[yy][xx]); } return m; }); }); };
        var sub = function (A, B) { return A.map(function (row, y) { return row.map(function (v, x) { return Math.max(0, v - B[y][x]); }); }); };
        var steps = { open: [['erode', 'src'], ['dilate', 's1']], close: [['dilate', 'src'], ['erode', 's1']], gradient: [['dilate', 'src'], ['erode', 'src'], ['sub', 's1', 's2']], tophat: [['erode', 'src'], ['dilate', 's1'], ['sub', 'src', 's2']], blackhat: [['dilate', 'src'], ['erode', 's1'], ['sub', 's2', 'src']] }[P.op];
        var st = { src: src }, panels3 = [G('src', 'src', 'bin')];
        steps.forEach(function (s, i) { panels3.push(G('s' + (i + 1), (i + 1) + '. ' + (s[0] === 'sub' ? s[1] + ' − ' + s[2] : s[0] + '(' + s[1] + ')'), 'bin')); });
        R.set('src', src); steps.forEach(function (_, i) { R.set('s' + (i + 1), nulls(H, W)); });
        R.frame({ open: 'Opening = erode then dilate: removes specks smaller than the kernel, keeps big shapes.', close: 'Closing = dilate then erode: fills small holes and gaps.', gradient: 'Gradient = dilate − erode: an outline of every shape.', tophat: 'Top-hat = src − open(src): only the small bright details survive.', blackhat: 'Black-hat = close(src) − src: the small dark holes.' }[P.op]);
        steps.forEach(function (s, i) {
          var id = 's' + (i + 1), res = s[0] === 'sub' ? sub(st[s[1]], st[s[2]]) : ero(st[s[1]], s[0] === 'dilate');
          st[id] = res;
          var part = nulls(H, W);
          for (var y5 = 0; y5 < H; y5++) {
            for (var x5 = 0; x5 < W; x5++) part[y5][x5] = res[y5][x5];
            R.set(id, cp(part)).clearHl().hl(id, part[y5].map(function (_, x) { return [y5, x, 'dst']; })).frame('Step ' + (i + 1) + ': ' + s[0] + ' — row ' + y5, null, null);
          }
          var white = 0; res.forEach(function (row) { row.forEach(function (v) { if (v) white++; }); });
          R.clearHl().frame('Step ' + (i + 1) + ' complete.', white + ' white pixels', { answer: white, q: 'How many white pixels after step ' + (i + 1) + '? (count before revealing)' });
        });
        return { panels: panels3, frames: R.frames };
      }

      /* --- generic 3×3 window ops */
      var kern = null, kTitle = '';
      if (op === 'filter') { kern = KERNELS[P.k]; kTitle = P.k + ' kernel'; }
      if (op === 'sobel') { kern = P.dir === 'x' ? [[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]] : [[-1, -2, -1], [0, 0, 0], [1, 2, 1]]; kTitle = 'Sobel ' + P.dir; }
      if (op === 'gauss') {
        var s = +P.s, g1 = s <= 0 ? [0.25, 0.5, 0.25] : (function () { var e = [-1, 0, 1].map(function (x) { return Math.exp(-x * x / (2 * s * s)); }), t = e[0] + e[1] + e[2]; return e.map(function (v) { return v / t; }); })();
        kern = g1.map(function (a) { return g1.map(function (b) { return a * b; }); }); kTitle = 'kernel = g gᵀ';
      }
      var outMode = op === 'sobel' ? 'signed' : (op === 'erode' ? 'bin' : 'gray');
      var srcMode = op === 'erode' ? 'bin' : 'gray';
      var panels4 = [G('src', 'src', srcMode)];
      if (kern) panels4.push(G('k', kTitle, 'float', { cs: 40, cf: 10 }));
      if (op === 'median') panels4.push({ id: 'sort', type: 'list', title: 'sorted window' });
      panels4.push(G('out', op === 'sobel' ? 'gradient (signed int16)' : op === 'erode' ? P.op : 'dst', outMode));
      var out2 = nulls(H, W);
      R.set('src', src).set('out', out2); if (kern) R.set('k', kern.map(function (row) { return row.map(function (v) { return Math.round(v * 1000) / 1000; }); }));
      if (op === 'median') R.set('sort', { items: [] });
      R.frame(op === 'erode' ? (P.op === 'erode' ? 'Erode = minimum over the 3×3 window: a pixel stays white only if all its neighbours are white. Outside pixels are ignored.' : 'Dilate = maximum over the window: any white neighbour makes the pixel white.') : op === 'median' ? 'Salt-and-pepper noise added. A mean would smear it; the median ignores outliers.' : 'At the edge the window hangs outside — reflect_101 mirrors without repeating the edge pixel (… 2 1 | 0 1 2 …).');
      for (var y6 = 0; y6 < H; y6++) for (var x6 = 0; x6 < W; x6++) {
        var wl = [], vals = [], acc = 0, terms = [];
        for (var dy2 = -1; dy2 <= 1; dy2++) for (var dx2 = -1; dx2 <= 1; dx2++) {
          var yy2 = y6 + dy2, xx2 = x6 + dx2, inside = yy2 >= 0 && yy2 < H && xx2 >= 0 && xx2 < W;
          if (op === 'erode') { if (!inside) continue; vals.push(src[yy2][xx2]); wl.push([yy2, xx2, 'win']); continue; }
          var ry = borderIdx(yy2, H, 'reflect_101'), rx = borderIdx(xx2, W, 'reflect_101'), pv = src[ry][rx];
          wl.push([ry, rx, inside ? 'win' : 'dim']); vals.push(pv);
          if (kern) { var kv2 = kern[dy2 + 1][dx2 + 1]; acc += kv2 * pv; if (kv2) terms.push((Math.abs(kv2 - Math.round(kv2)) < 1e-9 ? kv2 : f3(kv2)) + '·' + pv); }
        }
        var val2, fml2;
        if (op === 'erode') { val2 = P.op === 'erode' ? Math.min.apply(null, vals) : Math.max.apply(null, vals); fml2 = P.op + ' → ' + (P.op === 'erode' ? 'min' : 'max') + '(' + vals.map(function (v) { return v ? 1 : 0; }).join('') + ') = ' + (val2 ? 255 : 0); }
        else if (op === 'median') { var so = vals.slice().sort(function (a, b) { return a - b; }); val2 = so[4]; R.set('sort', { items: so, hl: [4] }); fml2 = 'sorted[4] = ' + val2; }
        else if (op === 'sobel') { val2 = Math.round(acc); fml2 = terms.join(' + ') + ' = ' + val2; }
        else { val2 = sat(acc); fml2 = (terms.length > 5 ? terms.slice(0, 5).join(' + ') + ' + …' : terms.join(' + ')) + ' = ' + f2(acc) + ' → ' + val2; }
        out2[y6][x6] = val2;
        R.set('out', out2).clearHl().hl('src', wl.concat([[y6, x6, 'src']])).hl('out', [[y6, x6, 'dst']]);
        R.frame('Window centred on (' + x6 + ', ' + y6 + ')' + (wl.some(function (h) { return h[2] === 'dim'; }) ? ' — dimmed cells are reflected copies' : ''), fml2, { panel: 'out', y: y6, x: x6, answer: val2, tol: op === 'gauss' || op === 'filter' ? 1 : 0, q: op === 'erode' ? 'Output (0 or 255)?' : null });
      }
      R.clearHl().frame(op === 'sobel' ? 'Positive = getting brighter in that direction, negative = darker. Take |value| for display.' : 'Done. This sliding window is exactly what a CNN convolution layer computes (with learned kernels).');
      return { panels: panels4, frames: R.frames };
    };
    return d;
  };

  /* =========================== CANNY */
  K.canny = function () {
    return { title: 'Canny: gradient → NMS → double threshold → hysteresis', params: [
      { id: 'lo', label: 'low', type: 'range', min: 0, max: 400, step: 10, value: 100 }, { id: 'hi', label: 'high', type: 'range', min: 0, max: 800, step: 10, value: 250 }],
      build: function (P, r) {
        var R = new Rec(), H = 8, W = 8, g = zeros(H, W), kind = r.int(0, 1);
        for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) { var on = kind ? x + y * 0.6 > 6 : (x - 3.5) * (x - 3.5) + (y - 3.5) * (y - 3.5) < 7; g[y][x] = sat((on ? 190 : 50) + r.int(-15, 15)); }
        var px = function (yy, xx) { return g[Math.max(0, Math.min(H - 1, yy))][Math.max(0, Math.min(W - 1, xx))]; };
        var gx = zeros(H, W), gy = zeros(H, W), mag = zeros(H, W);
        for (var y1 = 0; y1 < H; y1++) for (var x1 = 0; x1 < W; x1++) {
          gx[y1][x1] = px(y1 - 1, x1 + 1) + 2 * px(y1, x1 + 1) + px(y1 + 1, x1 + 1) - px(y1 - 1, x1 - 1) - 2 * px(y1, x1 - 1) - px(y1 + 1, x1 - 1);
          gy[y1][x1] = px(y1 + 1, x1 - 1) + 2 * px(y1 + 1, x1) + px(y1 + 1, x1 + 1) - px(y1 - 1, x1 - 1) - 2 * px(y1 - 1, x1) - px(y1 - 1, x1 + 1);
          mag[y1][x1] = Math.abs(gx[y1][x1]) + Math.abs(gy[y1][x1]);
        }
        var panels = [G('img', 'gray'), G('mag', '|gx| + |gy|', 'float', { cs: 34, cf: 8.5 }), G('nms', 'after NMS', 'float', { cs: 34, cf: 8.5 }), G('out', 'edges', 'bin', { notext: true })];
        R.set('img', g).set('mag', nulls(H, W)).set('nms', nulls(H, W)).set('out', zeros(H, W));
        R.frame('Stage 1: Sobel x and y with a replicate border, then the L1 magnitude |gx| + |gy| (OpenCV\'s default).');
        var mg = nulls(H, W);
        for (var y2 = 0; y2 < H; y2++) { for (var x2 = 0; x2 < W; x2++) mg[y2][x2] = mag[y2][x2]; R.set('mag', cp(mg)).clearHl().hl('mag', mg[y2].map(function (_, x) { return [y2, x, 'dst']; })).frame('Magnitude row ' + y2, 'e.g. (0,' + y2 + '): |' + gx[y2][0] + '| + |' + gy[y2][0] + '| = ' + mag[y2][0]); }
        var t = Math.tan(Math.PI / 8), keep = zeros(H, W), nm = nulls(H, W);
        var M = function (yy, xx) { return yy < 0 || yy >= H || xx < 0 || xx >= W ? 0 : mag[yy][xx]; };
        R.clearHl().frame('Stage 2: non-maximum suppression. Keep a pixel only if it beats both neighbours along the gradient direction. Thick ridges become 1-pixel lines.');
        var dirName = '';
        for (var y3 = 0; y3 < H; y3++) for (var x3 = 0; x3 < W; x3++) {
          var ax = Math.abs(gx[y3][x3]), ay = Math.abs(gy[y3][x3]), m = mag[y3][x3], n1, n2, ok;
          if (ay <= t * ax) { n1 = [0, -1]; n2 = [0, 1]; dirName = 'horizontal (→)'; }
          else if (ax <= t * ay) { n1 = [-1, 0]; n2 = [1, 0]; dirName = 'vertical (↓)'; }
          else if (gx[y3][x3] * gy[y3][x3] > 0) { n1 = [-1, -1]; n2 = [1, 1]; dirName = 'diagonal (↘)'; }
          else { n1 = [-1, 1]; n2 = [1, -1]; dirName = 'diagonal (↙)'; }
          var a = M(y3 + n1[0], x3 + n1[1]), b = M(y3 + n2[0], x3 + n2[1]);
          ok = m > a && m >= b && m > P.lo; keep[y3][x3] = ok ? 1 : 0; nm[y3][x3] = ok ? m : 0;
          if (m === 0) continue;
          R.set('nms', cp(nm)).clearHl().hl('mag', [[y3, x3, 'src'], [y3 + n1[0], x3 + n1[1], 'win'], [y3 + n2[0], x3 + n2[1], 'win']]).hl('nms', [[y3, x3, ok ? 'ok' : 'bad']]);
          R.frame('(' + x3 + ', ' + y3 + ') gradient is ' + dirName, m + ' vs neighbours ' + a + ', ' + b + (m > P.lo ? '' : '  (and ≤ low=' + P.lo + ')') + ' → ' + (ok ? 'keep' : 'suppress'), { answer: ok ? 1 : 0, q: 'Keep this pixel? (1 = keep, 0 = suppress)' });
        }
        var out = zeros(H, W), stack = [];
        for (var y4 = 0; y4 < H; y4++) for (var x4 = 0; x4 < W; x4++) if (keep[y4][x4] && mag[y4][x4] > P.hi) { out[y4][x4] = 255; stack.push([y4, x4]); }
        R.set('out', cp(out)).clearHl().frame('Stage 3: every kept pixel with magnitude > high (' + P.hi + ') is a strong edge → white immediately.', stack.length + ' strong pixels');
        while (stack.length) {
          var p = stack.pop(), added = [];
          for (var dy = -1; dy <= 1; dy++) for (var dx = -1; dx <= 1; dx++) { var yy = p[0] + dy, xx = p[1] + dx; if (yy >= 0 && yy < H && xx >= 0 && xx < W && keep[yy][xx] && !out[yy][xx]) { out[yy][xx] = 255; stack.push([yy, xx]); added.push([yy, xx, 'ok']); } }
          if (added.length) R.set('out', cp(out)).clearHl().hl('out', [[p[0], p[1], 'src']].concat(added)).frame('Stage 4 hysteresis: weak pixels (low < m ≤ high) touching an edge pixel join it.', added.length + ' pixel(s) promoted');
        }
        R.clearHl().frame('Done. Weak pixels never connected to a strong one are dropped — that is what removes noise without breaking real edges.');
        return { panels: panels, frames: R.frames };
      } };
  };

  /* =========================== CONNECTED COMPONENTS */
  K.flood = function () {
    return { title: 'connectedComponents: raster scan + flood fill', params: [{ id: 'c', label: 'connectivity', type: 'select', options: [8, 4], value: 8 }],
      build: function (P, r) {
        var R = new Rec(), H = 7, W = 8, b = blobs(r, H, W, 4, 1), lab = zeros(H, W), nb = +P.c === 8 ? [[-1, -1], [-1, 0], [-1, 1], [0, -1], [0, 1], [1, -1], [1, 0], [1, 1]] : [[-1, 0], [1, 0], [0, -1], [0, 1]];
        var panels = [G('b', 'binary', 'bin'), G('lab', 'labels', 'label'), { id: 'st', type: 'list', title: 'stack (y,x)' }];
        R.set('b', b).set('lab', cp(lab)).set('st', { items: [] }).frame('Scan in raster order. Each unlabelled white pixel starts a new label and a flood fill (' + P.c + '-connected).');
        var next = 1;
        for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) {
          if (!b[y][x] || lab[y][x]) continue;
          lab[y][x] = next; var stack = [[y, x]];
          R.set('lab', cp(lab)).clearHl().hl('b', [[y, x, 'src']]).set('st', { items: ['(' + y + ',' + x + ')'] }).frame('New seed at (' + x + ', ' + y + ') → label ' + next, null, { panel: 'lab', y: y, x: x, answer: next, q: 'Which label does this new region get?' });
          while (stack.length) {
            var p = stack.pop(), add = [];
            nb.forEach(function (d) { var yy = p[0] + d[0], xx = p[1] + d[1]; if (yy >= 0 && yy < H && xx >= 0 && xx < W && b[yy][xx] && !lab[yy][xx]) { lab[yy][xx] = next; stack.push([yy, xx]); add.push([yy, xx, 'dst']); } });
            R.set('lab', cp(lab)).clearHl().hl('lab', [[p[0], p[1], 'src']].concat(add)).set('st', { items: stack.map(function (q) { return '(' + q + ')'; }) });
            R.frame('Pop (' + p[1] + ', ' + p[0] + '): ' + add.length + ' new neighbour(s) labelled ' + next);
          }
          next++;
        }
        R.clearHl().frame('n = ' + next + ' (including background 0). Try switching to 4-connectivity: diagonal touches no longer join.', 'components = ' + (next - 1));
        return { panels: panels, frames: R.frames };
      } };
  };

  /* =========================== SHOELACE */
  K.shoelace = function () {
    return { title: 'Shoelace formula: area from vertices', params: [{ id: 'n', label: 'vertices', type: 'range', min: 3, max: 7, value: 5 }],
      build: function (P, r) {
        var R = new Rec(), n = P.n, pts = [];
        for (var i = 0; i < n; i++) { var a = i / n * Math.PI * 2 + r() * 0.5, rad = r.int(3, 6); pts.push([Math.round(7 + rad * Math.cos(a)), Math.round(7 + rad * Math.sin(a))]); }
        var terms = [], sum = 0;
        var panels = [{ id: 'cv', type: 'canvas', title: 'polygon (integer vertices)', w: 240, h: 240, draw: function (ctx, d, c) {
          var s = 15; ctx.strokeStyle = c.line; ctx.lineWidth = 0.5; for (var g = 0; g <= 15; g++) { ctx.beginPath(); ctx.moveTo(g * s + 7, 7); ctx.lineTo(g * s + 7, 232); ctx.stroke(); ctx.beginPath(); ctx.moveTo(7, g * s + 7); ctx.lineTo(232, g * s + 7); ctx.stroke(); }
          ctx.fillStyle = 'rgba(232,163,61,0.12)'; ctx.strokeStyle = c.accent; ctx.lineWidth = 2; ctx.beginPath(); pts.forEach(function (p, i) { i ? ctx.lineTo(p[0] * s + 7, p[1] * s + 7) : ctx.moveTo(p[0] * s + 7, p[1] * s + 7); }); ctx.closePath(); ctx.fill(); ctx.stroke();
          if (d && d.k != null) { var p1 = pts[d.k], p2 = pts[(d.k + 1) % n]; ctx.fillStyle = 'rgba(79,163,199,0.3)'; ctx.beginPath(); ctx.moveTo(7, 7); ctx.lineTo(p1[0] * s + 7, p1[1] * s + 7); ctx.lineTo(p2[0] * s + 7, p2[1] * s + 7); ctx.closePath(); ctx.fill(); }
          if (d && d.bb) { ctx.setLineDash([4, 3]); ctx.strokeStyle = c.info; ctx.strokeRect(d.bb[0] * s + 7, d.bb[1] * s + 7, (d.bb[2] - 1) * s, (d.bb[3] - 1) * s); ctx.setLineDash([]); }
          ctx.font = '10px JetBrains Mono, monospace'; pts.forEach(function (p, i) { ctx.fillStyle = c.text; ctx.beginPath(); ctx.arc(p[0] * s + 7, p[1] * s + 7, 3, 0, 7); ctx.fill(); ctx.fillText(i + '(' + p + ')', p[0] * s + 11, p[1] * s + 3); });
        } }, { id: 'kv', type: 'kv', title: 'cross terms xᵢ·yᵢ₊₁ − xᵢ₊₁·yᵢ' }];
        R.set('cv', {}).set('kv', []).frame('Each edge contributes a signed triangle with the origin. Summing them cancels everything outside the polygon.');
        for (var k = 0; k < n; k++) {
          var p1 = pts[k], p2 = pts[(k + 1) % n], t = p1[0] * p2[1] - p2[0] * p1[1]; sum += t;
          terms.push(['edge ' + k + '→' + (k + 1) % n, p1[0] + '·' + p2[1] + ' − ' + p2[0] + '·' + p1[1] + ' = ' + t]);
          R.set('cv', { k: k }).set('kv', cp(terms).concat([['running Σ', String(sum)]])).frame('Edge ' + k + ' → ' + (k + 1) % n, 'term = ' + t, { answer: t, q: 'x' + k + '·y' + ((k + 1) % n) + ' − x' + ((k + 1) % n) + '·y' + k + ' = ?' });
        }
        var area = Math.abs(sum) / 2, xs = pts.map(function (p) { return p[0]; }), ys = pts.map(function (p) { return p[1]; });
        var bb = [Math.min.apply(null, xs), Math.min.apply(null, ys), Math.max.apply(null, xs) - Math.min.apply(null, xs) + 1, Math.max.apply(null, ys) - Math.min.apply(null, ys) + 1];
        R.set('cv', {}).set('kv', cp(terms).concat([['Σ', String(sum)], ['area = |Σ|/2', String(area)]])).frame('Sign tells orientation (in image coordinates, positive = clockwise on screen). contourArea returns |Σ|/2.', 'area = |' + sum + '| / 2 = ' + area, { answer: area, q: 'Polygon area?' });
        R.set('cv', { bb: bb }).frame('boundingRect: min/max of x and y. Width counts pixels, so +1.', 'x=' + bb[0] + ' y=' + bb[1] + ' w=' + bb[2] + ' h=' + bb[3], { answer: bb[2], q: 'boundingRect width (inclusive pixels)?' });
        return { panels: panels, frames: R.frames };
      } };
  };

  /* =========================== MOORE TRACE */
  K.trace = function () {
    var DIRS = [[-1, 0], [-1, -1], [0, -1], [1, -1], [1, 0], [1, 1], [0, 1], [-1, 1]], NAMES = ['W', 'NW', 'N', 'NE', 'E', 'SE', 'S', 'SW'];
    return { title: 'Moore-neighbour tracing (clockwise)', params: [],
      build: function (P, r) {
        var R = new Rec(), H = 7, W = 8, b = zeros(H, W);
        var x0 = r.int(1, 3), y0 = r.int(1, 2), w = r.int(3, 4), h = r.int(3, 4);
        for (var y = y0; y < y0 + h; y++) for (var x = x0; x < x0 + w; x++) b[y][x] = 1;
        for (var k = 0; k < 3; k++) { var yy = r.int(y0, y0 + h - 1), xx = r.int(x0, x0 + w - 1); if (r() < 0.5) b[yy][xx] = 0; else if (xx + 1 < W) b[yy][Math.min(W - 1, x0 + w)] = 1; }
        var fg = function (x, y) { return x >= 0 && x < W && y >= 0 && y < H && b[y][x]; };
        var start = null; for (var y1 = 0; y1 < H && !start; y1++) for (var x1 = 0; x1 < W; x1++) if (b[y1][x1]) { start = [x1, y1]; break; }
        var panels = [G('b', 'binary  (path drawn in amber)', 'bin', { notext: true }), { id: 'kv', type: 'kv', title: 'state' }];
        var path = [];
        var hl = function (c, probe) { var l = path.map(function (p) { return [p[1], p[0], 'ok']; }); l.push([c[1], c[0], 'src']); if (probe) l.push([probe[1], probe[0], 'win']); return l; };
        R.set('b', b).set('kv', [['start', '(' + start + ')']]).hl('b', hl(start)).frame('Start at the first white pixel in raster order. Its west neighbour is background, so the backtrack direction starts at W.');
        var step = function (c, bt, record) {
          for (var k2 = 1; k2 <= 8; k2++) {
            var d = (bt + k2) % 8, n = [c[0] + DIRS[d][0], c[1] + DIRS[d][1]], hit = fg(n[0], n[1]);
            if (record) R.clearHl().hl('b', hl(c, n)).set('kv', [['current', '(' + c + ')'], ['probe', NAMES[d] + ' → (' + n + ')'], ['result', hit ? 'foreground!' : 'background']]).frame('Search clockwise around (' + c + ')', NAMES[d] + ': ' + (hit ? 'white → move there' : 'black'));
            if (hit) { var pd = DIRS[(d + 7) % 8], q = [c[0] + pd[0], c[1] + pd[1]]; var nb = -1; for (var j = 0; j < 8; j++) if (DIRS[j][0] === q[0] - n[0] && DIRS[j][1] === q[1] - n[1]) nb = j; return [n, nb]; }
          }
          return [null, bt];
        };
        path.push(start);
        var s2 = step(start, 0, true); if (!s2[0]) { R.frame('Isolated pixel.'); return { panels: panels, frames: R.frames }; }
        var second = s2[0], c = second, bt = s2[1], guard = 0;
        while (guard++ < 80) {
          var nx = step(c, bt, guard < 4);
          if (c[0] === start[0] && c[1] === start[1] && nx[0] && nx[0][0] === second[0] && nx[0][1] === second[1]) break;
          path.push(c);
          R.clearHl().hl('b', hl(c)).set('kv', [['points', String(path.length)], ['last', '(' + c + ')'], ['backtrack', NAMES[nx[1]] || '-']]).frame(guard < 4 ? 'Move, and restart the search from the last background pixel we saw.' : 'Trace continues (fast mode)…', 'contour += (' + c + ')');
          c = nx[0]; bt = nx[1];
        }
        R.clearHl().hl('b', path.map(function (p) { return [p[1], p[0], 'ok']; })).set('kv', [['points', String(path.length)], ['stop rule', 'back at start, about to repeat 2nd point']]).frame('Closed contour with ' + path.length + ' points — the format cv2.findContours returns (CHAIN_APPROX_NONE).', null, { answer: path.length, q: 'How many points does this contour have?' });
        return { panels: panels, frames: R.frames };
      } };
  };

  /* =========================== DOUGLAS–PEUCKER */
  K.dp = function () {
    return { title: 'approxPolyDP: Douglas–Peucker recursion', params: [{ id: 'eps', label: 'ε', type: 'range', min: 0.5, max: 6, step: 0.5, value: 2 }],
      build: function (P, r) {
        var R = new Rec(), n = 14, pts = [];
        for (var i = 0; i < n; i++) { var t = i / (n - 1); pts.push([Math.round(t * 28 + 1), Math.round(10 + 6 * Math.sin(t * 5 + r() * 0.5) + r.int(-1, 1) + (t > 0.5 ? 4 : 0))]); }
        var keep = [0, n - 1];
        var panels = [{ id: 'cv', type: 'canvas', title: 'polyline (open)', w: 320, h: 200, draw: function (ctx, d, c) {
          var s = 10, X = function (p) { return p[0] * s + 10; }, Y = function (p) { return p[1] * s - 10; };
          ctx.strokeStyle = c.muted; ctx.lineWidth = 1; ctx.beginPath(); pts.forEach(function (p, i) { i ? ctx.lineTo(X(p), Y(p)) : ctx.moveTo(X(p), Y(p)); }); ctx.stroke();
          var K2 = d.keep.slice().sort(function (a, b) { return a - b; }); ctx.strokeStyle = c.accent; ctx.lineWidth = 2; ctx.beginPath(); K2.forEach(function (k, i) { i ? ctx.lineTo(X(pts[k]), Y(pts[k])) : ctx.moveTo(X(pts[k]), Y(pts[k])); }); ctx.stroke();
          if (d.seg) { ctx.strokeStyle = c.info; ctx.setLineDash([5, 4]); ctx.beginPath(); ctx.moveTo(X(pts[d.seg[0]]), Y(pts[d.seg[0]])); ctx.lineTo(X(pts[d.seg[1]]), Y(pts[d.seg[1]])); ctx.stroke(); ctx.setLineDash([]); }
          pts.forEach(function (p, i) { ctx.fillStyle = d.keep.indexOf(i) >= 0 ? c.accent : (d.far === i ? c.bad : c.faint); ctx.beginPath(); ctx.arc(X(p), Y(p), d.far === i ? 5 : 3, 0, 7); ctx.fill(); });
        } }, { id: 'kv', type: 'kv', title: 'state' }];
        R.set('cv', { keep: keep.slice() }).set('kv', [['ε', String(P.eps)]]).frame('Keep the two endpoints. Find the point farthest from the segment between them; if it is farther than ε, keep it and recurse on both halves.');
        var stack = [[0, n - 1]];
        while (stack.length) {
          var seg = stack.pop(), a = pts[seg[0]], b = pts[seg[1]], dx = b[0] - a[0], dy = b[1] - a[1], L = Math.hypot(dx, dy), best = -1, bi = -1;
          for (var j = seg[0] + 1; j < seg[1]; j++) { var dd = Math.abs(dx * (pts[j][1] - a[1]) - dy * (pts[j][0] - a[0])) / L; if (dd > best) { best = dd; bi = j; } }
          if (bi < 0) continue;
          var split = best > P.eps;
          R.set('cv', { keep: keep.slice(), seg: seg, far: bi }).set('kv', [['ε', String(P.eps)], ['segment', seg[0] + ' → ' + seg[1]], ['farthest', 'point ' + bi], ['distance', f3(best)], ['decision', split ? 'keep & split' : 'drop all between']]);
          R.frame('Segment ' + seg[0] + '→' + seg[1], 'd = |dx·(y−y0) − dy·(x−x0)| / L = ' + f3(best) + (split ? ' > ' : ' ≤ ') + 'ε', { answer: split ? 1 : 0, q: 'distance = ' + f3(best) + '. Split here? (1 = yes, 0 = no)' });
          if (split) { keep.push(bi); stack.push([bi, seg[1]]); stack.push([seg[0], bi]); }
        }
        R.set('cv', { keep: keep.slice() }).set('kv', [['ε', String(P.eps)], ['kept', keep.length + ' of ' + n]]).frame('Result: ' + keep.length + ' vertices. For contours, OpenCV uses ε ≈ 1–5 % of arcLength, and a 4-vertex result often means "this is a rectangle".', null, { answer: keep.length, q: 'How many vertices were kept?' });
        return { panels: panels, frames: R.frames };
      } };
  };

  /* =========================== HOUGH */
  K.hough = function () {
    return { title: 'HoughLines: every edge pixel votes for all lines through it', params: [{ id: 'th', label: 'threshold', type: 'range', min: 2, max: 8, value: 4 }],
      build: function (P, r) {
        var R = new Rec(), S = 10, NT = 12, rhoStep = 2, maxR = 14, NR = Math.floor(2 * maxR / rhoStep) + 1;
        var edges = zeros(S, S), pts = [], kind = r.int(0, 2);
        for (var i = 0; i < S; i++) { var p = kind === 0 ? [i, r.int(3, 6)] : kind === 1 ? [r.int(3, 6), i] : [i, i]; if (kind < 2) p = kind === 0 ? [i, 5] : [5, i]; if (r() < 0.6) { edges[p[1]][p[0]] = 255; pts.push(p); } }
        for (var k = 0; k < 3; k++) { var q = [r.int(0, 9), r.int(0, 9)]; if (!edges[q[1]][q[0]]) { edges[q[1]][q[0]] = 255; pts.push(q); } }
        pts.sort(function (a, b) { return a[1] - b[1] || a[0] - b[0]; });
        var acc = zeros(NR, NT);
        var panels = [G('e', 'edge image', 'bin', { notext: true, cs: 22 }), G('acc', 'accumulator (rows ρ ' + (-maxR) + '…' + maxR + ' step 2, cols θ 0°…165°)', 'signed', { cs: 22, cf: 9 })];
        R.set('e', edges).set('acc', cp(acc)).frame('A line is ρ = x·cosθ + y·sinθ. For each edge pixel and each θ, compute ρ and add a vote. Collinear pixels pile votes into the same cell.');
        pts.forEach(function (p, pi) {
          var cells = [];
          for (var t = 0; t < NT; t++) { var th = t * Math.PI / NT, rho = p[0] * Math.cos(th) + p[1] * Math.sin(th), ri = Math.round(rho / rhoStep) + (NR - 1) / 2; if (ri >= 0 && ri < NR) { acc[ri][t]++; cells.push([ri, t, 'dst']); } }
          var th3 = 3 * Math.PI / NT, rh3 = p[0] * Math.cos(th3) + p[1] * Math.sin(th3);
          R.set('acc', cp(acc)).clearHl().hl('e', [[p[1], p[0], 'src']]).hl('acc', cells);
          R.frame('Pixel (' + p + ') votes along a sinusoid', 'e.g. θ=45°: ρ = ' + p[0] + '·cos45° + ' + p[1] + '·sin45° = ' + f2(rh3), pi < 3 ? { answer: Math.round(rh3 * 100) / 100, tol: 0.05, q: 'ρ at θ = 45° for (' + p + ')?' } : null);
        });
        var peaks = [];
        for (var a = 0; a < NR; a++) for (var b = 0; b < NT; b++) { var v = acc[a][b]; var nb = function (y, x) { return y < 0 || y >= NR || x < 0 || x >= NT ? 0 : acc[y][x]; }; if (v > P.th && v > nb(a, b - 1) && v >= nb(a, b + 1) && v > nb(a - 1, b) && v >= nb(a + 1, b)) peaks.push([a, b, 'ok']); }
        R.clearHl().hl('acc', peaks).frame('Peaks: cells with votes > threshold (' + P.th + ') that are local maxima. Each peak = one detected line.', peaks.map(function (p) { return 'ρ=' + ((p[0] - (NR - 1) / 2) * rhoStep) + ', θ=' + (p[1] * 15) + '°'; }).join('   ') || 'no lines above threshold', { answer: peaks.length, q: 'How many lines (peaks) are detected?' });
        return { panels: panels, frames: R.frames };
      } };
  };

  /* =========================== NMS */
  K.nms = function () {
    function iou(a, b) { var x1 = Math.max(a[0], b[0]), y1 = Math.max(a[1], b[1]), x2 = Math.min(a[0] + a[2], b[0] + b[2]), y2 = Math.min(a[1] + a[3], b[1] + b[3]); var i = Math.max(0, x2 - x1) * Math.max(0, y2 - y1); return i / (a[2] * a[3] + b[2] * b[3] - i); }
    return { title: 'NMSBoxes: greedy suppression by IoU', params: [
      { id: 'iou', label: 'IoU thr', type: 'range', min: 0.1, max: 0.9, step: 0.05, value: 0.4 }, { id: 'sc', label: 'score thr', type: 'range', min: 0, max: 0.9, step: 0.05, value: 0.3 }],
      build: function (P, r) {
        var R = new Rec(), boxes = [], objs = [[30, 30], [140, 60], [70, 120]];
        objs.forEach(function (o) { var m = r.int(2, 3); for (var k = 0; k < m; k++) boxes.push({ b: [o[0] + r.int(-12, 12), o[1] + r.int(-10, 10), r.int(55, 75), r.int(45, 60)], s: Math.round((0.35 + r() * 0.6) * 100) / 100 }); });
        boxes.push({ b: [r.int(10, 200), r.int(10, 150), 40, 30], s: 0.2 });
        boxes.forEach(function (b, i) { b.i = i; });
        var panels = [{ id: 'cv', type: 'canvas', title: 'detections', w: 300, h: 220, draw: function (ctx, d, c) {
          boxes.forEach(function (b) { var st = d.state[b.i]; ctx.lineWidth = st === 'keep' ? 2.5 : st === 'cur' ? 2 : 1; ctx.setLineDash(st === 'drop' || st === 'low' ? [4, 3] : []); ctx.strokeStyle = st === 'keep' ? c.ok : st === 'drop' || st === 'low' ? c.faint : st === 'cur' ? c.info : st === 'test' ? c.bad : c.accent; ctx.strokeRect(b.b[0], b.b[1], b.b[2], b.b[3]); ctx.setLineDash([]); ctx.fillStyle = ctx.strokeStyle; ctx.font = '10px JetBrains Mono, monospace'; ctx.fillText('#' + b.i + ' ' + b.s.toFixed(2), b.b[0] + 2, b.b[1] + 11); });
        } }, { id: 'kv', type: 'kv', title: 'queue (by score)' }];
        var state = {}; boxes.forEach(function (b) { state[b.i] = 'cand'; });
        R.set('cv', { state: cp(state) }).set('kv', []).frame('A detector fires several overlapping boxes per object. NMS keeps the best one per object.');
        boxes.forEach(function (b) { if (b.s < P.sc) state[b.i] = 'low'; });
        var order = boxes.filter(function (b) { return b.s >= P.sc; }).sort(function (a, b) { return b.s - a.s; });
        var showQ = function () { return order.filter(function (b) { return state[b.i] === 'cand' || state[b.i] === 'cur'; }).map(function (b) { return ['#' + b.i, b.s.toFixed(2)]; }); };
        R.set('cv', { state: cp(state) }).set('kv', showQ()).frame('1. Drop boxes with score < ' + P.sc + '. 2. Sort the rest by score, highest first.');
        var kept = 0;
        order.forEach(function (b) {
          if (state[b.i] !== 'cand') return;
          state[b.i] = 'cur'; R.set('cv', { state: cp(state) }).set('kv', showQ()).frame('Take the highest remaining: #' + b.i + ' (' + b.s.toFixed(2) + ') → keep it.');
          order.forEach(function (o) {
            if (state[o.i] !== 'cand') return;
            var v = iou(b.b, o.b); if (v <= 0) return;
            state[o.i] = 'test'; R.set('cv', { state: cp(state) }).frame('IoU(#' + b.i + ', #' + o.i + ')', 'IoU = ' + f3(v) + (v > P.iou ? ' > ' : ' ≤ ') + P.iou + ' → ' + (v > P.iou ? 'suppress' : 'keep as candidate'), { answer: v > P.iou ? 1 : 0, q: 'IoU = ' + f3(v) + '. Suppress #' + o.i + '? (1 = yes, 0 = no)' });
            state[o.i] = v > P.iou ? 'drop' : 'cand';
          });
          state[b.i] = 'keep'; kept++; R.set('cv', { state: cp(state) }).set('kv', showQ());
        });
        R.frame('Done: ' + kept + ' box(es) kept (green). cv2.dnn.NMSBoxes returns their indices.', null, { answer: kept, q: 'How many boxes survive?' });
        return { panels: panels, frames: R.frames };
      } };
  };

  /* =========================== PIPELINES */
  K.pipeline = function (op) {
    if (op === 'blob') return { title: 'blobFromImage: HWC uint8 → NCHW float32', params: [
      { id: 'sf', label: 'scalefactor', type: 'select', options: [[1, '1'], [0.00392156862745098, '1/255'], [0.017, '0.017']], value: 0.00392156862745098 },
      { id: 'swap', label: 'swapRB', type: 'select', options: [[1, 'True'], [0, 'False']], value: 1 },
      { id: 'mean', label: 'mean', type: 'select', options: [['0', '(0,0,0)'], ['in', '(104,117,123)'], ['127', '(127.5,127.5,127.5)']], value: '0' }],
      build: function (P, r) {
        var R = new Rec(), H = 2, W = 3, img = randColor(r, H, W), sw = +P.swap, sf = +P.sf;
        var mean = P.mean === 'in' ? [104, 117, 123] : P.mean === '127' ? [127.5, 127.5, 127.5] : [0, 0, 0];
        var sw2 = img.map(function (row) { return row.map(function (v) { return sw ? [v[2], v[1], v[0]] : v.slice(); }); });
        var planes = [nulls(H, W), nulls(H, W), nulls(H, W)], flat = [];
        var panels = [G('img', 'input (B,G,R) HWC', 'color'), G('sw', sw ? 'after swapRB (R,G,B)' : 'channel order (B,G,R)', 'text', { cs: 64, cf: 9 }), G('p0', 'blob[0, 0]', 'float', { cs: 44, cf: 9 }), G('p1', 'blob[0, 1]', 'float', { cs: 44, cf: 9 }), G('p2', 'blob[0, 2]', 'float', { cs: 44, cf: 9 }), { id: 'flat', type: 'list', title: 'memory order (NCHW)' }];
        R.set('img', img).set('sw', sw2.map(function (row) { return row.map(function (v) { return v.join(','); }); })).set('p0', planes[0]).set('p1', planes[1]).set('p2', planes[2]).set('flat', { items: [] });
        R.frame('Networks want planar float tensors: shape (1, 3, H, W). Each value = (pixel − mean[c]) × scalefactor, with mean applied AFTER the swap.', 'mean = (' + mean.join(', ') + '), scale = ' + f3(sf));
        for (var c = 0; c < 3; c++) for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) {
          var pv = sw2[y][x][c], v = Math.round((pv - mean[c]) * sf * 10000) / 10000;
          planes[c][y][x] = v; flat.push(Math.round(v * 1000) / 1000);
          R.set('p' + c, cp(planes[c])).set('flat', { items: flat.slice(), hl: [flat.length - 1] }).clearHl().hl('img', [[y, x, 'src']]).hl('p' + c, [[y, x, 'dst']]);
          R.frame('Channel ' + c + ', pixel (' + x + ', ' + y + ')', '(' + pv + ' − ' + mean[c] + ') × ' + f3(sf) + ' = ' + f3(v), { panel: 'p' + c, y: y, x: x, answer: v, tol: Math.max(0.005, Math.abs(v) * 0.01) });
        }
        R.clearHl().frame('Flat buffer: all of channel 0, then channel 1, then channel 2. That is what "planar" means.');
        return { panels: panels, frames: R.frames };
      } };
    if (op === 'count') return { title: 'Object counter: blur → Otsu → open → label → filter', params: [{ id: 'min', label: 'min area', type: 'range', min: 1, max: 8, value: 3 }],
      build: function (P, r) {
        var R = new Rec(), H = 10, W = 12, img = zeros(H, W);
        for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) img[y][x] = r.int(30, 70);
        var n = r.int(3, 4);
        for (var k = 0; k < n; k++) { var cx = r.int(1, W - 3), cy = r.int(1, H - 3), w = r.int(2, 3), h = r.int(2, 3); for (var yy = cy; yy < Math.min(H, cy + h); yy++) for (var xx = cx; xx < Math.min(W, cx + w); xx++) img[yy][xx] = r.int(180, 230); }
        for (var s = 0; s < 3; s++) img[r.int(0, H - 1)][r.int(0, W - 1)] = 220;
        // blur 3x3 [1 2 1]
        var g = [0.25, 0.5, 0.25], bl = img.map(function (row, y) { return row.map(function (_, x) { var a = 0; for (var dy = -1; dy <= 1; dy++) for (var dx = -1; dx <= 1; dx++) a += g[dy + 1] * g[dx + 1] * img[borderIdx(y + dy, H, 'reflect_101')][borderIdx(x + dx, W, 'reflect_101')]; return sat(a); }); });
        // otsu
        var hist = new Array(256).fill(0); bl.forEach(function (row) { row.forEach(function (v) { hist[v]++; }); });
        var N = H * W, mu = 0; hist.forEach(function (c, i) { mu += i * c / N; });
        var q1 = 0, m1 = 0, best = 0, t = 0; for (var i = 0; i < 256; i++) { var qn = q1 + hist[i] / N, q2 = 1 - qn; if (Math.min(qn, q2) < 1e-7 || Math.max(qn, q2) > 1 - 1e-7) { q1 = qn; continue; } m1 = (m1 * q1 + i * hist[i] / N) / qn; var m2 = (mu - qn * m1) / q2, sb = qn * q2 * (m1 - m2) * (m1 - m2); if (sb > best) { best = sb; t = i; } q1 = qn; }
        var mask = bl.map(function (row) { return row.map(function (v) { return v > t ? 255 : 0; }); });
        var mm = function (A, mx) { return A.map(function (row, y) { return row.map(function (_, x) { var m = mx ? 0 : 255; for (var dy = -1; dy <= 1; dy++) for (var dx = -1; dx <= 1; dx++) { var Y = y + dy, X = x + dx; if (Y < 0 || Y >= H || X < 0 || X >= W) continue; m = mx ? Math.max(m, A[Y][X]) : Math.min(m, A[Y][X]); } return m; }); }); };
        var op2 = mm(mm(mask, false), true);
        var lab = zeros(H, W), nl = 1, areas = [0];
        for (var y2 = 0; y2 < H; y2++) for (var x2 = 0; x2 < W; x2++) { if (!op2[y2][x2] || lab[y2][x2]) continue; var st = [[y2, x2]]; lab[y2][x2] = nl; var a2 = 0; while (st.length) { var p = st.pop(); a2++; for (var dy2 = -1; dy2 <= 1; dy2++) for (var dx2 = -1; dx2 <= 1; dx2++) { var Y2 = p[0] + dy2, X2 = p[1] + dx2; if (Y2 >= 0 && Y2 < H && X2 >= 0 && X2 < W && op2[Y2][X2] && !lab[Y2][X2]) { lab[Y2][X2] = nl; st.push([Y2, X2]); } } } areas.push(a2); nl++; }
        var kept = areas.map(function (a, i) { return i > 0 && a >= P.min; }), count = kept.filter(Boolean).length;
        var fin = lab.map(function (row) { return row.map(function (v) { return kept[v] ? v : 0; }); });
        var panels = [G('img', '1. input', 'gray', { cs: 22, cf: 8 }), G('bl', '2. blurred', 'gray', { cs: 22, cf: 8 }), G('mask', '3. Otsu mask', 'bin', { cs: 22, notext: true }), G('op', '4. opened', 'bin', { cs: 22, notext: true }), G('lab', '5. labels (area ≥ min)', 'label', { cs: 22, cf: 8 }), { id: 'kv', type: 'kv', title: 'measurements' }];
        R.set('img', img).frame('Every classical "count the things" app is this pipeline. Each stage is a function you wrote.');
        R.set('bl', bl).frame('Gaussian blur suppresses pixel noise so the threshold is stable.', 'gaussian_blur(gray, 3, 0)');
        R.set('mask', mask).set('kv', [['Otsu t', String(t)]]).frame('Otsu picks the threshold from the histogram.', 'mask = blurred > ' + t, { answer: t, tol: 3, q: 'Roughly what threshold will Otsu pick? (±3)' });
        R.set('op', op2).frame('Opening (erode → dilate) deletes isolated specks smaller than 3×3.');
        R.set('lab', lab).set('kv', [['Otsu t', String(t)]].concat(areas.slice(1).map(function (a, i) { return ['label ' + (i + 1), 'area ' + a + (a >= P.min ? '' : '  (too small)')]; }))).frame('Connected components + area for each label.');
        R.set('lab', fin).set('kv', [['Otsu t', String(t)], ['count', String(count)]]).frame('Filter by min_area → final count.', 'count = ' + count, { answer: count, q: 'How many objects are counted?' });
        return { panels: panels, frames: R.frames };
      } };
    if (op === 'scan') return { title: 'Document scanner: order corners → homography → warp', params: [],
      build: function (P, r) {
        var R = new Rec(), SH = 10, SW = 10, src = zeros(SH, SW);
        var q = [[r.int(1, 3), r.int(0, 2)], [r.int(7, 9), r.int(1, 3)], [r.int(6, 8), r.int(7, 9)], [r.int(0, 2), r.int(6, 8)]];
        for (var y = 0; y < SH; y++) for (var x = 0; x < SW; x++) src[y][x] = r.int(20, 50);
        var inside = function (x, y) { var s = 0; for (var i = 0; i < 4; i++) { var a = q[i], b = q[(i + 1) % 4]; if ((b[0] - a[0]) * (y - a[1]) - (b[1] - a[1]) * (x - a[0]) < 0) return false; } return true; };
        for (var y1 = 0; y1 < SH; y1++) for (var x1 = 0; x1 < SW; x1++) if (inside(x1, y1)) src[y1][x1] = r.int(200, 240) - (y1 % 3 === 1 && x1 % 2 ? 90 : 0);
        var shuffled = q.slice().sort(function () { return r() - 0.5; });
        var panels = [G('src', 'photo (page = bright quad)', 'gray', { cs: 24, cf: 8 }), { id: 'kv', type: 'kv', title: 'order_corners' }, G('dst', 'scanned 6×8', 'gray', { cs: 24, cf: 8 })];
        R.set('src', src).hl('src', shuffled.map(function (p) { return [p[1], p[0], 'win']; })).set('kv', shuffled.map(function (p, i) { return ['corner ' + i, '(' + p + ')  x+y=' + (p[0] + p[1]) + '  y−x=' + (p[1] - p[0])]; })).set('dst', nulls(8, 6));
        R.frame('approxPolyDP found 4 corners, but in arbitrary order. Sort them with two tricks: x+y and y−x.');
        var by = function (f, mx) { return shuffled.reduce(function (b, p) { return (mx ? f(p) > f(b) : f(p) < f(b)) ? p : b; }); };
        var tl = by(function (p) { return p[0] + p[1]; }), tr = by(function (p) { return p[1] - p[0]; }), br = by(function (p) { return p[0] + p[1]; }, true), bl = by(function (p) { return p[1] - p[0]; }, true);
        var ordered = [tl, tr, br, bl], names = ['TL', 'TR', 'BR', 'BL'], rules = ['min(x+y)', 'min(y−x)', 'max(x+y)', 'max(y−x)'], kv = [];
        ordered.forEach(function (p, i) { kv.push([names[i], '(' + p + ')  ← ' + rules[i]]); R.set('kv', cp(kv)).clearHl().hl('src', [[p[1], p[0], 'ok']]).frame(names[i] + ' = ' + rules[i], '(' + p + ')', { answer: i === 0 || i === 2 ? p[0] + p[1] : p[1] - p[0], q: (i === 0 || i === 2 ? 'x+y' : 'y−x') + ' of the ' + names[i] + ' corner?' }); });
        var DW = 6, DH = 8, Hm = homography([[0, 0], [DW - 1, 0], [DW - 1, DH - 1], [0, DH - 1]], ordered), dst = nulls(DH, DW);
        R.clearHl().frame('perspective_transform(dst_rect → corners) gives the inverse map directly. Now warp_perspective fills the flat page.');
        for (var y2 = 0; y2 < DH; y2++) for (var x2 = 0; x2 < DW; x2++) {
          var X = Hm[0][0] * x2 + Hm[0][1] * y2 + Hm[0][2], Y = Hm[1][0] * x2 + Hm[1][1] * y2 + Hm[1][2], Wd = Hm[2][0] * x2 + Hm[2][1] * y2 + Hm[2][2];
          var bl2 = bilin(src, X / Wd, Y / Wd, SH, SW); dst[y2][x2] = sat(bl2.v);
          R.set('dst', cp(dst)).clearHl().hl('src', [[Math.max(0, Math.min(SH - 1, Math.round(Y / Wd))), Math.max(0, Math.min(SW - 1, Math.round(X / Wd))), 'src']]).hl('dst', [[y2, x2, 'dst']]).frame('dst (' + x2 + ', ' + y2 + ') ← src (' + f2(X / Wd) + ', ' + f2(Y / Wd) + ')');
        }
        R.clearHl().frame('Scanned. At full resolution this is exactly what your scan_document() does — plus the detection steps before it.');
        return { panels: panels, frames: R.frames };
      } };
    return null;
  };

  /* =========================== VIDEO / WEBCAM */
  function videoFrames(r, n, H, W, objs) {
    // tiny synthetic camera: bright square blobs moving over a dark noisy background
    var o = [];
    for (var k = 0; k < objs; k++) o.push({ x: r.int(0, W - 3), y: r.int(0, H - 3), dx: r.int(0, 1) ? 1 : -1, dy: r.int(-1, 1), s: 2, v: r.int(170, 230) });
    var base = zeros(H, W); for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) base[y][x] = r.int(30, 60);
    var out = [];
    for (var t = 0; t < n; t++) {
      var f = cp(base);
      for (var y2 = 0; y2 < H; y2++) for (var x2 = 0; x2 < W; x2++) f[y2][x2] = sat(f[y2][x2] + r.int(-3, 3));
      o.forEach(function (b) {
        if (t > 0) { b.x += b.dx; b.y += b.dy; if (b.x < 0 || b.x > W - b.s) { b.dx = -b.dx; b.x += 2 * b.dx; } if (b.y < 0 || b.y > H - b.s) { b.dy = -b.dy; b.y += 2 * b.dy; } }
        for (var yy = b.y; yy < b.y + b.s; yy++) for (var xx = b.x; xx < b.x + b.s; xx++) if (yy >= 0 && yy < H && xx >= 0 && xx < W) f[yy][xx] = b.v;
      });
      out.push(f);
    }
    return out;
  }
  function absd(a, b) { return a.map(function (row, y) { return row.map(function (v, x) { return Math.abs(v - b[y][x]); }); }); }
  function dil3(A) { var H = A.length, W = A[0].length; return A.map(function (row, y) { return row.map(function (_, x) { var m = 0; for (var dy = -1; dy <= 1; dy++) for (var dx = -1; dx <= 1; dx++) { var Y = y + dy, X = x + dx; if (Y >= 0 && Y < H && X >= 0 && X < W) m = Math.max(m, A[Y][X]); } return m; }); }); }

  K.video = function (op) {
    if (op === 'loop') return { title: 'The capture loop: read → mirror → downscale → show', params: [{ id: 'mir', label: 'mirror', type: 'select', options: [[1, 'True'], [0, 'False']], value: 1 }],
      build: function (P, r) {
        var R = new Rec(), H = 4, W = 8, F = videoFrames(r, 4, H, W, 1), mir = +P.mir, stamps = [], t = 0;
        var panels = [G('cam', 'cap.read() → frame (4×8)', 'gray', { cs: 30, cf: 9 }), G('m', mir ? 'flip(frame, 1)' : 'no mirror', 'gray', { cs: 30, cf: 9 }), G('s', 'resize → 2×4 (bilinear)', 'gray', { cs: 30, cf: 9 }), { id: 'kv', type: 'kv', title: 'loop state' }];
        R.set('cam', nulls(H, W)).set('m', nulls(H, W)).set('s', nulls(2, 4)).set('kv', [['ok', '—'], ['frame #', '—']]);
        R.frame('A video is just a loop: every iteration reads ONE frame and runs your whole pipeline on it.', 'while True: ok, frame = cap.read()');
        for (var i = 0; i < F.length; i++) {
          var f = F[i]; t += 0.033 + r.int(0, 8) / 1000; stamps.push(t);
          var m = mir ? f.map(function (row) { return row.slice().reverse(); }) : cp(f);
          var s = zeros(2, 4);
          for (var y = 0; y < 2; y++) for (var x = 0; x < 4; x++) s[y][x] = rint((m[2 * y][2 * x] + m[2 * y][2 * x + 1] + m[2 * y + 1][2 * x] + m[2 * y + 1][2 * x + 1]) / 4);
          var fps = stamps.length > 1 ? (stamps.length - 1) / (stamps[stamps.length - 1] - stamps[0]) : 0;
          R.set('cam', f).set('m', nulls(H, W)).set('s', nulls(2, 4)).clearHl().set('kv', [['ok', 'True'], ['frame #', String(i)], ['t (s)', f3(t)], ['measured FPS', f2(fps)]]);
          R.frame('Frame ' + i + ' arrives (uint8, BGR on a real camera; gray here).', 'ok, frame = cap.read()');
          R.set('m', m).frame(mir ? 'Mirror: column x moves to column W−1−x, so the preview feels like a mirror.' : 'No mirror: the image stays as the camera sees it, which is what you feed a model.', mir ? "m[y][x] = frame[y][" + (W - 1) + " − x]" : 'm = frame');
          for (var y2 = 0; y2 < 2; y2++) for (var x2 = 0; x2 < 4; x2++) {
            var sub = nulls(2, 4); for (var a = 0; a < 2; a++) for (var b = 0; b < 4; b++) if (a < y2 || (a === y2 && b <= x2)) sub[a][b] = s[a][b];
            R.set('s', sub).clearHl().hl('m', [[2 * y2, 2 * x2, 'src'], [2 * y2, 2 * x2 + 1, 'src'], [2 * y2 + 1, 2 * x2, 'src'], [2 * y2 + 1, 2 * x2 + 1, 'src']]).hl('s', [[y2, x2, 'dst']]);
            var mm = [m[2 * y2][2 * x2], m[2 * y2][2 * x2 + 1], m[2 * y2 + 1][2 * x2], m[2 * y2 + 1][2 * x2 + 1]];
            R.frame('Exactly ½ scale: bilinear samples at (2x + 0.5, 2y + 0.5), which is the average of a 2×2 block.', '(' + mm.join(' + ') + ') / 4 = ' + s[y2][x2], { panel: 's', y: y2, x: x2, answer: s[y2][x2], tol: 1, q: 'Downscaled value? (±1)' });
          }
          R.clearHl().frame('imshow + waitKey(1). Then the loop starts over with the next frame.', 'measured FPS = (n − 1) / (t_last − t_first) = ' + f2(fps));
        }
        R.set('kv', [['ok', 'False'], ['action', 'break → cap.release()']]).frame('When read() returns ok = False (camera unplugged / end of file), leave the loop and release the camera.');
        return { panels: panels, frames: R.frames };
      } };

    if (op === 'diff') return { title: 'Frame differencing: |cur − prev| > thresh', params: [{ id: 't', label: 'thresh', type: 'range', min: 5, max: 120, step: 5, value: 25 }],
      build: function (P, r) {
        var R = new Rec(), H = 5, W = 7, F = videoFrames(r, 2, H, W, 1), a = F[0], b = F[1], d = nulls(H, W), m = nulls(H, W), T = +P.t, cnt = 0;
        var panels = [G('a', 'prev (t−1)', 'gray', { cs: 30, cf: 9 }), G('b', 'cur (t)', 'gray', { cs: 30, cf: 9 }), G('d', 'abs_diff', 'gray', { cs: 30, cf: 9 }), G('m', 'mask (> ' + T + ')', 'bin', { cs: 30, cf: 9 }), { id: 'kv', type: 'kv', title: 'uint8 trap' }];
        R.set('a', a).set('b', b).set('d', d).set('m', m).set('kv', [['10 − 20 (uint8)', '246  ✗'], ['absdiff(10, 20)', '10  ✓']]);
        R.frame('Two consecutive frames. The bright square moved, and the background only flickers a little (sensor noise).');
        for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) {
          var v = Math.abs(b[y][x] - a[y][x]); d[y][x] = v; m[y][x] = v > T ? 255 : 0; if (v > T) cnt++;
          R.set('d', cp(d)).set('m', cp(m)).clearHl().hl('a', [[y, x, 'src']]).hl('b', [[y, x, 'src']]).hl('d', [[y, x, 'dst']]);
          var big = v > T;
          R.frame(big ? 'Big change → moving pixel.' : 'Small change (noise) → ignored.', '|' + b[y][x] + ' − ' + a[y][x] + '| = ' + v + (big ? ' > ' : ' ≤ ') + T, (big || (x + y) % 5 === 0) ? { panel: 'd', y: y, x: x, answer: v, q: '|cur − prev| ?' } : null);
        }
        R.clearHl().set('kv', [['moving pixels', String(cnt)], ['fraction', f3(cnt / (H * W))]]).frame('Both the old AND the new position light up. Raise thresh to see noise disappear; set it too high and the motion disappears too.', 'moving = ' + cnt + ' / ' + (H * W), { answer: cnt, q: 'How many moving pixels are there?' });
        return { panels: panels, frames: R.frames };
      } };

    if (op === 'bg') return { title: 'Running-average background: B ← (1−α)·B + α·I', params: [{ id: 'al', label: 'α', type: 'select', options: [[0.1, '0.1'], [0.3, '0.3'], [0.5, '0.5']], value: 0.3 }, { id: 't', label: 'thresh', type: 'range', min: 10, max: 80, step: 5, value: 30 }],
      build: function (P, r) {
        var R = new Rec(), H = 4, W = 6, al = +P.al, T = +P.t, F = videoFrames(r, 9, H, W, 1), py = 1, px = 2;
        // the object stops after frame 4 (it "sits down"), so you can watch it fade into the background
        for (var i = 5; i < F.length; i++) F[i] = cp(F[4]);
        var B = F[0].map(function (row) { return row.map(Number); }), hist = [], hist2 = [];
        var panels = [G('f', 'frame I', 'gray', { cs: 30, cf: 9 }), G('B', 'background B (float)', 'float', { cs: 30, cf: 8, max: 255 }), G('fg', 'foreground |I − round(B)| > ' + T, 'bin', { cs: 30, cf: 9 }), { id: 'bars', type: 'bars', title: 'one pixel over time: B (amber) vs I' }];
        R.set('f', F[0]).set('B', cp(B)).set('fg', zeros(H, W)).set('bars', { data: [], max: 255 }).frame('Start: B = the first frame, stored as FLOAT so tiny α-updates are not rounded away.', 'acc = frame.astype(np.float32)');
        for (var t = 1; t < F.length; t++) {
          var f = F[t], fg = zeros(H, W);
          for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) fg[y][x] = Math.abs(f[y][x] - sat(B[y][x])) > T ? 255 : 0;
          R.set('f', f).set('fg', fg).clearHl().hl('f', [[py, px, 'src']]).hl('B', [[py, px, 'src']]);
          R.frame('Frame ' + t + (t >= 5 ? ' (the object has stopped moving)' : '') + ': compare with the background first.', 'fg = |I − round(B)| > ' + T);
          var old = B[py][px];
          for (var y2 = 0; y2 < H; y2++) for (var x2 = 0; x2 < W; x2++) B[y2][x2] = (1 - al) * B[y2][x2] + al * f[y2][x2];
          hist.push(Math.round(B[py][px])); hist2.push(f[py][px]);
          var series = []; hist.forEach(function (v, k) { series.push(hist2[k]); series.push(v); });
          R.set('B', cp(B.map(function (row) { return row.map(function (v) { return Math.round(v * 10) / 10; }); }))).set('bars', { data: series, hl: series.map(function (_, k) { return k; }).filter(function (k) { return k % 2 === 1; }), max: 255 }).hl('B', [[py, px, 'dst']]);
          R.frame('Then nudge B towards the frame. α = ' + al + ' → after ~' + Math.round(1 / al) + ' frames B has mostly caught up.', f2(1 - al) + ' × ' + f2(old) + ' + ' + al + ' × ' + f[py][px] + ' = ' + f2(B[py][px]), { panel: 'B', y: py, x: px, answer: Math.round(B[py][px] * 10) / 10, tol: 0.6, q: 'New B at the highlighted pixel? (±0.5)' });
        }
        R.clearHl().frame('A stopped object fades out of the foreground at a rate set by α. Try α = 0.1 versus 0.5 with "New input".');
        return { panels: panels, frames: R.frames };
      } };

    if (op === 'moments') return { title: 'Moments: m00, m10, m01 → centroid → μ20, μ11, μ02', params: [],
      build: function (P, r) {
        var R = new Rec(), H = 6, W = 8, I = zeros(H, W), cx0 = r.int(1, W - 4), cy0 = r.int(0, H - 3), ww = r.int(2, 3), hh = r.int(2, 3);
        for (var y = cy0; y < cy0 + hh; y++) for (var x = cx0; x < cx0 + ww; x++) I[y][x] = 1;
        I[cy0 + hh - 1 < H - 1 ? cy0 + hh : cy0 - 1 >= 0 ? cy0 - 1 : cy0][cx0 + ww - 1] = 1; // a bump so it isn't perfectly symmetric
        var xs = zeros(H, W); for (var y1 = 0; y1 < H; y1++) for (var x1 = 0; x1 < W; x1++) xs[y1][x1] = x1;
        var panels = [G('I', 'mask I (1 = object)', 'bin', { cs: 30, cf: 10 }), { id: 'kv', type: 'kv', title: 'running sums' }];
        var m00 = 0, m10 = 0, m01 = 0;
        R.set('I', I).set('kv', [['m00 = Σ I', '0'], ['m10 = Σ x·I', '0'], ['m01 = Σ y·I', '0']]).frame('Visit every pixel and add its weight (here 0 or 1) times x^p · y^q.', 'm_pq = Σ x^p y^q I(x, y)');
        var asked = 0;
        for (var y2 = 0; y2 < H; y2++) for (var x2 = 0; x2 < W; x2++) {
          if (!I[y2][x2]) continue;
          m00 += 1; m10 += x2; m01 += y2;
          R.set('kv', [['m00 = Σ I', String(m00)], ['m10 = Σ x·I', String(m10)], ['m01 = Σ y·I', String(m01)]]).clearHl().hl('I', [[y2, x2, 'dst']]);
          R.frame('Pixel (' + x2 + ', ' + y2 + ') is on.', 'm10 += ' + x2 + ',  m01 += ' + y2, (asked++ % 2 === 1) ? { answer: m10, q: 'm10 after this pixel?' } : null);
        }
        var cx = m10 / m00, cy = m01 / m00;
        R.clearHl().set('kv', [['m00', String(m00)], ['m10', String(m10)], ['m01', String(m01)], ['cx = m10/m00', f3(cx)], ['cy = m01/m00', f3(cy)]]);
        R.frame('The centroid is the average position, a sub-pixel (float) location.', 'cx = ' + m10 + ' / ' + m00 + ' = ' + f3(cx), { answer: Math.round(cx * 100) / 100, tol: 0.02, q: 'cx = m10 / m00 ? (2 decimals)' });
        var mu20 = 0, mu11 = 0, mu02 = 0;
        for (var y3 = 0; y3 < H; y3++) for (var x3 = 0; x3 < W; x3++) if (I[y3][x3]) { mu20 += (x3 - cx) * (x3 - cx); mu11 += (x3 - cx) * (y3 - cy); mu02 += (y3 - cy) * (y3 - cy); }
        var th = 0.5 * Math.atan2(2 * mu11, mu20 - mu02) * 180 / Math.PI;
        R.set('kv', [['cx, cy', f2(cx) + ', ' + f2(cy)], ['μ20 (spread in x)', f2(mu20)], ['μ02 (spread in y)', f2(mu02)], ['μ11 (tilt)', f2(mu11)], ['θ', f2(th) + '°']]);
        R.frame('Central moments measure spread around the centroid. A wider object has a larger μ20, and μ11 ≠ 0 means it is tilted.', 'θ = ½·atan2(2μ11, μ20 − μ02) = ' + f2(th) + '°');
        R.frame('On a webcam: in_range → moments → centroid on every frame = a colour tracker. Draw the centroid and you are following the object.');
        return { panels: panels, frames: R.frames };
      } };

    if (op === 'motion') return { title: 'Motion detector: diff → dilate → label → boxes', params: [{ id: 'min', label: 'min area', type: 'range', min: 1, max: 20, value: 6 }, { id: 't', label: 'thresh', type: 'range', min: 10, max: 100, step: 5, value: 40 }],
      build: function (P, r) {
        var R = new Rec(), H = 8, W = 10, F = videoFrames(r, 2, H, W, 2), a = F[0], b = F[1], T = +P.t;
        var d = absd(a, b), m = d.map(function (row) { return row.map(function (v) { return v > T ? 255 : 0; }); }), dm = dil3(m);
        var lab = zeros(H, W), nl = 1, boxes = [];
        for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) {
          if (!dm[y][x] || lab[y][x]) continue;
          var st = [[y, x]], area = 0, x0 = x, x1 = x, y0 = y, y1 = y; lab[y][x] = nl;
          while (st.length) { var p = st.pop(); area++; x0 = Math.min(x0, p[1]); x1 = Math.max(x1, p[1]); y0 = Math.min(y0, p[0]); y1 = Math.max(y1, p[0]);
            for (var dy = -1; dy <= 1; dy++) for (var dx = -1; dx <= 1; dx++) { var Y = p[0] + dy, X = p[1] + dx; if (Y >= 0 && Y < H && X >= 0 && X < W && dm[Y][X] && !lab[Y][X]) { lab[Y][X] = nl; st.push([Y, X]); } } }
          boxes.push({ l: nl, x: x0, y: y0, w: x1 - x0 + 1, h: y1 - y0 + 1, area: area }); nl++;
        }
        var panels = [G('b', 'current frame', 'gray', { cs: 24, cf: 8 }), G('m', '1. motion mask', 'bin', { cs: 24, notext: true }), G('dm', '2. dilated', 'bin', { cs: 24, notext: true }), G('lab', '3. labels', 'label', { cs: 24, cf: 8 }), { id: 'kv', type: 'kv', title: 'boxes (x, y, w, h)' }];
        R.set('b', b).set('m', nulls(H, W)).set('dm', nulls(H, W)).set('lab', nulls(H, W)).set('kv', []);
        R.frame('Two objects move between frames. Each stage below is a function you have already written.');
        R.set('m', m).frame('motion_mask: |cur − prev| > ' + T + '. Each object leaves two separate fragments (where it was and where it is).', 'motion_mask(prev, cur, ' + T + ')');
        R.set('dm', dm).frame('Dilate to fuse the fragments of one object into one blob (3×3 here; 5×5 ×2 in the real lesson).', 'dilate(mask, 3)');
        R.set('lab', lab).frame('connected_components gives one label per blob.', 'n = ' + nl + ' (incl. background)', { answer: nl - 1, q: 'How many blobs (not counting the background)?' });
        var kv = [], kept = 0, out = cp(b), hls = [];
        boxes.forEach(function (bx) {
          var ok = bx.area >= P.min;
          kv.push(['label ' + bx.l, '(' + bx.x + ', ' + bx.y + ', ' + bx.w + ', ' + bx.h + ')  area ' + bx.area + (ok ? '' : '  ✗ too small')]);
          var cells = [];
          for (var yy = bx.y; yy < bx.y + bx.h; yy++) for (var xx = bx.x; xx < bx.x + bx.w; xx++) if (yy === bx.y || yy === bx.y + bx.h - 1 || xx === bx.x || xx === bx.x + bx.w - 1) cells.push([yy, xx, ok ? 'ok' : 'bad']);
          if (ok) { kept++; hls = hls.concat(cells); }
          R.set('kv', cp(kv)).clearHl().hl('b', cells).frame('Label ' + bx.l + ': bounding box of its pixels, area = pixel count.', 'w = x_max − x_min + 1 = ' + bx.w, { answer: bx.w, q: 'Box width w (inclusive)?' });
        });
        R.clearHl().hl('b', hls).frame('Keep the boxes with area ≥ ' + P.min + ', then draw them with draw_rect (inclusive corners: x + w − 1).', kept + ' moving object(s)', { answer: kept, q: 'How many boxes survive the min-area filter?' });
        return { panels: panels, frames: R.frames };
      } };
    return null;
  };
})();
