/* mycv — application shell: views, workbench, grading, progress. */
(function () {
  var C = window.CURRICULUM, L = C.lessons, MODS = C.modules;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
  var byId = {}; L.forEach(function (l, i) { l.idx = i; byId[l.id] = l; });
  function icons() { if (window.lucide) lucide.createIcons(); }

  /* ------------------------------------------------------------ progress */
  var KEY = 'mycv-progress-v1';
  var P = { passedCode: {}, drafts: {}, questions: {}, attempted: {}, last: null };
  var store = null;
  try { store = window['local' + 'Storage']; var raw = store && store.getItem(KEY); if (raw) P = Object.assign(P, JSON.parse(raw)); } catch (e) { store = null; }
  var saveT = null;
  function save() { clearTimeout(saveT); saveT = setTimeout(function () { try { if (store) store.setItem(KEY, JSON.stringify(P)); } catch (e) { } }, 250); }
  function isDone(id) { return !!P.passedCode[id]; }
  function isStarted(id) { return !isDone(id) && (P.attempted[id] || Object.keys(P.questions[id] || {}).length > 0); }
  function library(i) { return L.slice(0, i).map(function (l) { return { id: l.id, src: P.passedCode[l.id] || l.solution }; }); }
  function refCount(i) { return L.slice(0, i).filter(function (l) { return !P.passedCode[l.id]; }).length; }

  /* ------------------------------------------------------------ ui helpers */
  var toastT;
  function toast(msg) { var t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(function () { t.classList.remove('show'); }, 2600); }
  function modal(title, bodyHtml, actions, wide) {
    var m = $('#modal'); $('#modalTitle').textContent = title; $('#modalBody').innerHTML = bodyHtml;
    $('.modal-card', m).style.maxWidth = wide ? '820px' : '';
    var a = $('#modalActions'); a.innerHTML = '';
    (actions || [{ label: 'Close' }]).forEach(function (ac) {
      var b = document.createElement('button'); b.className = 'btn ' + (ac.primary ? 'btn-primary' : ''); b.textContent = ac.label;
      b.onclick = function () { if (!ac.keep) closeModal(); if (ac.fn) ac.fn(); }; a.appendChild(b);
    });
    m.hidden = false; var f = $('button', a); if (f) f.focus();
  }
  function closeModal() { $('#modal').hidden = true; }
  $('#modal').addEventListener('click', function (e) { if (e.target.id === 'modal') closeModal(); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !$('#modal').hidden) closeModal(); });

  /* ------------------------------------------------------------ theme */
  var theme = (window.matchMedia && matchMedia('(prefers-color-scheme: light)').matches) ? 'light' : 'dark';
  function applyTheme() {
    document.documentElement.setAttribute('data-theme', theme);
    $('#themeBtn').innerHTML = '<i data-lucide="' + (theme === 'dark' ? 'sun' : 'moon') + '"></i>'; icons();
    if (current.player) current.player.go(current.player.i);
  }
  $('#themeBtn').onclick = function () { theme = theme === 'dark' ? 'light' : 'dark'; applyTheme(); };

  /* ------------------------------------------------------------ python status */
  PY.onStatus(function (state, msg) {
    var el = $('#pyStatus'); el.className = 'py-status ' + state; $('.txt', el).textContent = msg;
    $$('[data-needs-py]').forEach(function (b) { b.disabled = state === 'loading' || state === 'busy'; });
    var rs = $('#runStatus'); if (rs) rs.innerHTML = state === 'busy' || state === 'loading' ? '<span class="spinner"></span>' + esc(msg) : '';
  });

  /* ------------------------------------------------------------ sidebar */
  var openMods = {};
  function renderSidebar() {
    var done = L.filter(function (l) { return isDone(l.id); }).length;
    $('#progText').textContent = done + ' / ' + L.length;
    $('#progFill').style.width = (100 * done / L.length) + '%';
    var cur = current.view === 'lesson' ? current.lesson : null;
    var html = '';
    MODS.forEach(function (m, mi) {
      var ls = L.filter(function (l) { return l.module === m.id; });
      var dn = ls.filter(function (l) { return isDone(l.id); }).length;
      var open = openMods[m.id] != null ? openMods[m.id] : (cur ? cur.module === m.id : mi < 2);
      html += '<div class="mod' + (open ? '' : ' closed') + '" data-mod="' + m.id + '"><button class="mod-head" aria-expanded="' + open + '"><i data-lucide="chevron-down"></i>' + esc(m.title) + '<span class="count">' + dn + '/' + ls.length + '</span></button><div class="mod-lessons">';
      ls.forEach(function (l) {
        var cls = isDone(l.id) ? ' done' : isStarted(l.id) ? ' started' : '';
        if (cur && cur.id === l.id) cls += ' active';
        html += '<button class="lesson-link' + cls + '" data-lesson="' + l.id + '"><span class="lnum">' + (isDone(l.id) ? '✓' : l.idx + 1) + '</span><span>' + esc(l.title) + '</span></button>';
      });
      html += '</div></div>';
    });
    $('#moduleList').innerHTML = html;
    $$('.nav-link').forEach(function (b) { b.classList.toggle('active', b.dataset.view === current.view); });
    icons();
  }
  $('#moduleList').addEventListener('click', function (e) {
    var h = e.target.closest('.mod-head');
    if (h) { var m = h.parentNode; m.classList.toggle('closed'); openMods[m.dataset.mod] = !m.classList.contains('closed'); h.setAttribute('aria-expanded', openMods[m.dataset.mod]); return; }
    var b = e.target.closest('[data-lesson]'); if (b) openLesson(b.dataset.lesson);
  });
  $$('.nav-link').forEach(function (b) { b.onclick = function () { b.dataset.view === 'library' ? showLibrary() : showHome(); }; });
  $('#brandBtn').onclick = showHome;

  /* ------------------------------------------------------------ export / import */
  $('#exportBtn').onclick = function () {
    var blob = new Blob([JSON.stringify(P, null, 1)], { type: 'application/json' });
    var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'mycv-progress.json'; document.body.appendChild(a); a.click(); a.remove();
    toast('Progress exported');
  };
  $('#importFile').onchange = function (e) {
    var f = e.target.files[0]; if (!f) return;
    f.text().then(function (t) {
      var d = JSON.parse(t); if (!d.passedCode) throw new Error('not a mycv progress file');
      P = Object.assign({ passedCode: {}, drafts: {}, questions: {}, attempted: {} }, d); save(); toast('Progress imported'); rerender();
    }).catch(function (err) { toast('Import failed: ' + err.message); });
    e.target.value = '';
  };

  /* ------------------------------------------------------------ mobile tabs */
  $('#mobileTabs').addEventListener('click', function (e) {
    var b = e.target.closest('[data-mtab]'); if (!b) return;
    var t = b.dataset.mtab;
    if (t === 'nav') { document.body.classList.toggle('nav-open'); }
    else { document.body.classList.remove('nav-open'); document.body.classList.toggle('m-code', t === 'code'); if (t === 'code' && current.cm) setTimeout(function () { current.cm.refresh(); }, 30); }
    $$('#mobileTabs button').forEach(function (x) { x.classList.toggle('active', x.dataset.mtab === (t === 'nav' ? (document.body.classList.contains('nav-open') ? 'nav' : (document.body.classList.contains('m-code') ? 'code' : 'learn')) : t)); });
  });
  function closeNav() { document.body.classList.remove('nav-open'); $$('#mobileTabs button').forEach(function (x) { x.classList.toggle('active', x.dataset.mtab === (document.body.classList.contains('m-code') ? 'code' : 'learn')); }); }

  /* ------------------------------------------------------------ state routing */
  var current = { view: 'home' };
  function teardown() { if (current.player) current.player.destroy(); if (window.CAM) CAM.stop(); current = { view: current.view }; }
  function rerender() { if (current.view === 'lesson') openLesson(current.lesson.id, true); else if (current.view === 'library') showLibrary(); else showHome(); }

  /* ------------------------------------------------------------ HOME */
  function nextLesson() { for (var i = 0; i < L.length; i++) if (!isDone(L[i].id)) return L[i]; return L[L.length - 1]; }
  function showHome() {
    teardown(); current.view = 'home'; closeNav(); document.body.classList.remove('m-code');
    var done = L.filter(function (l) { return isDone(l.id); }).length, nx = nextLesson();
    var html = '<div class="page"><div class="page-inner">';
    html += '<section class="home-hero"><div><div class="crumbs">mycv · ' + L.length + ' lessons · ' + MODS.length + ' modules · graded against real OpenCV</div><h1>Build OpenCV yourself, one function at a time.</h1>' +
      '<p>Every lesson asks you to write one OpenCV function from scratch in Python + NumPy — no <code>cv2</code> allowed. Step through an emulator, climb a ladder of questions, then press Grade: your code is compared pixel-for-pixel with the real library. Each function you write becomes part of <b>your own mycv library</b>, and later lessons run on top of it — all the way to an object counter, a document scanner, the pre/post-processing around neural networks, and a real-time motion detector running on your own webcam.</p>' +
      '<div class="hero-actions"><button class="btn btn-primary" id="continueBtn"><i data-lucide="play"></i>' + (done ? 'Continue: ' + esc(nx.title) : 'Start lesson 1') + '</button><button class="btn" id="libBtn"><i data-lucide="library"></i>Your library</button></div></div>' +
      '<div class="how">' + [['Read', 'the concept — short, with the exact OpenCV conventions.'], ['Step', 'through the emulator. Turn on Predict mode and compute values before they appear.'], ['Answer', 'a ladder of questions: Warm-up → Apply → Trace → Challenge.'], ['Write', 'the function. Run it, then Grade it against cv2.'], ['Use', 'it in a real AI example: preprocessing, augmentation, detection post-processing.']].map(function (s, i) { return '<div><span class="n">0' + (i + 1) + '</span><span><b>' + s[0] + '</b> ' + s[1] + '</span></div>'; }).join('') + '</div></section>';
    html += '<div class="panel-title" style="margin-bottom:6px">Library progress — one pixel per function you have written (' + done + '/' + L.length + ')</div><div class="pixel-strip" style="grid-template-columns:repeat(20, 1fr)">' + L.map(function (l) { return '<i title="' + esc(l.title) + '" style="' + (isDone(l.id) ? 'background:var(--accent)' : isStarted(l.id) ? 'background:var(--accent-soft)' : '') + '"></i>'; }).join('') + '</div>';
    html += '<div class="map">';
    MODS.forEach(function (m, mi) {
      var ls = L.filter(function (l) { return l.module === m.id; }), dn = ls.filter(function (l) { return isDone(l.id); }).length;
      html += '<div class="mcard"><div class="mcard-top"><span class="mn">M' + String(mi + 1).padStart(2, '0') + '</span><h3>' + esc(m.title) + '</h3><span class="mp">' + dn + '/' + ls.length + '</span></div><p>' + esc(m.blurb) + '</p><div class="mlessons">';
      ls.forEach(function (l) { html += '<button class="mlesson' + (isDone(l.id) ? ' done' : '') + '" data-lesson="' + l.id + '"><span class="lnum">' + (isDone(l.id) ? '✓' : l.idx + 1) + '</span><span>' + esc(l.title) + '</span><span class="fn">' + esc(l.cv || '') + '</span></button>'; });
      html += '</div></div>';
    });
    html += '</div></div></div>';
    $('#main').innerHTML = html;
    $('#continueBtn').onclick = function () { openLesson(nx.id); };
    $('#libBtn').onclick = showLibrary;
    $('#main').onclick = function (e) { var b = e.target.closest('.mlesson'); if (b) openLesson(b.dataset.lesson); };
    renderSidebar(); $('#main').scrollTop = 0;
  }

  /* ------------------------------------------------------------ LIBRARY */
  function download(text, name) { var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: 'text/x-python' })); a.download = name; document.body.appendChild(a); a.click(); a.remove(); }
  function copyText(text, name) { (navigator.clipboard ? navigator.clipboard.writeText(text) : Promise.reject()).then(function () { toast('Copied ' + name); }, function () { toast('Copy failed — use Download'); }); }
  var WEBCAM_TEMPLATE = "\"\"\"mycv_webcam.py — run YOUR mycv functions on a real webcam.\n\nSetup (once):   pip install opencv-python numpy\nPut this file next to mycv.py (Library page → Download), then:   python mycv_webcam.py\n\ncv2 is used ONLY for the camera and the window (VideoCapture / imshow / waitKey / putText).\nEvery pixel of processing below is your own code from mycv.\nKeys:  1-6 switch mode · m mirror · q quit\n\"\"\"\nimport time\nimport cv2\nimport numpy as np\nimport mycv\n\nWIDTH = 160            # process small frames: pure-NumPy code is slower than cv2's C++\nMODES = {ord(\"1\"): \"raw\", ord(\"2\"): \"gray\", ord(\"3\"): \"edges\",\n         ord(\"4\"): \"motion\", ord(\"5\"): \"background\", ord(\"6\"): \"boxes\"}\n\ncap = cv2.VideoCapture(0)\nif not cap.isOpened():\n    raise SystemExit(\"Cannot open camera (check permissions / another app using it)\")\nmode, mirror, prev, acc, stamps = \"boxes\", True, None, None, []\n\nwhile True:\n    ok, frame = cap.read()\n    if not ok:\n        break\n    small = mycv.preprocess_frame(frame, WIDTH, mirror)          # lesson 41\n    if prev is None:\n        prev, acc = small, small.astype(np.float32)\n    if mode == \"raw\":\n        out = small\n    elif mode == \"gray\":\n        out = mycv.to_gray(small)\n    elif mode == \"edges\":\n        out = mycv.canny(mycv.to_gray(small), 50, 150)\n    elif mode == \"motion\":\n        out = mycv.motion_mask(prev, small)                       # lesson 42\n    elif mode == \"background\":\n        out = mycv.foreground_mask(small, acc, 30)                # lesson 43\n    else:\n        out = small\n        for b in mycv.motion_boxes(prev, small, 25, 60):           # lesson 45\n            out = mycv.draw_rect(out, b, (0, 255, 0), 1)\n    acc = mycv.accumulate_weighted(small, acc, 0.05)\n    prev = small\n    stamps = (stamps + [time.time()])[-30:]\n    big = cv2.resize(out, (out.shape[1] * 4, out.shape[0] * 4), interpolation=cv2.INTER_NEAREST)\n    color = (0, 255, 255) if big.ndim == 3 else 255\n    cv2.putText(big, \"%s  %.1f FPS\" % (mode, mycv.measured_fps(stamps)), (8, 24),\n                cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)\n    cv2.imshow(\"mycv webcam  (1-6 modes, m mirror, q quit)\", big)\n    k = cv2.waitKey(1) & 0xFF\n    if k == ord(\"q\"):\n        break\n    if k == ord(\"m\"):\n        mirror = not mirror\n    if k in MODES:\n        mode = MODES[k]\n\ncap.release()\ncv2.destroyAllWindows()\n";
  function combinedLibrary() {
    var out = ['"""mycv — my own OpenCV, written from scratch.', '', 'Built lesson by lesson at mycv. ' + L.filter(function (l) { return isDone(l.id); }).length + '/' + L.length + ' functions are my own code;', 'the rest are reference solutions (marked below).', '"""', 'import math', 'import numpy as np', ''];
    L.forEach(function (l) {
      out.push('', '# ' + '='.repeat(70), '# Lesson ' + (l.idx + 1) + ': ' + l.title + '   [' + (isDone(l.id) ? 'mine' : 'reference') + ']   ~ ' + (l.cv || ''), '# ' + '='.repeat(70));
      out.push((P.passedCode[l.id] || l.solution).trim(), '');
    });
    return out.join('\n');
  }
  function showLibrary() {
    teardown(); current.view = 'library'; closeNav(); document.body.classList.remove('m-code');
    var rows = L.map(function (l) { return '<tr><td class="mono">' + l.fn.map(function (f) { return '<code>' + esc(f) + '()</code>'; }).join(' ') + '</td><td><button class="btn btn-ghost btn-xs" data-lesson="' + l.id + '">' + (l.idx + 1) + '. ' + esc(l.title) + '</button></td><td>' + (isDone(l.id) ? '<span class="chip ok">yours</span>' : '<span class="chip">reference</span>') + '</td><td class="mono" style="color:var(--faint)">' + esc(l.cv || '') + '</td></tr>'; }).join('');
    $('#main').innerHTML = '<div class="page"><div class="page-inner"><div class="crumbs">mycv · library</div><h1 class="lesson-title">Your library: mycv.py</h1><p style="color:var(--muted);max-width:70ch;margin:0 0 var(--space-6)">Everything you have written, in one file. Download it and <code>import mycv</code> in any Python project — it depends only on NumPy. Functions you have not passed yet are filled with the reference solution so the file always works.</p>' +
      '<div class="lib-layout"><div style="overflow-x:auto"><table class="fn-table"><thead><tr><th>Function</th><th>Lesson</th><th>Source</th><th>OpenCV</th></tr></thead><tbody>' + rows + '</tbody></table></div>' +
      '<div><div class="hero-actions" style="margin-bottom:var(--space-3)"><button class="btn btn-primary btn-sm" id="dlLib"><i data-lucide="download"></i>Download mycv.py</button><button class="btn btn-sm" id="cpLib"><i data-lucide="copy"></i>Copy</button><button class="btn btn-sm" id="dlCam" title="Run your library on a real webcam (cv2 only for capture and the window)"><i data-lucide="video"></i>mycv_webcam.py</button></div><div class="lib-code" id="libCode"></div></div></div></div></div>';
    var src = combinedLibrary();
    var cm = CodeMirror($('#libCode'), { value: src, mode: 'python', theme: 'mycv', readOnly: true, lineNumbers: true });
    setTimeout(function () { cm.refresh(); }, 20);
    $('#dlLib').onclick = function () { download(src, 'mycv.py'); };
    $('#cpLib').onclick = function () { copyText(src, 'mycv.py'); };
    $('#dlCam').onclick = function () { download(WEBCAM_TEMPLATE, 'mycv_webcam.py'); toast('Put it next to mycv.py, then: python mycv_webcam.py'); };
    $('#main').onclick = function (e) { var b = e.target.closest('[data-lesson]'); if (b) openLesson(b.dataset.lesson); };
    renderSidebar(); icons();
  }

  /* ------------------------------------------------------------ LESSON */
  var BASE_TABS = [['solution', 'solution.py', 'starter'], ['playground', 'playground.py', 'playground'], ['ai_example', 'ai_example.py', 'ai_code']], TABS = BASE_TABS;
  function openLesson(id, keepScroll) {
    var l = byId[id]; if (!l) return;
    TABS = l.live ? BASE_TABS.concat([['webcam', 'webcam.py', 'live']]) : BASE_TABS;
    var prevScroll = keepScroll && $('.lesson-col') ? $('.lesson-col').scrollTop : 0;
    teardown(); current.view = 'lesson'; current.lesson = l; P.last = id; save(); closeNav();
    PY.start().catch(function () { });
    var mod = MODS.filter(function (m) { return m.id === l.module; })[0], mi = MODS.indexOf(mod);
    var prev = L[l.idx - 1], next = L[l.idx + 1];
    var nh = (l.hints || []).length;
    var secs = [['concept', 'Concept'], ['emulator', 'Emulator'], ['questions', 'Questions'], ['ai', 'AI in practice'], ['hints', 'Hints']];
    if (l.desktop) secs.push(['desktop', 'On your machine']);
    var html = '<div class="lesson-view"><div class="lesson-col" id="lessonCol"><div class="lesson-inner">';
    html += '<div class="crumbs"><span>M' + String(mi + 1).padStart(2, '0') + ' ' + esc(mod.title) + '</span><span class="sep">/</span><span>Lesson ' + (l.idx + 1) + ' of ' + L.length + '</span></div>';
    html += '<h1 class="lesson-title">' + esc(l.title) + '</h1><div class="meta-row">' + (l.cv ? '<span class="chip accent"><i data-lucide="target"></i>' + esc(l.cv) + '</span>' : '') + '<span class="chip"><i data-lucide="clock"></i>~' + (l.minutes || 20) + ' min</span>' + l.fn.map(function (f) { return '<span class="chip info">' + esc(f) + '()</span>'; }).join('') + (isDone(l.id) ? '<span class="chip ok"><i data-lucide="check"></i>passed</span>' : '') + '</div>';
    html += '<div class="toc">' + secs.map(function (s, i) { return '<button data-sec="' + s[0] + '"><span class="n">' + (i + 1) + '</span>' + s[1] + '</button>'; }).join('') + '<button data-gocode style="margin-left:auto"><span class="n">→</span>Write the code</button></div>';
    html += '<section class="sec" id="sec-concept"><div class="sec-head"><span class="idx">01</span><h2>Concept</h2></div><div class="prose">' + MD.block(l.concept) + '</div></section>';
    html += '<section class="sec" id="sec-emulator"><div class="sec-head"><span class="idx">02</span><h2>Emulator</h2><span class="aside">step · scrub · predict</span></div><div id="emuRoot"></div></section>';
    html += '<section class="sec" id="sec-questions"><div class="sec-head"><span class="idx">03</span><h2>Questions</h2><span class="aside">each unlocks the next</span></div><div id="quizRoot"></div></section>';
    html += '<section class="sec" id="sec-ai"><div class="sec-head"><span class="idx">04</span><h2>AI in practice</h2></div><div class="ai-box"><div class="prose">' + MD.block(l.ai) + '</div><div class="ai-actions"><button class="btn btn-primary btn-sm" id="runAiBtn" data-needs-py><i data-lucide="sparkles"></i>Open &amp; run ai_example.py</button><button class="btn btn-ghost btn-sm" id="viewAiBtn"><i data-lucide="file-code"></i>Just show the code</button></div></div></section>';
    html += '<section class="sec" id="sec-hints"><div class="sec-head"><span class="idx">05</span><h2>Hints</h2><span class="aside">reveal one at a time</span></div><div class="hint-list" id="hintList"></div></section>';
    if (l.desktop) html += '<section class="sec" id="sec-desktop"><div class="sec-head"><span class="idx">06</span><h2>On your machine</h2><span class="aside">real cv2 + your webcam</span></div><div class="prose"><p>The browser can\'t open <code>cv2.VideoCapture</code>, but your computer can. Install OpenCV once with <code>pip install opencv-python numpy</code>, save this script, and run it with <code>python ' + esc(l.id) + '.py</code>. Press <kbd>q</kbd> in the window to quit. To run <b>your own</b> functions instead of cv2\'s, download <code>mycv.py</code> from the Library page into the same folder and <code>import mycv</code>.</p></div><div class="desk-code"><div class="desk-bar"><span class="mono">' + esc(l.id) + '.py</span><span class="spacer"></span><button class="btn btn-ghost btn-sm" id="deskCopy"><i data-lucide="copy"></i>Copy</button><button class="btn btn-ghost btn-sm" id="deskDl"><i data-lucide="download"></i>Download</button></div><div class="lib-code" id="deskView"></div></div></section>';
    html += '<div class="next-row">' + (prev ? '<button class="btn btn-ghost" data-lesson="' + prev.id + '"><i data-lucide="arrow-left"></i>' + esc(prev.title) + '</button>' : '<span></span>') + (next ? '<button class="btn" data-lesson="' + next.id + '">' + esc(next.title) + '<i data-lucide="arrow-right"></i></button>' : '<button class="btn" data-home>Back to the course map</button>') + '</div>';
    html += '</div></div>';
    // bench
    html += '<section class="bench" aria-label="Workbench"><div class="bench-bar">' + TABS.map(function (t, i) { return '<button class="ftab' + (i === 0 ? ' active' : '') + '" data-tab="' + t[0] + '">' + (t[0] === 'ai_example' ? '<i data-lucide="sparkles" style="width:13px;height:13px"></i>' : '') + t[1] + '<span class="dotmod" hidden></span></button>'; }).join('') + '<span class="spacer"></span><button class="icon-btn" id="upBtn" title="Upload your own image" aria-label="Upload your own image"><i data-lucide="image-plus"></i></button><input type="file" id="upFile" accept="image/*" hidden></div>';
    html += '<div class="editor-wrap" id="editorWrap"></div>';
    html += '<div class="run-bar"><button class="btn btn-primary btn-sm" id="runBtn" data-needs-py title="Ctrl+Enter"><i data-lucide="play"></i>Run</button><button class="btn btn-sm" id="gradeBtn" data-needs-py title="Ctrl+Shift+Enter"><i data-lucide="check-check"></i>Grade</button><button class="btn btn-ghost btn-sm" id="resetBtn" title="Reset this file"><i data-lucide="rotate-ccw"></i>Reset</button><button class="btn btn-ghost btn-sm" id="solBtn"><i data-lucide="eye"></i>Solution</button><button class="btn btn-ghost btn-sm" id="stopBtn" title="Stop a runaway loop" hidden><i data-lucide="square"></i>Stop</button>' +
      '<label class="toggle" id="implWrap" hidden title="Which solution.py the example imports">use <select id="implSel"><option value="mine">my solution</option><option value="ref">reference</option></select></label><span id="runStatus" class="run-meta" style="margin:0;display:inline-flex;gap:6px;align-items:center"></span><span class="lib-note" id="libNote"></span></div>';
    html += '<div class="out"><div class="out-tabs"><button class="active" data-out="output"><i data-lucide="terminal" style="width:14px;height:14px"></i>Output</button><button data-out="tests"><i data-lucide="flask-conical" style="width:14px;height:14px"></i>Tests <span class="badge" id="testBadge">—</span></button>' + (l.live ? '<button data-out="camera"><i data-lucide="video" style="width:14px;height:14px"></i>Live camera</button>' : '') + '</div><div class="out-body" id="outBody"></div></div></section></div>';
    $('#main').innerHTML = html;
    $('#main').onclick = null;

    // library note
    var rc = refCount(l.idx);
    $('#libNote').textContent = l.idx === 0 ? 'first lesson — no library yet' : (l.idx - rc) + ' of your functions loaded' + (rc ? ' · reference for ' + rc + ' earlier' : '');
    // emulator
    current.player = EMU.mount($('#emuRoot'), l.emu, l);
    // quiz
    P.questions[l.id] = P.questions[l.id] || {};
    QUIZ.mount($('#quizRoot'), l, P.questions[l.id], function () { save(); renderSidebar(); });
    // hints
    var shown = 0;
    function drawHints() {
      $('#hintList').innerHTML = (l.hints || []).map(function (h, i) {
        return i < shown ? '<div class="hint"><div class="prose">' + MD.block(h) + '</div></div>' : (i === shown ? '<div class="hint locked"><span>Hint ' + (i + 1) + ' of ' + nh + '</span><button class="btn btn-sm" data-hint>Reveal</button></div>' : '<div class="hint locked"><span>Hint ' + (i + 1) + '</span></div>');
      }).join('') || '<div class="hint locked">No hints for this one.</div>';
    }
    drawHints();
    $('#hintList').onclick = function (e) { if (e.target.closest('[data-hint]')) { shown++; drawHints(); } };
    // toc / nav
    $('#lessonCol').addEventListener('click', function (e) {
      var s = e.target.closest('[data-sec]'); if (s) { var t = $('#sec-' + s.dataset.sec); $('#lessonCol').scrollTo({ top: t.offsetTop - 50, behavior: 'smooth' }); return; }
      if (e.target.closest('[data-gocode]')) { if (matchMedia('(max-width: 900px)').matches) $('#mobileTabs [data-mtab=code]').click(); current.cm.focus(); return; }
      var b = e.target.closest('[data-lesson]'); if (b) { openLesson(b.dataset.lesson); return; }
      if (e.target.closest('[data-home]')) showHome();
    });
    setupBench(l);
    if (l.desktop) {
      var dv = CodeMirror($('#deskView'), { value: l.desktop, mode: 'python', theme: 'mycv', readOnly: true, lineNumbers: true, viewportMargin: Infinity });
      setTimeout(function () { dv.refresh(); }, 40);
      $('#deskCopy').onclick = function () { copyText(l.desktop, l.id + '.py'); };
      $('#deskDl').onclick = function () { download(l.desktop, l.id + '.py'); };
    }
    $('#runAiBtn').onclick = function () { switchTab('ai_example'); if (matchMedia('(max-width: 900px)').matches) $('#mobileTabs [data-mtab=code]').click(); doRun(); };
    $('#viewAiBtn').onclick = function () { switchTab('ai_example'); if (matchMedia('(max-width: 900px)').matches) $('#mobileTabs [data-mtab=code]').click(); };
    renderSidebar(); icons();
    $('#lessonCol').scrollTop = prevScroll;
    if (PY.isReady()) $$('[data-needs-py]').forEach(function (b) { b.disabled = false; });
    else $$('[data-needs-py]').forEach(function (b) { b.disabled = true; });
    var rs = $('#runStatus'); if (!PY.isReady()) rs.innerHTML = '<span class="spinner"></span>' + esc($('#pyStatus .txt').textContent);
  }

  /* ------------------------------------------------------------ workbench */
  function setupBench(l) {
    var d = P.drafts[l.id] = P.drafts[l.id] || {};
    var docs = {};
    TABS.forEach(function (t) {
      var init = d[t[0]] != null ? d[t[0]] : (t[0] === 'solution' && P.passedCode[l.id] ? P.passedCode[l.id] : l[t[2]]);
      docs[t[0]] = CodeMirror.Doc(init, 'python');
    });
    current.docs = docs; current.tab = 'solution';
    var cm = CodeMirror($('#editorWrap'), { value: '', mode: 'python', theme: 'mycv', lineNumbers: true, matchBrackets: true, indentUnit: 4, tabSize: 4, indentWithTabs: false, lineWrapping: false,
      extraKeys: { 'Ctrl-Enter': doRun, 'Cmd-Enter': doRun, 'Shift-Ctrl-Enter': doGrade, 'Shift-Cmd-Enter': doGrade, Tab: function (c) { c.somethingSelected() ? c.indentSelection('add') : c.replaceSelection('    ', 'end'); } } });
    cm.swapDoc(docs.solution);
    current.cm = cm;
    setTimeout(function () { cm.refresh(); }, 30);
    var mark = function () { TABS.forEach(function (t) { var orig = l[t[2]]; var b = $('.ftab[data-tab="' + t[0] + '"] .dotmod'); if (b) b.hidden = docs[t[0]].getValue() === orig; }); };
    mark();
    TABS.forEach(function (t) { docs[t[0]].on('change', function () { d[t[0]] = docs[t[0]].getValue(); save(); mark(); clearErrLine(); }); });
    var camT = null;
    if (docs.webcam) docs.webcam.on('change', function () { clearTimeout(camT); camT = setTimeout(function () { if (window.CAM && CAM.isRunning() && current.outTab === 'camera') CAM.restart(); }, 900); });
    $$('.ftab').forEach(function (b) { b.onclick = function () { switchTab(b.dataset.tab); }; });
    $('#runBtn').onclick = doRun; $('#gradeBtn').onclick = doGrade;
    $('#resetBtn').onclick = function () {
      var t = TABS.filter(function (x) { return x[0] === current.tab; })[0];
      modal('Reset ' + t[1] + '?', '<p>This replaces the file with the original ' + (t[0] === 'solution' ? 'starter code' : 'example') + '. Your passed solution (if any) stays saved in your library.</p>', [{ label: 'Cancel' }, { label: 'Reset', primary: true, fn: function () { docs[t[0]].setValue(l[t[2]]); delete d[t[0]]; save(); } }]);
    };
    $('#solBtn').onclick = function () {
      modal('Reference solution', '<p>Peeking is fine — but you will learn far more by trying first. Loading it into the editor replaces your solution.py.</p><div class="lib-code" id="solView" style="height:50vh"></div>', [{ label: 'Close' }, { label: 'Load into solution.py', primary: true, fn: function () { switchTab('solution'); docs.solution.setValue(l.solution); } }], true);
      var v = CodeMirror($('#solView'), { value: l.solution, mode: 'python', theme: 'mycv', readOnly: true, lineNumbers: true }); setTimeout(function () { v.refresh(); }, 20);
    };
    $('#stopBtn').onclick = function () { PY.stop(); toast('Python restarted'); $('#stopBtn').hidden = true; };
    $('#implSel').value = isDone(l.id) ? 'mine' : 'ref';
    $('#upBtn').onclick = function () { $('#upFile').click(); };
    $('#upFile').onchange = function (e) {
      var f = e.target.files[0]; if (!f) return;
      var name = f.name.replace(/[^\w.\-]/g, '_');
      f.arrayBuffer().then(function (buf) { return PY.upload(name, buf); }).then(function () {
        toast('Uploaded — use user_image("' + name + '")');
        switchTab('playground');
        var doc = docs.playground; doc.replaceRange('\n# your uploaded image\nmine = user_image("' + name + '")\nshow(mine, "' + name + '")\n', { line: doc.lastLine() + 1, ch: 0 });
      }).catch(function (err) { toast('Upload failed: ' + err.message); });
      e.target.value = '';
    };
    $$('.out-tabs button').forEach(function (b) { b.onclick = function () { showOut(b.dataset.out); }; });
    current.outs = { output: '<div class="out-empty"><span>Press <b>Run</b> (<kbd>Ctrl</kbd>+<kbd>Enter</kbd>) to execute the open file. <code>print()</code> and <code>show(img, title)</code> appear here.</span><span>Press <b>Grade</b> (<kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>Enter</kbd>) to test <code>solution.py</code> against real OpenCV.</span><span>Sample images: <code>load("fruits.jpg")</code>, <code>load("sudoku.png", gray=True)</code>, … or upload your own with the image button.</span></div>', tests: '<div class="out-empty"><span>No grade yet. Tests compare your function with <code>' + esc(l.cv || 'cv2') + '</code> on several inputs and edge cases.</span></div>' };
    showOut('output');
  }
  function camCode() {
    var l = current.lesson;
    return { library: library(l.idx), solution: $('#implSel').value === 'ref' ? l.solution : current.docs.solution.getValue(), code: current.docs.webcam ? current.docs.webcam.getValue() : l.live, impl: $('#implSel').value };
  }
  function switchTab(t) {
    current.tab = t; current.cm.swapDoc(current.docs[t]);
    $$('.ftab').forEach(function (b) { b.classList.toggle('active', b.dataset.tab === t); });
    $('#implWrap').hidden = t === 'solution';
    $('#runBtn').innerHTML = t === 'webcam' ? '<i data-lucide="video"></i>Run live' : '<i data-lucide="play"></i>Run'; icons();
    $('#gradeBtn').title = t === 'solution' ? 'Ctrl+Shift+Enter' : 'Grades solution.py (Ctrl+Shift+Enter)';
    setTimeout(function () { current.cm.refresh(); current.cm.focus(); }, 0);
  }
  function showOut(which) {
    current.outTab = which;
    $$('.out-tabs button').forEach(function (b) { b.classList.toggle('active', b.dataset.out === which); });
    var ob = $('#outBody');
    if (which === 'camera') { CAM.mount(ob, current.lesson, camCode); icons(); return; }
    if (window.CAM) CAM.stop();
    ob.innerHTML = current.outs[which]; bindImages(ob); icons();
    ob.scrollTop = 0;
  }
  var errMark = null;
  function clearErrLine() { if (errMark != null && current.cm) { try { current.cm.removeLineClass(errMark, 'background', 'cm-error-line'); } catch (e) { } errMark = null; } }
  function markError(err, label) {
    clearErrLine(); if (!err) return;
    var re = new RegExp('File "<' + label.replace('.', '\\.') + '>", line (\\d+)', 'g'), m, last = null;
    while ((m = re.exec(err))) last = +m[1];
    if (last != null && current.cm) { errMark = current.cm.getLineHandle(last - 1); if (errMark) current.cm.addLineClass(errMark, 'background', 'cm-error-line'); }
  }
  var busyTimer = null;
  function busy(on) {
    clearTimeout(busyTimer);
    if (on) busyTimer = setTimeout(function () { var s = $('#stopBtn'); if (s) s.hidden = false; }, 4000);
    else { var s = $('#stopBtn'); if (s) s.hidden = true; }
  }
  function doRun() {
    var l = current.lesson; if (!l) return;
    var tab = current.tab, sol = current.docs.solution.getValue(), extra = '', label = 'solution.py';
    if (tab === 'webcam') { P.attempted[l.id] = true; save(); if (current.outTab === 'camera') CAM.restart(); else showOut('camera'); return; }
    if (tab !== 'solution') { extra = current.docs[tab].getValue(); label = tab + '.py'; if ($('#implSel').value === 'ref') sol = l.solution; }
    P.attempted[l.id] = true; save();
    busy(true);
    PY.run(library(l.idx), sol, extra, label).then(function (r) {
      busy(false);
      var html = '<div class="run-meta">' + esc(label) + (tab !== 'solution' ? ' + ' + ($('#implSel').value === 'ref' ? 'reference' : 'your') + ' solution.py' : '') + ' · ' + r.ms + ' ms</div>';
      if (r.stdout) html += '<pre class="stdout">' + esc(r.stdout) + '</pre>';
      if (r.error) html += '<pre class="stderr">' + esc(r.error) + '</pre>';
      if (r.images && r.images.length) html += imgGrid(r.images);
      if (!r.stdout && !r.error && !(r.images || []).length) html += '<div class="out-empty"><span>Ran without output. Add <code>print(...)</code> or <code>show(img)</code> to see something.</span></div>';
      current.outs.output = html; showOut('output');
      markError(r.error, label === 'solution.py' ? 'solution.py' : label);
      if (r.error && /NotImplementedError/.test(r.error) && tab !== 'solution') toast('Your solution.py is not finished — switch "use" to reference to try the example');
    }).catch(function (e) { busy(false); if (e.message !== 'Stopped') { current.outs.output = '<pre class="stderr">' + esc(e.message) + '</pre>'; showOut('output'); } });
  }
  function doGrade() {
    var l = current.lesson; if (!l) return;
    var sol = current.docs.solution.getValue();
    P.attempted[l.id] = true; save(); renderSidebar();
    busy(true);
    $('#testBadge').className = 'badge'; $('#testBadge').textContent = '…';
    PY.grade(library(l.idx), sol, l.tests, l.banned, l.fn).then(function (r) {
      busy(false);
      var cases = r.cases || [], ok = cases.filter(function (c) { return c.ok === true; }).length, tot = cases.filter(function (c) { return c.ok !== null; }).length;
      var html = '';
      if (r.passed) {
        var first = !P.passedCode[l.id];
        P.passedCode[l.id] = sol; save();
        var nx = L[l.idx + 1];
        html += '<div class="celebrate"><i data-lucide="badge-check" class="big"></i><div><h3>' + esc(l.fn.join(', ')) + ' — matches OpenCV.</h3><p>' + (first ? 'Added to your mycv library. Every later lesson now runs on your code.' : 'Library updated with this version.') + '</p></div>' + (nx ? '<button class="btn btn-primary btn-sm" data-next="' + nx.id + '" style="margin-left:auto">Next lesson<i data-lucide="arrow-right"></i></button>' : '') + '</div>';
        if (first) toast('Lesson passed — ' + l.fn.join(', ') + ' added to your library');
      } else {
        html += '<div class="verdict bad"><i data-lucide="x-circle"></i>' + (r.banned && r.banned.length ? 'Uses something off-limits: ' + esc(r.banned.join(', ')) : r.error && !cases.length ? 'Your code raised an error before the tests ran' : ok + ' / ' + tot + ' tests passed') + '</div>';
      }
      if (r.error && !cases.length) html += '<pre class="stderr">' + esc(r.error) + '</pre>';
      if (r.stdout) html += '<details style="margin-bottom:var(--space-3)"><summary class="run-meta">stdout during tests</summary><pre class="stdout">' + esc(r.stdout) + '</pre></details>';
      cases.forEach(function (c) {
        var cls = c.ok === null ? 'note' : c.ok ? 'ok' : 'bad';
        html += '<div class="case ' + cls + '"><div class="case-head"><span class="ico"><i data-lucide="' + (c.ok === null ? 'info' : c.ok ? 'check' : 'x') + '" style="width:12px;height:12px"></i></span><span>' + esc(c.name) + '</span><span class="ms">' + (c.ms != null ? c.ms + ' ms' : '') + '</span></div>' + (c.msg || (c.images && c.images.length) ? '<div class="case-body">' + (c.msg ? '<div class="msg">' + esc(c.msg) + '</div>' : '') + (c.images && c.images.length ? imgGrid(c.images) : '') + '</div>' : '') + '</div>';
      });
      html += '<div class="run-meta" style="margin-top:var(--space-2)">graded in ' + (r.ms || 0) + ' ms against OpenCV ' + esc((PY.info() || {}).version || '') + '</div>';
      current.outs.tests = html;
      var b = $('#testBadge'); b.textContent = r.passed ? '✓' : ok + '/' + tot; b.className = 'badge ' + (r.passed ? 'ok' : 'bad');
      showOut('tests');
      markError(r.error, 'solution.py');
      renderSidebar();
      var nb = $('[data-next]', $('#outBody')); if (nb) nb.onclick = function () { openLesson(nb.dataset.next); };
    }).catch(function (e) { busy(false); if (e.message !== 'Stopped') { current.outs.tests = '<pre class="stderr">' + esc(e.message) + '</pre>'; showOut('tests'); } });
  }

  /* ------------------------------------------------------------ images + inspector */
  var IMGS = [];
  function imgGrid(list) {
    return '<div class="img-grid">' + list.map(function (im) {
      var k = IMGS.push(im) - 1;
      return '<div class="img-card"><div class="cap"><span>' + esc(im.title || 'image') + '</span><span class="dim">' + esc(im.shape.join('×')) + ' ' + esc(im.dtype) + '</span></div><canvas data-img="' + k + '" width="' + im.w + '" height="' + im.h + '"></canvas></div>';
    }).join('') + '</div>';
  }
  var insp = null;
  function bindImages(root) {
    $$('canvas[data-img]', root).forEach(function (cv) {
      var im = IMGS[+cv.dataset.img]; if (!im) return;
      var maxW = Math.max(120, Math.min(root.clientWidth - 40, 420)), scale = im.w * 2 <= maxW ? Math.floor(maxW / im.w / (im.w < 40 ? 1 : 2)) || 1 : 1;
      scale = Math.max(1, Math.min(scale, Math.floor(260 / Math.max(im.w, im.h)) || 1));
      if (im.w > maxW) scale = maxW / im.w;
      cv.style.width = Math.round(im.w * scale) + 'px'; cv.style.height = Math.round(im.h * scale) + 'px';
      var img = new Image();
      img.onload = function () { var ctx = cv.getContext('2d'); ctx.imageSmoothingEnabled = false; ctx.drawImage(img, 0, 0); };
      img.src = 'data:image/png;base64,' + im.png;
      var raw = null;
      if (im.raw) { var bin = atob(im.raw), buf = new ArrayBuffer(bin.length), u = new Uint8Array(buf); for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); raw = new Float32Array(buf); }
      cv.onmousemove = function (e) {
        var r = cv.getBoundingClientRect(), x = Math.floor((e.clientX - r.left) / r.width * im.w), y = Math.floor((e.clientY - r.top) / r.height * im.h);
        if (x < 0 || y < 0 || x >= im.w || y >= im.h) return;
        var val;
        if (raw) {
          var ch = im.shape.length === 3 ? im.shape[2] : 1, o = (y * im.w + x) * ch, f = function (v) { return Number.isInteger(v) ? v : v.toFixed(3); };
          val = ch === 1 ? f(raw[o]) : '[' + Array.prototype.slice.call(raw, o, o + ch).map(f).join(', ') + ']';
        } else { var p = cv.getContext('2d').getImageData(x, y, 1, 1).data; val = im.shape.length === 3 ? '[' + p[2] + ', ' + p[1] + ', ' + p[0] + '] (display)' : p[0] + ' (display)'; }
        if (!insp) { insp = document.createElement('div'); insp.className = 'inspector'; document.body.appendChild(insp); }
        insp.textContent = 'x=' + x + ' y=' + y + '  ' + val; insp.style.display = 'block';
        insp.style.left = Math.min(window.innerWidth - 220, e.clientX + 14) + 'px'; insp.style.top = (e.clientY + 14) + 'px';
      };
      cv.onmouseleave = function () { if (insp) insp.style.display = 'none'; };
    });
  }

  /* ------------------------------------------------------------ boot */
  document.addEventListener('keydown', function (e) {
    if (current.view !== 'lesson' || !$('#modal').hidden) return;
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter' && !e.target.closest('.CodeMirror')) { e.preventDefault(); e.shiftKey ? doGrade() : doRun(); }
  });
  applyTheme();
  if (P.last && byId[P.last]) showHome(); else showHome();
})();
