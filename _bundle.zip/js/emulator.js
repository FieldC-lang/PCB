/* Generic step-by-step emulator engine.
 * A kind definition: { title, params:[...], random:true, build(params, rng) -> {panels, frames} }
 * Use EMU.Rec to record frames.
 */
(function () {
  function rngFrom(seed) {
    var s = seed >>> 0 || 1;
    var r = function () { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; };
    r.int = function (lo, hi) { return lo + Math.floor(r() * (hi - lo + 1)); };
    r.pick = function (a) { return a[Math.floor(r() * a.length)]; };
    return r;
  }
  function clone(x) { return x == null ? x : JSON.parse(JSON.stringify(x)); }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function css(name) { return getComputedStyle(document.documentElement).getPropertyValue(name).trim(); }

  /* ---------------- recorder */
  function Rec() { this.state = {}; this.hls = {}; this.frames = []; this.maxFrames = 600; }
  Rec.prototype.set = function (id, data) { this.state[id] = data; return this; };
  Rec.prototype.hl = function (id, list) { this.hls[id] = list || []; return this; };
  Rec.prototype.clearHl = function () { this.hls = {}; return this; };
  Rec.prototype.frame = function (note, formula, ask) {
    if (this.frames.length >= this.maxFrames) return this;
    this.frames.push({ s: clone(this.state), h: clone(this.hls), note: note || '', formula: formula || '', ask: ask || null });
    return this;
  };

  /* ---------------- value -> colour helpers */
  function grayCss(v) { v = Math.max(0, Math.min(255, Math.round(v))); return 'rgb(' + v + ',' + v + ',' + v + ')'; }
  function inkFor(v) { return v > 140 ? '#151310' : '#efe9dc'; }
  var LABEL_COLORS = ['#2a2723', '#e8a33d', '#4fa3c7', '#7cc47a', '#d46a6a', '#b48ad8', '#d8c45a', '#5ac7b5', '#e07fb5', '#9aa36a'];
  function divColor(v, m) {
    if (!m) m = 1;
    var t = Math.max(-1, Math.min(1, v / m));
    if (t >= 0) return 'oklch(' + (0.25 + 0.55 * t).toFixed(3) + ' ' + (0.15 * t).toFixed(3) + ' 75)';
    return 'oklch(' + (0.25 + 0.45 * -t).toFixed(3) + ' ' + (0.12 * -t).toFixed(3) + ' 240)';
  }
  function fmt(v, mode) {
    if (v == null) return '';
    if (typeof v === 'number') {
      if (mode === 'float') return Math.abs(v) >= 100 ? v.toFixed(0) : Math.abs(v) >= 10 ? v.toFixed(1) : v.toFixed(2);
      return Number.isInteger(v) ? String(v) : v.toFixed(1);
    }
    return String(v);
  }

  /* ---------------- renderers */
  function renderGrid(p, data, hl, hide) {
    if (!data) return '<div class="panel-title">' + esc(p.title || '') + '</div><div class="out-empty">—</div>';
    var H = data.length, W = H ? data[0].length : 0;
    var cs = p.cs || (p.mode === 'color' ? 42 : W > 12 ? 24 : 30);
    var cf = p.cf || (cs <= 24 ? 9 : p.mode === 'color' ? 9 : 10.5);
    var mx = 1;
    if (p.mode === 'float' || p.mode === 'signed') {
      mx = p.max || 0;
      if (!mx) { for (var a = 0; a < H; a++) for (var b = 0; b < W; b++) if (data[a][b] != null) mx = Math.max(mx, Math.abs(data[a][b])); }
      if (!mx) mx = 1;
    }
    var map = {};
    (hl || []).forEach(function (h) { var k = h[0] + ',' + h[1]; map[k] = (map[k] || '') + ' hl-' + (h[2] || 'src'); });
    var html = '<div class="panel-title">' + esc(p.title || '') + '</div><div class="cells" style="grid-template-columns:repeat(' + W + ', var(--cs));--cs:' + cs + 'px;--cf:' + cf + 'px">';
    for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) {
      var v = data[y][x], cls = 'cell' + (map[y + ',' + x] || ''), style = '', txt = '';
      var hidden = hide && hide.y === y && hide.x === x;
      if (v == null) cls += ' empty';
      else if (p.mode === 'color') {
        style = 'background:rgb(' + v[2] + ',' + v[1] + ',' + v[0] + ');color:' + inkFor(0.299 * v[2] + 0.587 * v[1] + 0.114 * v[0]);
        txt = p.notext ? '' : v[0] + '<br>' + v[1] + '<br>' + v[2];
      } else if (p.mode === 'bin') {
        var on = v > 0; style = 'background:' + (on ? '#ece6d8' : '#24211d') + ';color:' + (on ? '#151310' : '#8a847a');
        txt = p.notext ? '' : (v > 1 ? v : on ? 1 : 0);
      } else if (p.mode === 'label') {
        style = 'background:' + (v ? LABEL_COLORS[1 + (v - 1) % (LABEL_COLORS.length - 1)] : LABEL_COLORS[0]) + ';color:' + (v ? '#151310' : '#6a645a');
        txt = v;
      } else if (p.mode === 'float' || p.mode === 'signed') {
        style = 'background:' + divColor(v, mx) + ';color:#f2ede2'; txt = fmt(v, p.mode === 'float' ? 'float' : 'int');
      } else if (p.mode === 'text') {
        style = 'background:var(--surface-3)'; txt = esc(v);
      } else {
        style = 'background:' + grayCss(v) + ';color:' + inkFor(v); txt = fmt(v);
      }
      if (hidden) { txt = '?'; cls += ' ask'; style += ';background:var(--surface-3);color:var(--accent)'; }
      html += '<div class="' + cls + '" style="' + style + '" title="(' + x + ', ' + y + ')">' + txt + '</div>';
    }
    return html + '</div>';
  }
  function renderBars(p, d) {
    d = d || { data: [] };
    var n = d.data.length, mx = d.max || Math.max.apply(null, d.data.concat([1]));
    var bw = p.bw || Math.max(4, Math.min(18, Math.floor(320 / Math.max(1, n))));
    var hl = d.hl || [], hl2 = d.hl2 || [];
    var html = '<div class="panel-title">' + esc(d.title || p.title || '') + '</div><div class="bars" style="--bw:' + bw + 'px;height:' + (p.h || 120) + 'px">';
    d.data.forEach(function (v, i) {
      html += '<div class="bar' + (hl.indexOf(i) >= 0 ? ' hl' : hl2.indexOf(i) >= 0 ? ' hl2' : '') + '" style="height:' + (100 * Math.max(0, v) / mx).toFixed(1) + '%" title="' + i + ': ' + fmt(v, 'float') + '"></div>';
    });
    html += '</div>';
    if (d.labels) {
      html += '<div class="bar-labels" style="--bw:' + bw + 'px">' + d.labels.map(function (l) { return '<span>' + esc(l) + '</span>'; }).join('') + '</div>';
    }
    return html;
  }
  function renderList(p, d) {
    d = d || { items: [] };
    return '<div class="panel-title">' + esc(d.title || p.title || '') + '</div><div class="list-panel">' +
      d.items.map(function (v, i) { return '<span class="' + ((d.hl || []).indexOf(i) >= 0 ? 'hl' : '') + '">' + esc(fmt(v, 'float')) + '</span>'; }).join('') + '</div>';
  }
  function renderKV(p, d) {
    d = d || [];
    return '<div class="panel-title">' + esc(p.title || '') + '</div><div class="kv">' + d.map(function (r) { return '<span class="k2">' + esc(r[0]) + '</span><span>' + esc(r[1]) + '</span>'; }).join('') + '</div>';
  }
  function renderHex(p, d) {
    d = d || { bytes: [] };
    var html = '<div class="panel-title">' + esc(p.title || '') + '</div><div class="hex">';
    d.bytes.forEach(function (b, i) {
      var c = (i >= d.a && i < d.b) ? 'hl' : (i < d.seen ? 'seen' : '');
      html += '<span class="' + c + '" title="offset ' + i + '">' + (b < 16 ? '0' : '') + b.toString(16).toUpperCase() + '</span>';
    });
    return html + '</div>';
  }

  /* ---------------- player */
  function Player(root, def, opts) {
    this.root = root; this.def = def; this.opts = opts || {};
    this.params = {}; var self = this;
    (def.params || []).forEach(function (p) { self.params[p.id] = p.value; });
    this.seed = 7; this.i = 0; this.playing = false; this.speed = 4; this.predict = false;
    this.streak = 0; this.best = 0; this.answered = {}; this.askCount = 0;
    this.build(); this.mount();
  }
  Player.prototype.build = function () {
    var rng = rngFrom(this.seed * 7919 + 13);
    var out;
    try { out = this.def.build(this.params, rng); }
    catch (e) { console.error(e); out = { panels: [], frames: [{ s: {}, h: {}, note: 'Emulator error: ' + e.message }] }; }
    this.panels = out.panels; this.frames = out.frames.length ? out.frames : [{ s: {}, h: {}, note: '' }];
    this.answered = {}; this.i = 0;
    // which ask frames are actually asked in predict mode
    var k = 0, self = this;
    this.askSet = {};
    this.frames.forEach(function (f, idx) { if (f.ask) { if (k < 3 || k % 3 === 0) self.askSet[idx] = true; k++; } });
  };
  Player.prototype.mount = function () {
    var self = this, d = this.def;
    var params = (d.params || []).map(function (p) {
      if (p.type === 'select') {
        return '<label>' + esc(p.label) + ' <select data-p="' + p.id + '">' + p.options.map(function (o) {
          var v = Array.isArray(o) ? o[0] : o, l = Array.isArray(o) ? o[1] : o;
          return '<option value="' + esc(v) + '"' + (String(v) === String(self.params[p.id]) ? ' selected' : '') + '>' + esc(l) + '</option>';
        }).join('') + '</select></label>';
      }
      return '<label>' + esc(p.label) + ' <input type="range" data-p="' + p.id + '" min="' + p.min + '" max="' + p.max + '" step="' + (p.step || 1) + '" value="' + self.params[p.id] + '"><span class="val" data-v="' + p.id + '">' + self.params[p.id] + '</span></label>';
    }).join('');
    this.root.innerHTML =
      '<div class="emu">' +
      '<div class="emu-top"><span class="emu-title">' + esc(d.title) + '</span>' +
      (d.random !== false ? '<button class="btn btn-xs btn-ghost" data-a="rand" title="New random input"><i data-lucide="shuffle"></i>New input</button>' : '') +
      '<label class="toggle" title="Pause before each value is written and ask you to compute it"><input type="checkbox" data-a="predict">Predict mode</label>' +
      '<span class="streak" data-streak></span></div>' +
      (params ? '<div class="emu-params">' + params + '</div>' : '') +
      '<div class="emu-stage" data-stage></div>' +
      '<div class="emu-note" data-note></div>' +
      '<div class="predict" data-predict hidden></div>' +
      '<div class="emu-controls">' +
      '<button class="icon-btn" data-a="first" aria-label="First step"><i data-lucide="skip-back"></i></button>' +
      '<button class="icon-btn" data-a="prev" aria-label="Previous step"><i data-lucide="step-back"></i></button>' +
      '<button class="btn btn-primary btn-sm" data-a="play" aria-label="Play"><i data-lucide="play"></i><span>Play</span></button>' +
      '<button class="icon-btn" data-a="next" aria-label="Next step"><i data-lucide="step-forward"></i></button>' +
      '<button class="icon-btn" data-a="last" aria-label="Last step"><i data-lucide="skip-forward"></i></button>' +
      '<input type="range" class="emu-scrub" data-a="scrub" min="0" max="0" value="0" aria-label="Scrub steps">' +
      '<span class="step-txt" data-step></span>' +
      '<label class="toggle" style="border:0" title="Speed">speed <input type="range" data-a="speed" min="1" max="30" value="' + this.speed + '"></label>' +
      '</div></div>';
    var q = function (s) { return self.root.querySelector(s); };
    this.el = { stage: q('[data-stage]'), note: q('[data-note]'), step: q('[data-step]'), scrub: q('[data-a=scrub]'), play: q('[data-a=play]'), predict: q('[data-predict]'), streak: q('[data-streak]') };
    this.root.addEventListener('click', function (e) {
      var b = e.target.closest('[data-a]'); if (!b) return;
      var a = b.getAttribute('data-a');
      if (a === 'first') { self.pause(); self.go(0); }
      else if (a === 'prev') { self.pause(); self.go(self.i - 1); }
      else if (a === 'next') { self.pause(); self.advance(); }
      else if (a === 'last') { self.pause(); self.go(self.frames.length - 1); }
      else if (a === 'play') { self.playing ? self.pause() : self.play(); }
      else if (a === 'rand') { self.pause(); self.seed++; self.rebuild(); }
    });
    this.root.addEventListener('input', function (e) {
      var t = e.target;
      if (t.matches('[data-a=scrub]')) { self.pause(); self.go(+t.value); }
      else if (t.matches('[data-a=speed]')) { self.speed = +t.value; if (self.playing) { self.pause(); self.play(); } }
      else if (t.matches('[data-p]')) {
        var id = t.getAttribute('data-p'), p = (self.def.params || []).filter(function (x) { return x.id === id; })[0];
        self.params[id] = p.type === 'select' ? (isNaN(+t.value) || t.value === '' ? t.value : +t.value) : +t.value;
        var v = self.root.querySelector('[data-v="' + id + '"]'); if (v) v.textContent = t.value;
        self.pause(); self.rebuild();
      }
    });
    this.root.addEventListener('change', function (e) {
      if (e.target.matches('[data-a=predict]')) {
        self.predict = e.target.checked; e.target.parentNode.classList.toggle('on', self.predict);
        self.pause(); self.go(0); self.updateStreak();
      }
    });
    if (window.lucide) lucide.createIcons({ attrs: {}, nameAttr: 'data-lucide' });
    this.rebuild();
  };
  Player.prototype.rebuild = function () { this.build(); this.el.scrub.max = this.frames.length - 1; this.go(0); };
  Player.prototype.needsAsk = function (idx) { return this.predict && this.askSet[idx] && !this.answered[idx]; };
  Player.prototype.advance = function () {
    if (this.pendingAsk != null) return false;
    var n = this.i + 1;
    if (n >= this.frames.length) return false;
    if (this.needsAsk(n)) { this.showAsk(n); return false; }
    this.go(n); return true;
  };
  Player.prototype.go = function (i) {
    i = Math.max(0, Math.min(this.frames.length - 1, i));
    this.i = i; this.pendingAsk = null; this.el.predict.hidden = true;
    this.render(this.frames[i], null);
    this.el.scrub.value = i;
    this.el.step.textContent = 'step ' + (i + 1) + '/' + this.frames.length;
  };
  Player.prototype.showAsk = function (n) {
    var self = this, f = this.frames[n];
    this.pause();
    this.pendingAsk = n; this.i = n;
    this.render(f, f.ask);
    this.el.scrub.value = n;
    this.el.step.textContent = 'step ' + (n + 1) + '/' + this.frames.length;
    var P = this.el.predict;
    P.hidden = false;
    P.innerHTML = '<span>' + (f.ask.q || 'Predict the highlighted value:') + '</span><input type="text" inputmode="decimal" aria-label="Your prediction"><button class="btn btn-primary btn-sm">Check</button><button class="btn btn-ghost btn-sm" data-skip>Reveal</button><span class="res"></span>';
    var inp = P.querySelector('input'); inp.focus({ preventScroll: true });
    var done = function (ok, revealed) {
      self.answered[n] = true; self.pendingAsk = null;
      if (ok) { self.streak++; self.best = Math.max(self.best, self.streak); } else self.streak = 0;
      self.updateStreak();
      self.render(f, null);
      var ans = f.ask.answer;
      P.innerHTML = '<span class="res ' + (ok ? 'ok' : 'bad') + '">' + (ok ? '✓ Correct' : revealed ? 'Answer' : '✗ Not quite') + ': ' + esc(fmt(ans, 'float')) + '</span><button class="btn btn-sm" data-cont>Continue</button>';
      P.querySelector('[data-cont]').onclick = function () { P.hidden = true; self.advance(); };
      P.querySelector('[data-cont]').focus({ preventScroll: true });
    };
    var check = function () {
      var raw = inp.value.trim(); if (!raw) return;
      var v = parseFloat(raw), a = f.ask.answer, tol = f.ask.tol != null ? f.ask.tol : (Number.isInteger(a) ? 0 : 0.01 + Math.abs(a) * 0.01);
      done(Math.abs(v - a) <= tol + 1e-9, false);
    };
    P.querySelector('.btn-primary').onclick = check;
    inp.onkeydown = function (e) { if (e.key === 'Enter') check(); };
    P.querySelector('[data-skip]').onclick = function () { done(false, true); };
  };
  Player.prototype.updateStreak = function () {
    this.el.streak.textContent = this.predict ? 'streak ' + this.streak + ' · best ' + this.best : '';
  };
  Player.prototype.play = function () {
    var self = this;
    if (this.i >= this.frames.length - 1) this.go(0);
    this.playing = true;
    this.el.play.innerHTML = '<i data-lucide="pause"></i><span>Pause</span>';
    if (window.lucide) lucide.createIcons();
    this.timer = setInterval(function () { if (!self.advance()) self.pause(); }, 1000 / this.speed);
  };
  Player.prototype.pause = function () {
    if (!this.playing) return;
    this.playing = false; clearInterval(this.timer);
    this.el.play.innerHTML = '<i data-lucide="play"></i><span>Play</span>';
    if (window.lucide) lucide.createIcons();
  };
  Player.prototype.destroy = function () { this.pause(); };
  Player.prototype.render = function (f, ask) {
    var html = '', self = this;
    this.panels.forEach(function (p) {
      var data = f.s[p.id], hl = f.h[p.id];
      var hide = ask && ask.panel === p.id ? ask : null;
      html += '<div class="panel" data-panel="' + p.id + '">';
      if (p.type === 'grid') html += renderGrid(p, data, hl, hide);
      else if (p.type === 'bars') html += renderBars(p, data);
      else if (p.type === 'list') html += renderList(p, data);
      else if (p.type === 'kv') html += renderKV(p, data);
      else if (p.type === 'hex') html += renderHex(p, data);
      else if (p.type === 'canvas') html += '<div class="panel-title">' + esc(p.title || '') + '</div><canvas class="emu-canvas" width="' + p.w * 2 + '" height="' + p.h * 2 + '" style="width:' + p.w + 'px;height:' + p.h + 'px"></canvas>';
      html += '</div>';
    });
    this.el.stage.innerHTML = html;
    this.panels.forEach(function (p) {
      if (p.type !== 'canvas') return;
      var c = self.el.stage.querySelector('[data-panel="' + p.id + '"] canvas');
      var ctx = c.getContext('2d'); ctx.scale(2, 2);
      try { p.draw(ctx, f.s[p.id], { accent: css('--accent'), info: css('--info'), ok: css('--ok'), bad: css('--bad'), text: css('--text'), muted: css('--muted'), faint: css('--faint'), line: css('--line-strong'), bg: css('--bg'), w: p.w, h: p.h }); }
      catch (e) { console.error(e); }
    });
    var note = f.note ? '<p>' + f.note + '</p>' : '';
    var formula = (!ask && f.formula) ? '<div class="formula">' + esc(f.formula) + '</div>' : (ask ? '<div class="formula">…</div>' : '');
    this.el.note.innerHTML = note + formula;
  };

  window.EMU = { Rec: Rec, Player: Player, rng: rngFrom, kinds: {}, esc: esc, fmt: fmt,
    mount: function (root, emuSpec, lesson) {
      var kind = window.EMU.kinds[emuSpec.kind];
      if (!kind) { root.innerHTML = '<div class="out-empty">No emulator for this lesson.</div>'; return null; }
      var def = typeof kind === 'function' ? kind(emuSpec.op, lesson) : kind;
      if (!def) { root.innerHTML = '<div class="out-empty">No emulator for this lesson.</div>'; return null; }
      return new Player(root, def);
    } };
})();
