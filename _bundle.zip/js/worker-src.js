/* Source of the Pyodide web worker. Created from a Blob so it works from opaque-origin iframes. */
(function () {
  function workerMain() {
    var PYODIDE = 'https://cdn.jsdelivr.net/pyodide/v0.28.3/full/';
    var py = null;
    var grader = null;
    function post(m) { self.postMessage(m); }
    async function writeImage(name, bytes) {
      var parts = name.split('/');
      var dir = '/imgs';
      for (var i = 0; i < parts.length - 1; i++) {
        dir += '/' + parts[i];
        try { py.FS.mkdir(dir); } catch (e) { /* exists */ }
      }
      py.FS.writeFile('/imgs/' + name, new Uint8Array(bytes));
    }
    async function init(m) {
      post({ type: 'status', state: 'loading', msg: 'Downloading Python runtime…' });
      importScripts(PYODIDE + 'pyodide.js');
      py = await loadPyodide({ indexURL: PYODIDE });
      post({ type: 'status', state: 'loading', msg: 'Loading NumPy + OpenCV (grader only)…' });
      await py.loadPackage(['numpy', 'opencv-python'], { messageCallback: function () {} });
      try { py.FS.mkdir('/imgs'); } catch (e) {}
      post({ type: 'status', state: 'loading', msg: 'Fetching sample images…' });
      var missing = [];
      await Promise.all(m.images.map(async function (im) {
        try {
          var r = await fetch(im.url);
          if (!r.ok) throw new Error(r.status);
          await writeImage(im.name, await r.arrayBuffer());
        } catch (e) { missing.push(im.name); }
      }));
      if (missing.length) {
        post({ type: 'need_images', names: missing });
        return; // main thread will send 'images' then 'finish'
      }
      finish(m.grader);
    }
    function finish(src) {
      py.globals.set('GRADER_SRC', src);
      py.runPython([
        'import sys, types',
        'grader = types.ModuleType("grader")',
        'exec(compile(GRADER_SRC, "grader.py", "exec"), grader.__dict__)',
        'sys.modules["grader"] = grader'
      ].join('\n'));
      grader = py.pyimport('grader');
      var hasDnn = py.runPython('import cv2\nhasattr(cv2, "dnn") and hasattr(cv2.dnn, "NMSBoxes")');
      post({ type: 'ready', version: py.runPython('import cv2, numpy\ncv2.__version__ + " / numpy " + numpy.__version__'), dnn: !!hasDnn });
    }
    var pendingGrader = null;
    self.onmessage = async function (e) {
      var m = e.data;
      try {
        if (m.type === 'init') { pendingGrader = m.grader; await init(m); }
        else if (m.type === 'images') {
          for (var i = 0; i < m.items.length; i++) await writeImage(m.items[i].name, m.items[i].bytes);
          finish(pendingGrader);
        }
        else if (m.type === 'upload') { await writeImage('user/' + m.name, m.bytes); post({ type: 'uploaded', id: m.id, name: m.name }); }
        else if (m.type === 'run') {
          var out = grader.run(m.library, m.solution, m.extra || '', m.label || 'playground.py');
          post({ type: 'result', id: m.id, json: out });
        }
        else if (m.type === 'live_setup') {
          post({ type: 'result', id: m.id, json: grader.live_setup(m.library, m.solution, m.code) });
        }
        else if (m.type === 'live_frame') {
          var r = grader.live_frame(m.bytes, m.h, m.w);
          var j = r.toJs(); r.destroy();
          var px = j[0] instanceof Uint8Array ? j[0] : new Uint8Array(j[0] || []);
          var copy = new Uint8Array(px);
          self.postMessage({ type: 'frame', id: m.id, bytes: copy.buffer, h: j[1], w: j[2], text: j[3], error: j[4], ms: j[5] }, [copy.buffer]);
        }
        else if (m.type === 'grade') {
          var out2 = grader.grade(m.library, m.solution, m.tests, m.banned, m.fns);
          post({ type: 'result', id: m.id, json: out2 });
        }
      } catch (err) {
        post({ type: 'error', id: m.id, msg: String(err && err.message || err) });
      }
    };
  }
  window.WORKER_SRC = '(' + workerMain.toString() + ')();';
})();
