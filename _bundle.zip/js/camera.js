/* Live camera panel: webcam / simulated camera / video file → process(frame) in Python → canvas.
   Backpressure: a new frame is only sent after the previous result came back. */
(function () {
  var S = { running: false, root: null, getCode: null, src: 'sim', res: 160, stream: null, video: null, cap: null, raf: 0, pending: false,
    t0: 0, frames: 0, fpsT: 0, fpsN: 0, fps: 0, ms: 0, sim: null, fileUrl: null, gen: 0, lessonId: null, err: null };
  var pref = { src: 'sim', res: 160 };

  function $(s, r) { return (r || document).querySelector(s); }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  /* ---------- simulated camera: coloured balls over a textured background (mirrors sim_video) */
  function makeSim() {
    var balls = [
      { x: 60, y: 50, vx: 2.6, vy: 1.7, r: 26, c: 'rgb(230,40,40)' },
      { x: 200, y: 140, vx: -2.1, vy: 2.3, r: 20, c: 'rgb(60,200,40)' },
      { x: 250, y: 60, vx: 1.6, vy: -2.4, r: 17, c: 'rgb(30,120,230)' }
    ];
    var bg = document.createElement('canvas'); bg.width = 320; bg.height = 240;
    var g = bg.getContext('2d'), id = g.createImageData(320, 240);
    for (var y = 0; y < 240; y++) for (var x = 0; x < 320; x++) {
      var o = (y * 320 + x) * 4;
      id.data[o] = 60 + 20 * Math.sin((x + y) / 23); id.data[o + 1] = 80 + 25 * Math.cos(y / 13); id.data[o + 2] = 70 + 30 * Math.sin(x / 17); id.data[o + 3] = 255;
    }
    g.putImageData(id, 0, 0);
    g.fillStyle = 'rgba(255,255,255,.08)'; g.fillRect(20, 150, 90, 70); g.fillRect(230, 20, 70, 40);
    return { balls: balls, bg: bg, t: 0, paused: false };
  }
  function drawSim(ctx, w, h) {
    var s = S.sim; s.t++;
    ctx.drawImage(s.bg, 0, 0, w, h);
    var k = w / 320;
    s.balls.forEach(function (b, i) {
      // ball 0 pauses every few seconds — shows the difference between frame-diff and background models
      var still = i === 0 && (s.t % 240) > 170;
      if (!still) {
        b.x += b.vx; b.y += b.vy;
        if (b.x < b.r || b.x > 320 - b.r) { b.vx = -b.vx; b.x = Math.max(b.r, Math.min(320 - b.r, b.x)); }
        if (b.y < b.r || b.y > 240 - b.r) { b.vy = -b.vy; b.y = Math.max(b.r, Math.min(240 - b.r, b.y)); }
      }
      ctx.fillStyle = b.c; ctx.beginPath(); ctx.arc(b.x * k, b.y * k, b.r * k, 0, Math.PI * 2); ctx.fill();
    });
  }

  /* ---------- UI */
  function html() {
    return '<div class="cam">' +
      '<div class="cam-ctrl">' +
      '<label class="toggle">source <select id="camSrc"><option value="sim">Simulated camera</option><option value="webcam">My webcam</option><option value="file">Video file…</option></select></label>' +
      '<label class="toggle">width <select id="camRes"><option value="80">80 px</option><option value="160">160 px</option><option value="320">320 px</option></select></label>' +
      '<button class="btn btn-primary btn-sm" id="camGo"><i data-lucide="play"></i>Start</button>' +
      '<input type="file" id="camFile" accept="video/*" hidden>' +
      '<span class="cam-stats mono" id="camStats">stopped</span></div>' +
      '<div class="cam-views"><figure><figcaption>camera frame <span class="dim" id="camInDim"></span></figcaption><canvas id="camIn" width="160" height="120"></canvas></figure>' +
      '<figure><figcaption>process(frame) <span class="dim" id="camOutDim"></span></figcaption><canvas id="camOut" width="160" height="120"></canvas></figure></div>' +
      '<div class="cam-text mono" id="camText"></div>' +
      '<pre class="stderr" id="camErr" hidden></pre>' +
      '<div class="cam-help">Each frame is handed to <code>process(frame)</code> in <b>webcam.py</b> as a <code>(H, W, 3)</code> uint8 <b>BGR</b> array, exactly like <code>cap.read()</code>. Return an image, or <code>(image, "status text")</code>. Edit webcam.py and the stream restarts with your code. ' +
      'Your camera never leaves this tab: frames are processed locally, in your browser.</div></div>';
  }
  function stats(t) { var e = $('#camStats'); if (e) e.textContent = t; }
  function showErr(msg) { var e = $('#camErr'); if (!e) return; e.hidden = !msg; e.textContent = msg || ''; }
  function setBtn() { var b = $('#camGo'); if (!b) return; b.innerHTML = S.running ? '<i data-lucide="square"></i>Stop' : '<i data-lucide="play"></i>Start'; if (window.lucide) lucide.createIcons(); }

  function mount(root, lesson, getCode) {
    S.root = root; S.getCode = getCode;
    if (S.lessonId !== lesson.id) { S.lessonId = lesson.id; }
    root.innerHTML = html();
    $('#camSrc').value = pref.src; $('#camRes').value = String(pref.res);
    $('#camSrc').onchange = function () {
      pref.src = this.value;
      if (pref.src === 'file') { $('#camFile').click(); return; }
      if (S.running) restart();
    };
    $('#camFile').onchange = function (e) {
      var f = e.target.files[0]; if (!f) { pref.src = 'sim'; $('#camSrc').value = 'sim'; return; }
      if (S.fileUrl) URL.revokeObjectURL(S.fileUrl);
      S.fileUrl = URL.createObjectURL(f); restart();
    };
    $('#camRes').onchange = function () { pref.res = +this.value; if (S.running) restart(); };
    $('#camGo').onclick = function () { S.running ? stop() : start(); };
    start();
  }

  function openSource() {
    stopSource();
    if (pref.src === 'sim') { S.sim = S.sim || makeSim(); return Promise.resolve({ w: 320, h: 240 }); }
    var v = document.createElement('video'); v.muted = true; v.playsInline = true; v.setAttribute('playsinline', ''); S.video = v;
    if (pref.src === 'file') {
      if (!S.fileUrl) return Promise.reject(new Error('Choose a video file first.'));
      v.src = S.fileUrl; v.loop = true;
      return v.play().then(function () { return { w: v.videoWidth || 320, h: v.videoHeight || 240 }; });
    }
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return Promise.reject(new Error('This browser does not expose a camera here (it needs HTTPS and a top-level page). Use the simulated camera, or the "On your machine" script.'));
    return navigator.mediaDevices.getUserMedia({ video: { width: { ideal: 640 }, height: { ideal: 480 } }, audio: false }).then(function (st) {
      S.stream = st; v.srcObject = st;
      return v.play().then(function () { return { w: v.videoWidth || 640, h: v.videoHeight || 480 }; });
    }, function (e) {
      var m = e && e.name === 'NotAllowedError' ? 'Camera permission was denied (or the page is embedded and not allowed to ask). Allow camera access for this site, open the app in its own tab, or use the simulated camera.'
        : e && e.name === 'NotFoundError' ? 'No camera was found on this device. Try the simulated camera or a video file.'
          : 'Could not open the camera: ' + (e && e.message || e);
      throw new Error(m);
    });
  }
  function stopSource() {
    if (S.stream) { S.stream.getTracks().forEach(function (t) { t.stop(); }); S.stream = null; }
    if (S.video) { try { S.video.pause(); } catch (e) { } S.video.removeAttribute('src'); S.video.srcObject = null; S.video = null; }
  }

  function start() {
    var gen = ++S.gen;
    cancelAnimationFrame(S.raf); S.pending = false; showErr(null);
    if (!window.PY || !PY.isReady()) { stats('waiting for Python to load…'); setTimeout(function () { if (gen === S.gen && S.root && document.body.contains(S.root)) start(); }, 800); return; }
    S.running = true; setBtn(); stats('preparing webcam.py…');
    var c = S.getCode();
    PY.liveSetup(c.library, c.solution, c.code).then(function (r) {
      if (gen !== S.gen) return;
      if (r.error) { S.running = false; setBtn(); stats('setup failed'); showErr(r.error + (c.impl === 'mine' && /NotImplementedError|TODO/.test(r.error) ? '\n\nTip: switch "use" to reference to run with the reference solution.' : '')); return; }
      if (r.stdout) $('#camText').textContent = r.stdout.trim();
      return openSource().then(function (dim) {
        if (gen !== S.gen) { stopSource(); return; }
        var w = pref.res, h = Math.max(2, Math.round(dim.h * w / dim.w));
        S.cap = document.createElement('canvas'); S.cap.width = w; S.cap.height = h;
        var ci = $('#camIn'); ci.width = w; ci.height = h; $('#camInDim').textContent = w + '×' + h;
        S.fpsT = performance.now(); S.fpsN = 0; S.frames = 0;
        loop(gen);
      });
    }).catch(function (e) { if (gen !== S.gen) return; S.running = false; setBtn(); stats('stopped'); showErr(e.message || String(e)); stopSource(); });
  }
  function grab() {
    var ctx = S.cap.getContext('2d', { willReadFrequently: true }), w = S.cap.width, h = S.cap.height;
    if (pref.src === 'sim') drawSim(ctx, w, h);
    else ctx.drawImage(S.video, 0, 0, w, h);
    var ci = $('#camIn'); if (ci) ci.getContext('2d').drawImage(S.cap, 0, 0);
    return ctx.getImageData(0, 0, w, h);
  }
  function loop(gen) {
    if (gen !== S.gen || !S.running) return;
    S.raf = requestAnimationFrame(function () { loop(gen); });
    if (S.pending) return;
    if (pref.src === 'sim') { var now = performance.now(); if (S._last && now - S._last < 30) return; S._last = now; } // ~30 fps camera
    if (!$('#camIn')) { stop(); return; }
    var img = grab(), w = img.width, h = img.height;
    S.pending = true;
    PY.liveFrame(img.data.buffer, w, h).then(function (m) {
      S.pending = false;
      if (gen !== S.gen) return;
      if (m.error) { showErr(m.error); stats('error in process(frame) — fix webcam.py and press Run live'); S.running = false; setBtn(); stopSource(); return; }
      var co = $('#camOut'); if (!co) return;
      if (co.width !== m.w || co.height !== m.h) { co.width = m.w; co.height = m.h; $('#camOutDim').textContent = m.w + '×' + m.h; }
      co.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(m.bytes), m.w, m.h), 0, 0);
      S.fpsN++; var t = performance.now();
      if (t - S.fpsT > 500) { S.fps = S.fpsN * 1000 / (t - S.fpsT); S.fpsT = t; S.fpsN = 0; }
      stats(S.fps.toFixed(1) + ' fps · ' + m.ms + ' ms in process() · ' + w + '×' + h + ' in');
      var tx = $('#camText'); if (tx) tx.textContent = m.text || '';
      showErr(null);
    }).catch(function (e) { S.pending = false; if (gen !== S.gen) return; S.running = false; setBtn(); stopSource(); if (e.message !== 'Stopped') showErr(e.message); stats('stopped'); });
  }
  function stop() {
    S.gen++; S.running = false; cancelAnimationFrame(S.raf); S.pending = false; stopSource(); setBtn();
    if ($('#camStats')) stats('stopped');
  }
  function restart() { if (S.root && document.body.contains(S.root) && $('#camGo')) start(); }
  window.CAM = { mount: mount, stop: stop, restart: restart, isRunning: function () { return S.running; } };
})();
