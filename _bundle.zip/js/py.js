/* Main-thread wrapper around the Pyodide worker */
(function () {
  var worker = null, ready = false, readyPromise = null, readyResolve = null, readyReject = null;
  var seq = 0, pending = {}, listeners = [], info = {};

  function emit(state, msg) { listeners.forEach(function (f) { f(state, msg); }); }

  function absUrl(p) { return new URL(p, location.href).href; }

  function loadImageBundle() {
    return new Promise(function (res, rej) {
      if (window.IMAGE_BUNDLE) return res(window.IMAGE_BUNDLE);
      var s = document.createElement('script');
      s.src = 'data/images.js';
      s.onload = function () { res(window.IMAGE_BUNDLE); };
      s.onerror = rej;
      document.head.appendChild(s);
    });
  }
  function b64ToBytes(b64) {
    var bin = atob(b64), n = bin.length, u = new Uint8Array(n);
    for (var i = 0; i < n; i++) u[i] = bin.charCodeAt(i);
    return u.buffer;
  }

  function start() {
    if (readyPromise) return readyPromise;
    readyPromise = new Promise(function (res, rej) { readyResolve = res; readyReject = rej; });
    var blob = new Blob([window.WORKER_SRC], { type: 'application/javascript' });
    worker = new Worker(URL.createObjectURL(blob));
    worker.onmessage = function (e) {
      var m = e.data;
      if (m.type === 'status') emit('loading', m.msg);
      else if (m.type === 'need_images') {
        emit('loading', 'Loading bundled sample images…');
        loadImageBundle().then(function (bundle) {
          var items = m.names.filter(function (n) { return bundle[n]; }).map(function (n) { return { name: n, bytes: b64ToBytes(bundle[n]) }; });
          worker.postMessage({ type: 'images', items: items });
        }).catch(function () { worker.postMessage({ type: 'images', items: [] }); });
      }
      else if (m.type === 'ready') { ready = true; info = m; emit('ready', 'Python ready · OpenCV ' + m.version); readyResolve(m); }
      else if (m.type === 'frame') { var fp = pending[m.id]; if (fp) { delete pending[m.id]; fp.resolve(m); } }
      else if (m.type === 'result' || m.type === 'error' || m.type === 'uploaded') {
        var p = pending[m.id];
        if (!p) return;
        delete pending[m.id];
        if (m.type === 'error') p.reject(new Error(m.msg));
        else if (m.type === 'uploaded') p.resolve(m);
        else { try { p.resolve(JSON.parse(m.json)); } catch (err) { p.reject(err); } }
        if (!Object.keys(pending).some(function (k) { return pending[k].loud; })) emit('ready', 'Python ready · OpenCV ' + info.version);
      }
    };
    worker.onerror = function (e) {
      emit('error', 'Python worker failed: ' + (e.message || 'unknown error'));
      if (!ready) readyReject(new Error(e.message || 'worker error'));
    };
    emit('loading', 'Starting Python…');
    worker.postMessage({
      type: 'init',
      grader: window.CURRICULUM.grader,
      images: window.CURRICULUM.images.map(function (n) { return { name: n, url: absUrl('img/' + n) }; })
    });
    return readyPromise;
  }

  function call(msg) {
    return start().then(function () {
      return new Promise(function (res, rej) {
        var id = ++seq;
        pending[id] = { resolve: res, reject: rej, loud: true };
        msg.id = id;
        emit('busy', msg.type === 'grade' ? 'Grading against OpenCV…' : 'Running…');
        worker.postMessage(msg);
      });
    });
  }

  function callQuiet(msg, transfer) {
    return start().then(function () {
      return new Promise(function (res, rej) {
        var id = ++seq; pending[id] = { resolve: res, reject: rej }; msg.id = id;
        worker.postMessage(msg, transfer || []);
      });
    });
  }

  function stop() {
    if (worker) worker.terminate();
    Object.keys(pending).forEach(function (k) { pending[k].reject(new Error('Stopped')); });
    pending = {}; worker = null; ready = false; readyPromise = null;
    emit('idle', 'Python stopped — restarting…');
    return start();
  }

  window.PY = {
    start: start,
    isReady: function () { return ready; },
    info: function () { return info; },
    onStatus: function (f) { listeners.push(f); },
    run: function (library, solution, extra, label) {
      return call({ type: 'run', library: JSON.stringify(library), solution: solution, extra: extra || '', label: label });
    },
    grade: function (library, solution, tests, banned, fns) {
      return call({ type: 'grade', library: JSON.stringify(library), solution: solution, tests: tests, banned: JSON.stringify(banned || []), fns: JSON.stringify(fns || []) });
    },
    liveSetup: function (library, solution, code) {
      return callQuiet({ type: 'live_setup', library: JSON.stringify(library), solution: solution, code: code });
    },
    liveFrame: function (buffer, w, h) { return callQuiet({ type: 'live_frame', bytes: new Uint8Array(buffer), w: w, h: h }, [buffer]); },
    upload: function (name, bytes) { return call({ type: 'upload', name: name, bytes: bytes }); },
    stop: stop
  };
})();
