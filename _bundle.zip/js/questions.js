/* Markdown + math helper and the incremental question ladder. */
(function () {
  function katexOr(src, display) {
    try { return window.katex ? katex.renderToString(src, { displayMode: display, throwOnError: false }) : src; } catch (e) { return src; }
  }
  function render(src, inline) {
    if (!src) return '';
    var code = [], math = [];
    var s = src.replace(/```[\s\S]*?```|`[^`\n]*`/g, function (m) { code.push(m); return 'ZQC' + (code.length - 1) + 'QZ'; });
    s = s.replace(/\$\$([\s\S]+?)\$\$/g, function (_, m) { math.push(katexOr(m, true)); return 'ZQM' + (math.length - 1) + 'QZ'; });
    s = s.replace(/\$([^\$\n]+?)\$/g, function (_, m) { math.push(katexOr(m, false)); return 'ZQM' + (math.length - 1) + 'QZ'; });
    s = s.replace(/ZQC(\d+)QZ/g, function (_, i) { return code[+i]; });
    var html = window.marked ? (inline ? marked.parseInline(s) : marked.parse(s)) : s;
    return html.replace(/ZQM(\d+)QZ/g, function (_, i) { return math[+i]; });
  }
  window.MD = { block: function (s) { return render(s, false); }, inline: function (s) { return render(s, true); } };

  var LV = { 1: 'Warm-up', 2: 'Apply', 3: 'Trace', 4: 'Challenge' };
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function staticGrid(data) {
    var w = data[0].length;
    return '<div class="ginput sgrid" style="grid-template-columns:repeat(' + w + ', 46px)">' + data.map(function (r) { return r.map(function (v) { return '<span>' + esc(v) + '</span>'; }).join(''); }).join('') + '</div>';
  }

  /* mount(root, lesson, state, save)  state = {qi: 'ok'|'revealed'} */
  function mount(root, lesson, state, save) {
    var qs = lesson.questions || [];
    var tries = {};
    function solved(i) { return state[i] === 'ok' || state[i] === 'revealed'; }
    function firstOpen() { for (var i = 0; i < qs.length; i++) if (!solved(i)) return i; return qs.length; }
    function score() { var n = 0; for (var i = 0; i < qs.length; i++) if (state[i] === 'ok') n++; return n; }

    function draw() {
      var open = firstOpen();
      var html = '<div class="ladder-legend"><span class="lvl" data-l="1">1 Warm-up</span><span class="lvl" data-l="2">2 Apply</span><span class="lvl" data-l="3">3 Trace</span><span class="lvl" data-l="4">4 Challenge</span><span class="ai-tag"><i data-lucide="sparkles"></i>AI</span> = how this is used in ML / AI systems<span class="q-score" style="margin-left:auto">' + score() + '/' + qs.length + ' correct</span></div><div class="ladder">';
      qs.forEach(function (q, i) {
        var locked = i > open, done = solved(i);
        html += '<div class="q' + (state[i] === 'ok' ? ' correct' : '') + (locked ? ' locked' : '') + '" data-qi="' + i + '">';
        html += '<div class="q-top"><span class="lvl" data-l="' + q.level + '">' + q.level + ' ' + LV[q.level] + '</span>' + (q.ai ? '<span class="ai-tag"><i data-lucide="sparkles"></i>AI</span>' : '') + '<span class="q-num">' + (done ? (state[i] === 'ok' ? '✓ ' : '◌ revealed · ') : '') + 'Q' + (i + 1) + '</span></div>';
        if (locked) { html += '<div class="q-text" style="color:var(--faint)">Answer Q' + (i) + ' to unlock.</div></div>'; return; }
        html += '<div class="q-text">' + MD.block(q.q) + '</div>';
        if (q.type === 'mcq') {
          html += '<div class="opts" role="radiogroup">' + q.options.map(function (o, k) {
            var cls = done ? (k === q.answer ? ' right' : '') : '';
            return '<label class="opt' + cls + '"><input type="radio" name="q' + lesson.id + i + '" value="' + k + '"' + (done ? ' disabled' : '') + (done && k === q.answer ? ' checked' : '') + '><span>' + MD.inline(o) + '</span></label>';
          }).join('') + '</div>';
        } else if (q.type === 'number') {
          html += '<div class="q-row"><input class="num-in" type="text" inputmode="decimal" aria-label="Your answer"' + (done ? ' disabled value="' + q.answer + '"' : '') + '></div>';
        } else if (q.type === 'grid') {
          var a = q.answer, w = a[0].length;
          html += '<div class="q-grids">' + (q.show || []).map(function (g) { return '<div><div class="panel-title">' + esc(g.label) + '</div>' + staticGrid(g.data) + '</div>'; }).join('');
          html += '<div><div class="panel-title">your answer</div><div class="ginput" style="grid-template-columns:repeat(' + w + ', 46px)">';
          a.forEach(function (row, y) { row.forEach(function (v, x) { html += '<input type="text" inputmode="decimal" data-y="' + y + '" data-x="' + x + '" aria-label="row ' + y + ' col ' + x + '"' + (done ? ' disabled value="' + v + '" class="right"' : '') + '>'; }); });
          html += '</div></div></div>';
        }
        if (!done) {
          html += '<div class="q-row"><button class="btn btn-primary btn-sm" data-check>Check</button>' + ((tries[i] || 0) >= 2 ? '<button class="btn btn-ghost btn-sm" data-reveal>Show answer</button>' : '') + '</div>';
          if (tries[i]) html += '<div class="feedback bad"><div class="fb-h">Not quite' + (tries[i] >= 2 ? '' : ' — try again') + '</div>' + (tries[i] >= 2 ? '<p>Hint: re-read the concept section, or step through the emulator above with Predict mode on.</p>' : '') + '</div>';
        } else {
          var ans = q.type === 'mcq' ? '' : q.type === 'number' ? ' Answer: <code>' + q.answer + '</code>' : '';
          html += '<div class="feedback ' + (state[i] === 'ok' ? 'ok' : 'bad') + '"><div class="fb-h">' + (state[i] === 'ok' ? 'Correct' : 'Answer shown') + ans + '</div>' + MD.block(q.explain || '') + '</div>';
        }
        html += '</div>';
      });
      html += '</div>';
      if (open >= qs.length && qs.length) html += '<div class="feedback ok" style="margin-top:var(--space-4)"><div class="fb-h">Ladder complete — ' + score() + '/' + qs.length + ' first-time-right.</div><p>Now implement it for real in the workbench and press Grade.</p></div>';
      root.innerHTML = html;
      if (window.lucide) lucide.createIcons();
    }

    function check(i, el) {
      var q = qs[i], ok = false;
      if (q.type === 'mcq') {
        var sel = el.querySelector('input:checked'); if (!sel) return;
        ok = +sel.value === q.answer;
      } else if (q.type === 'number') {
        var raw = el.querySelector('.num-in').value.trim(); if (!raw) return;
        var v = parseFloat(raw.replace(',', '.')); var tol = q.tol != null ? q.tol : 1e-6;
        ok = !isNaN(v) && Math.abs(v - q.answer) <= tol + 1e-9 * Math.abs(q.answer);
      } else if (q.type === 'grid') {
        var ins = el.querySelectorAll('.ginput input'), all = true, tol2 = q.tol || 0;
        ins.forEach(function (inp) { var a = q.answer[+inp.dataset.y][+inp.dataset.x], v2 = parseFloat(inp.value); var r = !isNaN(v2) && Math.abs(v2 - a) <= tol2 + 1e-9; inp.classList.toggle('right', r); inp.classList.toggle('wrong', !r); if (!r) all = false; });
        ok = all;
      }
      if (ok) { state[i] = 'ok'; save(); draw(); focusNext(i); }
      else {
        tries[i] = (tries[i] || 0) + 1;
        if (q.type === 'grid') { // keep typed values
          var vals = Array.prototype.map.call(el.querySelectorAll('.ginput input'), function (x) { return x.value; });
          draw(); var el2 = root.querySelector('[data-qi="' + i + '"]');
          el2.querySelectorAll('.ginput input').forEach(function (inp, k) { inp.value = vals[k]; var a = q.answer[+inp.dataset.y][+inp.dataset.x]; inp.classList.add(Math.abs(parseFloat(inp.value) - a) <= (q.tol || 0) ? 'right' : 'wrong'); });
        } else if (q.type === 'mcq') {
          var pick = +el.querySelector('input:checked').value; draw();
          var el3 = root.querySelector('[data-qi="' + i + '"]'); var opt = el3.querySelectorAll('.opt')[pick]; opt.classList.add('wrong'); opt.querySelector('input').disabled = true;
        } else { var keep = el.querySelector('.num-in').value; draw(); var n = root.querySelector('[data-qi="' + i + '"] .num-in'); n.value = keep; n.focus(); n.select(); }
      }
    }
    function focusNext(i) {
      var nx = root.querySelector('[data-qi="' + (i + 1) + '"]');
      if (nx) { var f = nx.querySelector('input'); if (f) f.focus({ preventScroll: true }); }
    }
    root.addEventListener('click', function (e) {
      var qel = e.target.closest('.q'); if (!qel) return;
      var i = +qel.dataset.qi;
      if (e.target.closest('[data-check]')) check(i, qel);
      else if (e.target.closest('[data-reveal]')) { state[i] = 'revealed'; save(); draw(); }
    });
    root.addEventListener('change', function (e) {
      if (e.target.matches('.opt input')) { var g = e.target.closest('.opts'); g.querySelectorAll('.opt').forEach(function (o) { o.classList.toggle('sel', o.contains(e.target)); }); }
    });
    root.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && e.target.matches('.num-in, .ginput input')) { var qel = e.target.closest('.q'); check(+qel.dataset.qi, qel); }
    });
    draw();
    return { redraw: draw, score: score };
  }
  window.QUIZ = { mount: mount };
})();
