"""mycv grader — runs learner code with cv2 hidden, then compares against real OpenCV.

The same file runs in the browser (Pyodide) and locally (CPython) for testing.
"""
import sys, io, json, math, time, base64, traceback, tokenize, copy, types
import numpy as np
import cv2

IMG_DIR = '/imgs'
_OUT = []          # images produced by show()
_IMG_CACHE = {}
SHOW_LIMIT = 24

# ----------------------------------------------------------------- helpers

def _to_display(img):
    """Convert any array into a displayable uint8 (gray or BGR) image."""
    a = np.asarray(img)
    if a.dtype == bool:
        a = a.astype(np.uint8) * 255
    if a.ndim == 3 and a.shape[2] == 1:
        a = a[:, :, 0]
    if a.ndim == 3 and a.shape[2] == 4:
        a = a[:, :, :3]
    if a.ndim == 3 and a.shape[2] == 2:
        a = np.dstack([a[:, :, 0], a[:, :, 1], np.zeros_like(a[:, :, 0])])
    if a.ndim not in (2, 3):
        raise ValueError('show() needs a 2-D (gray) or 3-D (H, W, 3) array, got shape %s' % (a.shape,))
    if a.dtype != np.uint8:
        f = a.astype(np.float64)
        f = np.nan_to_num(f)
        lo, hi = float(f.min()), float(f.max())
        if lo >= 0 and hi <= 255 and np.issubdtype(a.dtype, np.integer):
            a = f.astype(np.uint8)
        elif lo >= 0 and hi <= 1.0 and np.issubdtype(a.dtype, np.floating):
            a = np.round(f * 255).astype(np.uint8)
        else:
            a = np.round((f - lo) / (hi - lo + 1e-12) * 255).astype(np.uint8)
    return np.ascontiguousarray(a)


def _png(img):
    d = _to_display(img)
    ok, buf = cv2.imencode('.png', d)
    return base64.b64encode(buf.tobytes()).decode('ascii'), d


def _pack(img, title=''):
    a = np.asarray(img)
    b64, d = _png(a)
    item = {'title': str(title), 'png': b64, 'h': int(d.shape[0]), 'w': int(d.shape[1]),
            'shape': list(a.shape), 'dtype': str(a.dtype)}
    # raw values for the pixel inspector (small images only)
    if a.size <= 160 * 160 * 3 and a.ndim in (2, 3):
        raw = np.asarray(a, dtype=np.float32)
        item['raw'] = base64.b64encode(np.ascontiguousarray(raw).tobytes()).decode('ascii')
    return item


def show(img, title=''):
    """Display an image (any dtype / shape) in the Output panel."""
    if len(_OUT) >= SHOW_LIMIT:
        return
    _OUT.append(_pack(img, title))


def load(name, size=None, gray=False):
    """Load a sample image as a BGR uint8 array (H, W, 3), or gray (H, W).

    This is the only thing the course gives you for free: decoding JPEG/PNG.
    (You will write your own BMP decoder in lesson 5.)
    size = (width, height) to downscale for speed.
    """
    key = (name, size, gray)
    if key not in _IMG_CACHE:
        p = IMG_DIR + '/' + name
        im = cv2.imread(p, cv2.IMREAD_GRAYSCALE if gray else cv2.IMREAD_COLOR)
        if im is None:
            raise FileNotFoundError('No sample image called %r. Try one of: %s' % (name, ', '.join(SAMPLES)))
        if size is not None:
            im = cv2.resize(im, tuple(size), interpolation=cv2.INTER_AREA)
        _IMG_CACHE[key] = im
    return _IMG_CACHE[key].copy()


SAMPLES = ['fruits.jpg', 'baboon.jpg', 'building.jpg', 'butterfly.jpg', 'messi5.jpg', 'smarties.png',
           'sudoku.png', 'box.png', 'box_in_scene.png', 'chessboard.png', 'gradient.png', 'pic1.png',
           'starry_night.jpg', 'document.jpg', 'shapes.png']


def user_image(path):
    """Images uploaded by the learner live in /imgs/user/."""
    return load('user/' + path)


def sim_video(n=30, size=(160, 120), seed=0, objects=3, noise=4, still=0):
    """A synthetic 'camera': n BGR frames of coloured balls moving over a textured background.

    still = number of initial frames with no motion (useful for background models).
    """
    w, h = size
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[0:h, 0:w]
    bg = np.zeros((h, w, 3), np.float64)
    bg[..., 0] = 70 + 30 * np.sin(xx / 17.0)
    bg[..., 1] = 80 + 25 * np.cos(yy / 13.0)
    bg[..., 2] = 60 + 20 * np.sin((xx + yy) / 23.0)
    cols = [(40, 40, 230), (40, 200, 60), (230, 120, 30), (30, 220, 230), (200, 40, 200)]
    objs = []
    for k in range(objects):
        r = int(rng.integers(max(4, h // 14), max(6, h // 7)))
        objs.append([float(rng.uniform(r, w - r)), float(rng.uniform(r, h - r)),
                     float(rng.uniform(-4, 4)) or 2.0, float(rng.uniform(-3, 3)) or 1.5, r, cols[k % len(cols)]])
    frames = []
    for i in range(n):
        f = bg.copy()
        for o in objs:
            if i >= still:
                o[0] += o[2]; o[1] += o[3]
                if not o[4] <= o[0] <= w - o[4]: o[2] = -o[2]; o[0] = min(max(o[0], o[4]), w - o[4])
                if not o[4] <= o[1] <= h - o[4]: o[3] = -o[3]; o[1] = min(max(o[1], o[4]), h - o[4])
            m = (xx - o[0]) ** 2 + (yy - o[1]) ** 2 < o[4] ** 2
            f[m] = o[5]
        f += rng.normal(0, noise, f.shape) if noise else 0
        frames.append(np.clip(np.rint(f), 0, 255).astype(np.uint8))
    return frames


# ------------------------------------------------------------ cv2 blocker

BLOCKED = ('cv2', 'scipy', 'skimage', 'PIL', 'torch', 'torchvision', 'imageio', 'sklearn')


class _Blocker:
    def find_spec(self, name, path=None, target=None):
        root = name.split('.')[0]
        if root in BLOCKED:
            raise ImportError("'%s' is off-limits in mycv: you're building OpenCV from scratch. "
                              "Use plain Python, math and numpy." % root)
        return None


class hidden_cv2:
    """Context manager: while active, `import cv2` (and friends) fails."""
    def __enter__(self):
        self.saved = {k: v for k, v in sys.modules.items() if k.split('.')[0] in BLOCKED}
        for k in self.saved:
            del sys.modules[k]
        self.blocker = _Blocker()
        sys.meta_path.insert(0, self.blocker)
        return self

    def __exit__(self, *a):
        try:
            sys.meta_path.remove(self.blocker)
        except ValueError:
            pass
        sys.modules.update(self.saved)
        return False


def strip_comments_and_strings(src):
    out = []
    try:
        for tok in tokenize.generate_tokens(io.StringIO(src).readline):
            if tok.type in (tokenize.COMMENT, tokenize.STRING):
                continue
            out.append(tok.string)
    except Exception:
        return src
    return ' '.join(out)


def check_banned(src, banned):
    code = strip_comments_and_strings(src).replace(' ', '')
    hits = []
    for b in banned or []:
        if b.replace(' ', '') in code:
            hits.append(b)
    return hits


# ---------------------------------------------------------- namespaces

def make_namespace():
    ns = {'__name__': 'mycv', 'np': np, 'numpy': np, 'math': math, 'show': show, 'load': load,
          'user_image': user_image, 'SAMPLES': SAMPLES, 'sim_video': sim_video}
    return ns


def build_ns(library):
    """library: list of {'id','src'} executed in order into one shared namespace."""
    ns = make_namespace()
    for item in library:
        try:
            with hidden_cv2():
                exec(compile(item['src'], '<mycv:%s>' % item['id'], 'exec'), ns)
        except Exception as e:
            raise RuntimeError('Your saved library code for lesson "%s" failed to load: %s: %s'
                               % (item['id'], type(e).__name__, e))
    return ns


def _fmt_tb(e, fname_prefix='<'):
    tb = traceback.extract_tb(e.__traceback__)
    keep = [f for f in tb if f.filename.startswith(fname_prefix)]
    lines = []
    for f in keep[-4:]:
        lines.append('  %s, line %d, in %s' % (f.filename.strip('<>'), f.lineno, f.name))
        if f.line:
            lines.append('    ' + f.line.strip())
    return ('Traceback (your code):\n' + '\n'.join(lines) + '\n' if lines else '') + '%s: %s' % (type(e).__name__, e)


class _Capture(io.StringIO):
    def __init__(self, limit=20000):
        super().__init__()
        self.limit = limit

    def write(self, s):
        if self.tell() < self.limit:
            return super().write(s)
        return len(s)


# ----------------------------------------------------------------- run

def run(library_json, solution, extra='', file_label='solution.py'):
    """Run the learner's solution (and optional playground/AI snippet)."""
    library = json.loads(library_json) if isinstance(library_json, str) else library_json
    _OUT.clear()
    cap = _Capture()
    old = sys.stdout, sys.stderr
    sys.stdout = sys.stderr = cap
    err = None
    t0 = time.time()
    try:
        ns = build_ns(library)
        with hidden_cv2():
            exec(compile(solution, '<solution.py>', 'exec'), ns)
            if extra.strip():
                exec(compile(extra, '<%s>' % file_label, 'exec'), ns)
    except Exception as e:
        err = _fmt_tb(e)
    finally:
        sys.stdout, sys.stderr = old
    return json.dumps({'stdout': cap.getvalue(), 'error': err, 'images': list(_OUT),
                       'ms': int((time.time() - t0) * 1000)})


# --------------------------------------------------------------- grading

class _Fail(Exception):
    pass


def _loc(idx):
    if len(idx) == 2:
        return 'row %d, col %d' % idx
    if len(idx) == 3:
        return 'row %d, col %d, channel %d' % idx
    return 'index %s' % (idx,)


def _val(v):
    if isinstance(v, (float, np.floating)):
        return '%.6g' % v
    return str(v)


class Tester:
    def __init__(self, ns):
        self.ns = ns
        self.cases = []
        self.rng = np.random.default_rng(1234)

    # ---------- inputs
    def img(self, name, size=None, gray=False):
        return load(name, size, gray)

    def rand(self, shape, lo=0, hi=256, dtype=np.uint8):
        return self.rng.integers(lo, hi, size=shape).astype(dtype)

    def randf(self, shape, lo=0.0, hi=1.0):
        return self.rng.uniform(lo, hi, size=shape)

    def fn(self, name):
        f = self.ns.get(name)
        if f is None or not callable(f):
            raise _Fail('Could not find a function called `%s`. Keep the name exactly as in the starter code.' % name)
        return f

    def note(self, text):
        self.cases.append({'name': text, 'ok': None, 'msg': '', 'images': []})

    # ---------- main check
    def check(self, name, fn, args=(), expected=None, cmp='exact', tol=0, pct=1.0, thr=0.95,
              rtol=1e-5, atol=1e-6, kwargs=None, inputs=None, custom=None, dtype_strict=True,
              show=True, hint=None, prep=None):
        case = {'name': name, 'ok': False, 'msg': '', 'images': [], 'ms': 0}
        self.cases.append(case)
        try:
            f = self.fn(fn) if isinstance(fn, str) else fn
            a = copy.deepcopy(args)
            kw = copy.deepcopy(kwargs or {})
            t0 = time.time()
            with hidden_cv2():
                got = f(*a, **kw)
            case['ms'] = int((time.time() - t0) * 1000)
            if prep is not None:
                got = prep(got)
            ok, msg = self._compare(got, expected, cmp, tol, pct, thr, rtol, atol, custom, dtype_strict)
            case['ok'], case['msg'] = bool(ok), str(msg)
            if not ok and hint:
                case['msg'] += '\nHint: ' + hint
            if show:
                self._attach(case, inputs, got, expected, cmp)
        except _Fail as e:
            case['msg'] = str(e)
        except Exception as e:
            case['msg'] = _fmt_tb(e)
        return case['ok']

    def _attach(self, case, inputs, got, expected, cmp):
        def imgish(x):
            try:
                x = np.asarray(x)
            except Exception:
                return False
            return x.dtype != object and (x.ndim == 2 and min(x.shape) >= 2) or (x.ndim == 3 and x.shape[2] in (1, 3, 4) and min(x.shape[:2]) >= 2)
        try:
            for i, inp in enumerate(inputs or []):
                if imgish(inp):
                    case['images'].append(_pack(inp, 'input' if i == 0 else 'input %d' % (i + 1)))
            if imgish(got):
                case['images'].append(_pack(got, 'yours'))
            if imgish(expected):
                case['images'].append(_pack(expected, 'OpenCV'))
                g, e = np.asarray(got), np.asarray(expected)
                if imgish(got) and g.shape == e.shape and cmp in ('exact', 'tol', 'close'):
                    d = np.abs(g.astype(np.float64) - e.astype(np.float64))
                    if d.ndim == 3:
                        d = d.max(axis=2)
                    if d.max() > 0:
                        heat = np.zeros(d.shape + (3,), np.uint8)
                        mag = np.clip(d / (d.max() + 1e-12) * 255, 0, 255).astype(np.uint8)
                        heat[..., 2] = np.where(d > 0, np.maximum(mag, 90), 0)
                        heat[..., 1] = np.where(d > 0, mag // 3, 0)
                        case['images'].append(_pack(heat, 'difference'))
        except Exception:
            pass

    def _compare(self, got, exp, cmp, tol, pct, thr, rtol, atol, custom, dtype_strict):
        if cmp == 'custom':
            return custom(got, exp)
        if got is None:
            return False, 'Your function returned None. Did you forget a `return` statement?'
        if cmp == 'value':
            if isinstance(exp, float) or isinstance(got, float):
                try:
                    ok = math.isclose(float(got), float(exp), rel_tol=rtol, abs_tol=atol)
                except Exception:
                    ok = False
            else:
                try:
                    ok = got == exp
                    if isinstance(ok, np.ndarray):
                        ok = bool(ok.all())
                    ok = bool(ok)
                except Exception:
                    ok = False
            return ok, ('Correct: %s' % _val(got)) if ok else 'Expected %s, you returned %s' % (_val(exp), _val(got))
        g = np.asarray(got)
        e = np.asarray(exp)
        if g.dtype == object:
            return False, 'Your result could not be turned into a numeric array (ragged lists?).'
        if g.shape != e.shape:
            if g.squeeze().shape == e.squeeze().shape and cmp in ('close', 'tol', 'exact'):
                g = g.reshape(e.shape)
            else:
                return False, 'Shape mismatch: OpenCV gives %s, yours is %s.' % (e.shape, g.shape)
        if dtype_strict and cmp in ('exact', 'tol') and g.dtype != e.dtype:
            return False, ('dtype mismatch: OpenCV returns %s, yours is %s. '
                           'Images are usually uint8 — clip to 0..255 and use .astype(np.uint8).' % (e.dtype, g.dtype))
        if cmp == 'exact':
            if np.array_equal(g, e):
                return True, 'Pixel-perfect match (%d values).' % e.size
            bad = np.argwhere(g != e)
            idx = tuple(int(i) for i in bad[0])
            return False, '%d of %d values differ. First at %s: yours %s, OpenCV %s.' % (
                len(bad), e.size, _loc(idx), _val(g[idx]), _val(e[idx]))
        if cmp == 'tol':
            d = np.abs(g.astype(np.int64) - e.astype(np.int64)) if np.issubdtype(e.dtype, np.integer) else np.abs(g - e)
            frac = float((d <= tol).mean())
            if frac >= pct:
                extra = '' if d.max() == 0 else ' (max difference %s — allowed, OpenCV uses fixed-point rounding)' % _val(d.max())
                return True, '%.2f%% of values within ±%s of OpenCV%s.' % (frac * 100, tol, extra)
            idx = tuple(int(i) for i in np.unravel_index(int(np.argmax(d)), d.shape))
            return False, 'Only %.2f%% of values are within ±%s (need %.0f%%). Worst at %s: yours %s, OpenCV %s.' % (
                frac * 100, tol, pct * 100, _loc(idx), _val(g[idx]), _val(e[idx]))
        if cmp == 'close':
            gf, ef = g.astype(np.float64), e.astype(np.float64)
            if np.allclose(gf, ef, rtol=rtol, atol=atol, equal_nan=True):
                return True, 'All %d values match OpenCV (max error %.2e).' % (e.size, float(np.max(np.abs(gf - ef))) if e.size else 0)
            d = np.abs(gf - ef) - (atol + rtol * np.abs(ef))
            idx = tuple(int(i) for i in np.unravel_index(int(np.argmax(d)), d.shape))
            return False, 'Values differ. Worst at %s: yours %s, OpenCV %s.' % (_loc(idx), _val(gf[idx]), _val(ef[idx]))
        if cmp == 'iou':
            gb, eb = g > 0, e > 0
            inter, uni = np.logical_and(gb, eb).sum(), np.logical_or(gb, eb).sum()
            iou = 1.0 if uni == 0 else inter / uni
            return iou >= thr, 'Overlap with OpenCV (IoU) = %.3f (need ≥ %.2f).' % (iou, thr)
        if cmp == 'corr':
            gf, ef = g.astype(np.float64).ravel(), e.astype(np.float64).ravel()
            if gf.std() == 0 or ef.std() == 0:
                return False, 'Your output is constant — no structure to compare.'
            c = float(np.corrcoef(gf, ef)[0, 1])
            return c >= thr, 'Correlation with OpenCV = %.4f (need ≥ %.3f).' % (c, thr)
        raise ValueError('unknown cmp ' + cmp)


def grade(library_json, solution, tests_src, banned_json='[]', fn_names_json='[]'):
    library = json.loads(library_json) if isinstance(library_json, str) else library_json
    banned = json.loads(banned_json) if isinstance(banned_json, str) else banned_json
    fn_names = json.loads(fn_names_json) if isinstance(fn_names_json, str) else fn_names_json
    _OUT.clear()
    cap = _Capture()
    old = sys.stdout, sys.stderr
    res = {'passed': False, 'cases': [], 'error': None, 'banned': [], 'stdout': ''}
    t0 = time.time()
    sys.stdout = sys.stderr = cap
    try:
        hits = check_banned(solution, banned)
        if hits:
            res['banned'] = hits
            res['error'] = ('Your code uses %s — that is the very thing this lesson asks you to build. '
                            'Rewrite it with loops / basic numpy indexing.' % ', '.join('`%s`' % h for h in hits))
            return json.dumps(res)
        ns = build_ns(library)
        global SHOW_LIMIT
        saved_limit = SHOW_LIMIT
        SHOW_LIMIT = 0  # silence show() during grading
        try:
            with hidden_cv2():
                exec(compile(solution, '<solution.py>', 'exec'), ns)
        finally:
            SHOW_LIMIT = saved_limit
        for n in fn_names:
            if not callable(ns.get(n)):
                raise _Fail('Your code must define a function named `%s`.' % n)
        T = Tester(ns)
        tns = {'np': np, 'cv2': cv2, 'math': math, 'T': T, 'ns': ns}
        exec(compile(tests_src, '<tests>', 'exec'), tns)
        tns['tests'](T)
        res['cases'] = T.cases
        real = [c for c in T.cases if c['ok'] is not None]
        res['passed'] = bool(real) and all(c['ok'] for c in real)
    except _Fail as e:
        res['error'] = str(e)
    except Exception as e:
        res['error'] = _fmt_tb(e)
    finally:
        sys.stdout, sys.stderr = old
        res['stdout'] = cap.getvalue()
        res['ms'] = int((time.time() - t0) * 1000)
    return json.dumps(res)


# ---------------------------------------------------------- live camera
_LIVE = {'ns': None, 'cap': None}


def live_setup(library_json, solution, code):
    """Prepare a namespace in which webcam.py's process(frame) will be called once per frame."""
    library = json.loads(library_json) if isinstance(library_json, str) else library_json
    cap = _Capture()
    old = sys.stdout, sys.stderr
    sys.stdout = sys.stderr = cap
    err = None
    try:
        ns = build_ns(library)
        with hidden_cv2():
            exec(compile(solution, '<solution.py>', 'exec'), ns)
            exec(compile(code, '<webcam.py>', 'exec'), ns)
        if not callable(ns.get('process')):
            raise _Fail('webcam.py must define a function process(frame) that returns an image.')
        _LIVE['ns'] = ns
    except Exception as e:
        _LIVE['ns'] = None
        err = str(e) if isinstance(e, _Fail) else _fmt_tb(e)
    finally:
        sys.stdout, sys.stderr = old
    return json.dumps({'error': err, 'stdout': cap.getvalue()})


def _rgba(img):
    d = _to_display(img)
    h, w = d.shape[:2]
    out = np.empty((h, w, 4), np.uint8)
    if d.ndim == 2:
        out[..., 0] = out[..., 1] = out[..., 2] = d
    else:
        out[..., 0] = d[..., 2]; out[..., 1] = d[..., 1]; out[..., 2] = d[..., 0]
    out[..., 3] = 255
    return out


def live_frame(buf, h, w):
    """buf: RGBA bytes from the browser. Returns (rgba_bytes, h, w, text, error, ms)."""
    ns = _LIVE['ns']
    if ns is None:
        return (b'', 0, 0, '', 'not set up', 0)
    if hasattr(buf, 'to_py'):
        buf = buf.to_py()
    a = np.frombuffer(buf, np.uint8).reshape(int(h), int(w), 4)
    frame = np.ascontiguousarray(a[:, :, 2::-1])          # RGBA -> BGR, like cv2.VideoCapture
    cap = _Capture(2000)
    old = sys.stdout, sys.stderr
    sys.stdout = sys.stderr = cap
    t0 = time.time()
    global SHOW_LIMIT
    saved = SHOW_LIMIT
    SHOW_LIMIT = 0
    try:
        with hidden_cv2():
            res = ns['process'](frame)
        text = ''
        if isinstance(res, tuple):
            res, text = res[0], str(res[1])
        if res is None:
            res = frame
        out = _rgba(res)
        return (out.tobytes(), out.shape[0], out.shape[1], (cap.getvalue()[-400:] + text), None, int((time.time() - t0) * 1000))
    except Exception as e:
        return (b'', 0, 0, cap.getvalue()[-400:], _fmt_tb(e), int((time.time() - t0) * 1000))
    finally:
        SHOW_LIMIT = saved
        sys.stdout, sys.stderr = old
